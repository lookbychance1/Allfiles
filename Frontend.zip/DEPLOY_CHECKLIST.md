# Deploy Checklist — v6

## On every deploy — ONE change only

Open **`js/config.js`** and bump `APP_VERSION`:

```js
const APP_VERSION = 7;   // was 6
```

Done. Everything else is automatic.

---

## How v6 cache nuking works

Every time any user visits your domain, this happens in order:

```
Browser loads index.html (always from network — never SW-cached)
    │
    ├─ loads js/config.js  →  APP_VERSION is defined
    │
    └─ NUKE SCRIPT runs:
           ├─ checks sessionStorage for "cache_nuked_v{N}"
           │
           ├─ NOT SET (fresh visit / new version):
           │       unregister all service workers
           │       delete all Cache Storage caches
           │       set sessionStorage marker
           │       reload(true)  ← hard reload, fetches everything from network
           │
           └─ ALREADY SET (same session after nuke):
                   skip nuke → app loads normally
                   SW re-registers cleanly with empty cache
```

### Why sessionStorage and not localStorage?

| Storage | Behaviour |
|---|---|
| `sessionStorage` | Cleared when the tab is closed. Each new tab/visit is a fresh session → nuke runs again. |
| `localStorage` | Persists across sessions. If used, the nuke would only run once ever per device — not what we want. |

### Why is index.html excluded from the SW cache?

The SW fetch handler explicitly passes through `/` and `/index.html` to the network (returns without calling `event.respondWith`). This guarantees the browser always fetches the real file, so the nuke script is never skipped due to a cached old `index.html`.

---

## What gets nuked

- All Cache Storage caches (`caches.keys()` → delete all)
- All service worker registrations for this origin

**Not touched:** localStorage, sessionStorage, IndexedDB, cookies.  
If you also want to clear those, add them to the `nukeAndReload` function in index.html.
