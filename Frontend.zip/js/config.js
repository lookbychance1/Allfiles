/**
 * ╔══════════════════════════════════════════════════╗
 * ║           SolveMCQ Frontend Config              ║
 * ║                                                  ║
 * ║  APP_VERSION lives in js/version.js — edit      ║
 * ║  ONLY that file on every release.               ║
 * ║  Changing anything here will NOT trigger the    ║
 * ║  'Update Now' toast. Only bumping APP_VERSION   ║
 * ║  in version.js will.                            ║
 * ╚══════════════════════════════════════════════════╝
 */

const API_BASE_URL = 'https://api.sharepremium.in';

/**
 * ── Maintenance Gate ─────────────────────────────────────────────────────────
 *
 *  SYS_MAINTAIN_STATUS   "ON"  → maintenance mode is armed (uses the schedule
 *                                below to decide WHEN it activates).
 *                        "OFF" → maintenance screen never shows, regardless of
 *                                the scheduled time. Use this to turn it off.
 *
 *  MAINTENANCE_START_IST  Date & time (Indian Standard Time) when the
 *                         maintenance screen should begin appearing.
 *                         Format: "YYYY-MM-DD HH:MM"  (24-hour clock, IST)
 *
 *  How it works:
 *    - Set SYS_MAINTAIN_STATUS = "ON" and fill MAINTENANCE_START_IST with
 *      the future IST date/time you want maintenance to begin.
 *    - Deploy. Visitors arriving before that time see the app normally.
 *    - At (or after) that exact IST moment, every page load shows the
 *      maintenance overlay automatically — no further action needed.
 *    - To end maintenance, set SYS_MAINTAIN_STATUS = "OFF" and redeploy.
 *      No need to touch MAINTENANCE_START_IST.
 *
 *  Examples:
 *    Start tonight at 2 AM IST:   MAINTENANCE_START_IST = "2025-06-10 02:00"
 *    Activate immediately:        MAINTENANCE_START_IST = "2000-01-01 00:00"
 *                                 (any past time triggers it right away)
 */
const SYS_MAINTAIN_STATUS   = "OFF";             // "ON" to arm  |  "OFF" to disable
const MAINTENANCE_START_IST = "2026-01-01 00:00"; // IST start time — YYYY-MM-DD HH:MM (24-hr)
const MAINTENANCE_ETA_IST   = "12:30 AM IST";    // upcoming Estimated completion time shown on overlay (free text, 12-hr format e.g. "2:30 AM IST")

/**
 * ── Feature Flags ────────────────────────────────────────────────────────────
 * These replace the /api/config backend call for UI visibility.
 * The backend env vars (PHONE_SIGNUP_SIGNIN / LEGACY_LOGIN) still gate the
 * actual API routes — these flags only control what the login screen shows.
 *
 *   FEATURE_PHONE_AUTH   "ON"  → 📱 Mobile OTP tab is visible
 *                        "OFF" → tab is hidden (users cannot reach phone auth)
 *
 *   FEATURE_LEGACY_LOGIN "ON"  → "Old User?" tab is visible
 *                        "OFF" → tab is hidden
 */
const FEATURE_PHONE_AUTH   = "OFF";  // ← show/hide Mobile OTP tab
const FEATURE_LEGACY_LOGIN = "ON";  // ← show/hide "Old User?" tab

/**
 * ── OAuth Provider Flags ─────────────────────────────────────────────────────
 * These control which social sign-in buttons appear on the login screen.
 * No backend call is made — visibility is decided entirely in the browser.
 * The backend OAuth routes are still protected by the server's own env vars;
 * these flags are UI-only (same pattern as FEATURE_PHONE_AUTH above).
 *
 *   FEATURE_OAUTH_GOOGLE  "ON"  → Google sign-in button is visible
 *                         "OFF" → button is hidden
 *
 *   FEATURE_OAUTH_GITHUB  "ON"  → GitHub sign-in button is visible
 *                         "OFF" → button is hidden
 *
 *   FEATURE_OAUTH_APPLE   "ON"  → Apple sign-in button is visible
 *                         "OFF" → button is hidden
 */
const FEATURE_OAUTH_GOOGLE = "ON";   // ← show/hide Google sign-in
const FEATURE_OAUTH_GITHUB = "ON";   // ← show/hide GitHub sign-in
const FEATURE_OAUTH_APPLE  = "OFF";  // ← show/hide Apple sign-in

/**
 * ── Dashboard Notification Bar ───────────────────────────────────────────────
 * Controls the sticky notification strip shown just below the dashboard header.
 * Notification text is set in js/notification.js → NOTIFICATION_TEXT.
 *
 * Format:  "ON_Nxx"  → show the bar   (Nxx = notification ID, e.g. N1, N2 …)
 *          "OFF_Nxx" → hide the bar
 *
 * The Nxx suffix acts as a version key stored in localStorage.
 * When a user dismisses the bar, that Nxx is remembered so the bar
 * does NOT reappear on the next visit — until you bump to a new Nxx.
 *
 * Examples:
 *   "ON_N1"  → show notification #1 (first time only; hidden after dismiss)
 *   "OFF_N1" → completely hide (no bar, regardless of dismiss state)
 *   "ON_N2"  → new notification #2 — reappears even for users who dismissed N1
 */
const NOTIFICATION = "ON_N6";  // ← change here to control the notification bar



