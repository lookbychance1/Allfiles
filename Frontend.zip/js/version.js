/**
 * ╔══════════════════════════════════════════════════╗
 * ║              SolveMCQ — App Version             ║
 * ║                                                  ║
 * ║  This is the ONLY file you edit on a release.   ║
 * ║  Bumping APP_VERSION here triggers:             ║
 * ║    • SW cache nuke (old cache cleared)          ║
 * ║    • 'Update Now' toast for open tabs           ║
 * ║    • Versioned ?v= cache-busting on assets      ║
 * ║                                                  ║
 * ║  Changing config.js (notifications, maintenance ║
 * ║  etc.) will NOT trigger any of the above.       ║
 * ╚══════════════════════════════════════════════════╝
 */

const APP_VERSION      = 8.26;   // ← bump this on every release
const PREV_APP_VERSION = 8.23;   // ← set to old APP_VERSION before bumping
