/**
 * Anti-DevTools Shield
 * Loaded first - blocks inspection, dumping, and scraping
 */
(function() {
  'use strict';

  // === 1. DevTools Detection ===
  let devOpen = false;
  const REDIRECT_URL = 'chrome://newtab/';

  // Detect iOS / Safari to avoid false "Access Restricted" on mobile browsers.
  // Safari on iPhone has outerWidth === innerWidth (no chrome offset), and the
  // debugger timing trick is unreliable in JavaScriptCore — both cause false positives.
  const isIOS = /iP(hone|ad|od)/i.test(navigator.userAgent) ||
    (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  const isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
  const isMobileBrowser = isIOS || isSafari;

  function checkDevTools() {
    if (isMobileBrowser) return false; // Never trigger on iOS/Safari
    const threshold = 160;
    const widthDiff = window.outerWidth - window.innerWidth > threshold;
    const heightDiff = window.outerHeight - window.innerHeight > threshold;
    // Timing attack
    const start = performance.now();
    debugger; // pauses only in devtools
    const end = performance.now();
    const timingAttack = (end - start) > 100;
    return widthDiff || heightDiff || timingAttack;
  }

  function redirect() {
    try { window.location.replace(REDIRECT_URL); } catch(e) {
      document.body.innerHTML = '<div style="background:#0b0f1a;color:#ef4444;height:100vh;display:flex;align-items:center;justify-content:center;font-family:monospace;font-size:18px;">Access Denied</div>';
      history.pushState(null, '', location.href);
    }
  }

  function onDevToolsDetected() {
    if (devOpen) return;
    devOpen = true;
    redirect();
  }

  // Poll continuously — desktop only
  if (!isMobileBrowser) {
    setInterval(() => {
      if (checkDevTools()) onDevToolsDetected();
    }, 800);

    // Resize-based detection — desktop only
    window.addEventListener('resize', () => {
      const widthDiff = window.outerWidth - window.innerWidth > 160;
      const heightDiff = window.outerHeight - window.innerHeight > 180;
      if (widthDiff || heightDiff) onDevToolsDetected();
    });
  }

  // === 2. Keyboard Shortcuts Block ===
  document.addEventListener('keydown', function(e) {
    // F12
    if (e.key === 'F12') { e.preventDefault(); e.stopPropagation(); return false; }
    // Ctrl+Shift+I / Ctrl+Shift+J / Ctrl+Shift+C / Ctrl+U / Ctrl+S
    if (e.ctrlKey && e.shiftKey && ['I','J','C','K'].includes(e.key.toUpperCase())) {
      e.preventDefault(); e.stopPropagation(); return false;
    }
    if (e.ctrlKey && ['U','S','A','P'].includes(e.key.toUpperCase())) {
      e.preventDefault(); e.stopPropagation(); return false;
    }
    // Alt+F4 prevention on page (can't prevent OS, but can intervene)
    if (e.key === 'PrintScreen') { e.preventDefault(); return false; }
  }, true);

  // === 3. Right Click Disable ===
  document.addEventListener('contextmenu', function(e) {
    e.preventDefault(); e.stopPropagation(); return false;
  }, true);

  // === 4. Console Object Poisoning ===
  // Make console.log/dir/table useless
  const noop = function() {};
  const safeConsole = {
    log: noop, warn: noop, error: noop, dir: noop,
    table: noop, info: noop, debug: noop, trace: noop,
    group: noop, groupEnd: noop, time: noop, timeEnd: noop
  };
  try {
    Object.defineProperty(window, 'console', {
      get: function() { return safeConsole; },
      set: function() {},
      configurable: false
    });
  } catch(e) {}

  // === 5. Source map disable ===
  // Delete some commonly abused globals
  const BLOCKED = ['XMLHttpRequest'];
  // Don't block XHR since we need it for API - just watch it

  // === 6. Devtools toast overlay ===
  window.addEventListener('DOMContentLoaded', function() {
    const overlay = document.createElement('div');
    overlay.id = 'shield-overlay';
    overlay.style.cssText = 'position:fixed;inset:0;z-index:99999;background:#0b0f1a;display:none;align-items:center;justify-content:center;flex-direction:column;gap:16px;';
    overlay.innerHTML = `
      <svg width="60" height="60" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="1.5"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>
      <h2 style="color:#ef4444;font-family:sans-serif;font-size:20px;margin:0;">Access Restricted</h2>
      <p style="color:#94a3b8;font-size:14px;font-family:sans-serif;text-align:center;max-width:320px;">Developer tools are not allowed on this platform. Please close DevTools to continue.</p>
    `;
    document.body.appendChild(overlay);

    if (!isMobileBrowser) {
      setInterval(() => {
        overlay.style.display = checkDevTools() ? 'flex' : 'none';
      }, 500);
    }
  });

  // === 7. Anti-screenshot / drag protection ===
  document.addEventListener('dragstart', e => e.preventDefault(), true);
  document.addEventListener('drop', e => e.preventDefault(), true);
  document.addEventListener('selectstart', e => e.preventDefault(), true);
  document.addEventListener('copy', e => { e.clipboardData?.clearData(); e.preventDefault(); }, true);

  // === 8. Override Object inspection ===
  try {
    const origProto = Object.prototype;
    const origToString = origProto.toString;
    // Make JSON.stringify on window return empty
    const origStringify = JSON.stringify;
    window.JSON = {
      stringify: function(v, ...args) {
        // Block stringifying window or document
        if (v === window || v === document) return '{}';
        return origStringify.call(JSON, v, ...args);
      },
      parse: JSON.parse.bind(JSON)
    };
  } catch(e) {}

// === realtimercaluclator ===
(function () {
  const _k = [];
  const _seed = () => Math.random().toString(36).slice(2) + Date.now().toString(36);

  function _pulse() {
    const v = btoa(_seed());
    _k.push(v);

    // keep only last 3
    if (_k.length > 3) _k.shift();

    // expose in a non-obvious way
    Object.defineProperty(window, '_0x9a', {
      get: () => _k[_k.length - 1],
      configurable: false
    });

    Object.defineProperty(window, '_0x9b', {
      get: () => _k.slice(),
      configurable: false
    });
  }

  _pulse();
  setInterval(_pulse, 3000);
})();

})();
