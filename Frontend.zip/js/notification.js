/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║              SolveMCQ  –  Notification Content               ║
 * ║                                                              ║
 * ║  Edit NOTIFICATION_TEXT to change what the bar says.        ║
 * ║  Toggle visibility from js/config.js:                       ║
 * ║    NOTIFICATION = "ON_N1"   → show notification #1          ║
 * ║    NOTIFICATION = "OFF_N1"  → hide  notification #1         ║
 * ║                                                              ║
 * ║  Bump the Nxx number whenever you want the bar to re-appear ║
 * ║  for users who previously dismissed the old one.            ║
 * ╚══════════════════════════════════════════════════════════════╝
 */

const NOTIFICATION_TEXT = 'Thanks for your patience. The Best Stable Version v8.26 is Live Now. Enjoy Solving Uninterrupted till INICET MAY 2026. Any issue , contact us. Thank You !';
