/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║              SolveMCQ  –  WebView Guard  v2.0                ║
 * ║                                                              ║
 * ║  Detects when the site is opened inside an in-app WebView   ║
 * ║  (WhatsApp, Telegram, Instagram, Facebook, etc.) and shows  ║
 * ║  a full-screen overlay instructing the user to open the     ║
 * ║  site in a real browser instead.                            ║
 * ║                                                              ║
 * ║  Why: In-app WebViews block cookies, OAuth popups, and      ║
 * ║  network requests in ways that cause sign-in / sign-up /    ║
 * ║  OTP to fail with "Load failed" errors.                     ║
 * ║                                                              ║
 * ║  Detection covers:                                           ║
 * ║    Android  — Explicit "; wv)" token (stable even after     ║
 * ║               Android 16 UA reduction — Google confirmed    ║
 * ║               wv token is preserved)                         ║
 * ║               OR known in-app UA tokens                      ║
 * ║               OR any Android UA not from a known safe        ║
 * ║               standalone browser                             ║
 * ║                                                              ║
 * ║    iOS      — Three-layer check:                             ║
 * ║      1. Known in-app UA tokens (WhatsApp, Instagram, etc.)  ║
 * ║      2. navigator.standalone === undefined (WKWebView lacks  ║
 * ║         this property; real Safari always defines it)        ║
 * ║      3. Bare WKWebView UA: no "Safari/" token               ║
 * ║                                                              ║
 * ║    iPadOS   — CRITICAL FIX: iPadOS 13+ reports              ║
 * ║      platform="MacIntel", NOT "iPad", so "iPad" is absent   ║
 * ║      from the UA string. Detection now uses                  ║
 * ║      navigator.maxTouchPoints > 1 on MacIntel to correctly  ║
 * ║      identify all modern iPad generations.                   ║
 * ║                                                              ║
 * ║  No config needed — runs automatically on every page load.  ║
 * ║  Overlay cannot be dismissed; user must open a real browser. ║
 * ╚══════════════════════════════════════════════════════════════╝
 */

(function () {
  'use strict';

  /* ── WebView detection ──────────────────────────────────────────────────── */
  function isWebView() {
    var ua       = navigator.userAgent || '';
    var uaLower  = ua.toLowerCase();
    var platform = navigator.platform || '';

    // ── Android ──────────────────────────────────────────────────────────────
    // The Android WebView appends "; wv)" to the UA string.
    // Google confirmed the wv token is preserved even after Android 16
    // UA-reduction (only device model / OS build info gets frozen).
    if (/android/i.test(uaLower)) {

      // 1. Explicit WebView token — most reliable signal
      //    Reduced UA example: Mozilla/5.0 (Linux; Android 10; K; wv) ...
      if (/;\s*wv\)/i.test(ua)) return true;

      // 2. Known in-app browser UA tokens for Android
      if (/FBAN|FBAV|Instagram|WhatsApp|Telegram|Twitter\/|LinkedInApp|Snapchat|Line\/|GSA\/|Musical\.ly|TikTok/i.test(ua)) return true;

      // 3. Any Android UA that is NOT a known safe standalone browser
      var safeBrowsers = /Chrome\/|Firefox\/|EdgA\/|SamsungBrowser\/|OPR\/|Opera\/|DuckDuckGo\/|Brave\//i;
      if (!safeBrowsers.test(ua)) return true;

      return false;
    }

    // ── iOS / iPadOS ──────────────────────────────────────────────────────────
    //
    // CRITICAL FIX — iPadOS 13+ reports platform="MacIntel", NOT "iPad".
    // The old check `/iPhone|iPad|iPod/i.test(ua)` completely misses iPads
    // running iPadOS 13 and above because "iPad" no longer appears in the UA.
    //
    // Correct three-part iOS/iPadOS detection:
    //   1. UA contains "iphone" or "ipod" — iPhones (all versions still do this)
    //   2. UA contains "ipad" — iPad running iPadOS 12 or earlier
    //   3. platform === "MacIntel" AND maxTouchPoints > 1 — iPad running iPadOS 13+
    //      (real Macs always return maxTouchPoints = 0)

    var isIOS = (
      /iphone|ipod/i.test(uaLower) ||
      /ipad/i.test(uaLower) ||
      (platform === 'MacIntel' && navigator.maxTouchPoints > 1)
    );

    if (isIOS) {

      // 1. Known in-app browser UA tokens — guaranteed WKWebView
      if (/WhatsApp\/|Telegram|FBAN|FBAV|Instagram|Twitter\/|LinkedInApp|Snapchat|Line\/|GSA\/|Musical\.ly|TikTok/i.test(ua)) {
        return true;
      }

      // 2. navigator.standalone — strongest generic WebView signal.
      //    Real Safari (and Chrome/Firefox on iOS) always define this property.
      //    WKWebView embedded in a third-party app does NOT define it.
      //      standalone === false     → normal Safari tab
      //      standalone === true      → installed as home-screen PWA
      //      standalone === undefined → WKWebView (in-app browser)
      if (typeof navigator.standalone === 'undefined') return true;

      // 3. Bare WKWebView UA fallback — real Safari always includes "Safari/".
      //    Some apps strip it when they customise the WKWebView user-agent.
      if (!/Safari\//i.test(ua)) return true;

      return false;
    }

    return false;
  }

  if (!isWebView()) return; // Not a WebView — do nothing, app loads normally

  /* ── Inject overlay CSS ─────────────────────────────────────────────────── */
  var style = document.createElement('style');
  style.textContent = [
    /* Overlay container */
    '#wv-guard{',
      'position:fixed;inset:0;',
      'z-index:2147483647;',
      'background:rgba(7,12,30,0.93);',
      'backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px);',
      'display:flex;flex-direction:column;',
      'align-items:center;justify-content:center;',
      'font-family:"DM Sans","Helvetica Neue",Arial,sans-serif;',
      'padding:28px 24px;box-sizing:border-box;',
      'text-align:center;',
      '-webkit-tap-highlight-color:transparent;',
    '}',

    /* Card */
    '#wv-guard-card{',
      'background:rgba(255,255,255,0.06);',
      'border:1px solid rgba(255,255,255,0.13);',
      'border-radius:20px;',
      'padding:36px 28px 32px;',
      'max-width:380px;width:100%;',
      'box-shadow:0 24px 64px rgba(0,0,0,0.55);',
    '}',

    /* Warning icon ring */
    '#wv-guard-icon{',
      'width:64px;height:64px;',
      'border-radius:50%;',
      'background:rgba(239,68,68,0.15);',
      'border:2px solid rgba(239,68,68,0.45);',
      'display:flex;align-items:center;justify-content:center;',
      'margin:0 auto 22px;',
      'font-size:28px;line-height:1;',
      'animation:wvPulse 2.4s ease-in-out infinite;',
    '}',

    '@keyframes wvPulse{',
      '0%,100%{box-shadow:0 0 0 0 rgba(239,68,68,0.3);}',
      '50%{box-shadow:0 0 0 10px rgba(239,68,68,0);}',
    '}',

    /* Heading */
    '#wv-guard h2{',
      'font-family:"Syne","DM Sans","Helvetica Neue",sans-serif;',
      'font-size:19px;font-weight:800;',
      'color:#f1f5f9;',
      'margin:0 0 10px;',
      'line-height:1.25;',
    '}',

    /* Body text */
    '#wv-guard p{',
      'font-size:13.5px;line-height:1.65;',
      'color:rgba(203,213,225,0.85);',
      'margin:0 0 22px;',
    '}',

    /* Step list */
    '#wv-guard ol{',
      'list-style:none;padding:0;margin:0 0 24px;',
      'text-align:left;',
    '}',
    '#wv-guard ol li{',
      'display:flex;align-items:flex-start;gap:10px;',
      'font-size:13px;line-height:1.55;',
      'color:rgba(203,213,225,0.9);',
      'padding:7px 0;',
      'border-bottom:1px solid rgba(255,255,255,0.06);',
    '}',
    '#wv-guard ol li:last-child{border-bottom:none;}',

    /* Step number badge */
    '#wv-guard .wv-step-num{',
      'flex-shrink:0;',
      'width:22px;height:22px;',
      'border-radius:50%;',
      'background:rgba(37,99,235,0.75);',
      'color:#fff;',
      'font-size:11px;font-weight:700;',
      'display:flex;align-items:center;justify-content:center;',
      'margin-top:1px;',
    '}',

    /* URL pill */
    '#wv-guard-url{',
      'display:inline-block;',
      'background:rgba(37,99,235,0.18);',
      'border:1px solid rgba(37,99,235,0.4);',
      'border-radius:8px;',
      'padding:8px 16px;',
      'font-size:13px;font-weight:600;',
      'color:#93c5fd;',
      'letter-spacing:0.01em;',
      'word-break:break-all;',
      'margin-top:4px;',
    '}',

    /* Footer note */
    '#wv-guard-note{',
      'margin-top:20px;',
      'font-size:11.5px;',
      'color:rgba(148,163,184,0.6);',
      'line-height:1.5;',
    '}',
  ].join('');
  document.head.appendChild(style);

  /* ── Build overlay HTML ─────────────────────────────────────────────────── */
  var origin = window.location.hostname || 'our website';

  var overlay = document.createElement('div');
  overlay.id = 'wv-guard';
  overlay.setAttribute('role', 'alertdialog');
  overlay.setAttribute('aria-modal', 'true');
  overlay.setAttribute('aria-label', 'Please open in a browser');

  overlay.innerHTML = [
    '<div id="wv-guard-card">',

      '<div id="wv-guard-icon">⚠️</div>',

      '<h2>Open in a Browser to Continue</h2>',

      '<p>',
        'You\'re viewing this page inside an <strong style="color:#fca5a5;">in-app browser</strong>. ',
        'Sign in, Sign up, and other features <strong style="color:#fca5a5;">will not work here</strong> due to security restrictions.',
      '</p>',

      '<ol>',
        '<li>',
          '<span class="wv-step-num">1</span>',
          '<span>Tap the <strong style="color:#e2e8f0;">⋯ menu</strong> or <strong style="color:#e2e8f0;">⋮ menu</strong> in the top-right corner of this screen</span>',
        '</li>',
        '<li>',
          '<span class="wv-step-num">2</span>',
          '<span>Choose <strong style="color:#e2e8f0;">"Open in Chrome"</strong>, <strong style="color:#e2e8f0;">"Open in Safari"</strong>, or your preferred browser app</span>',
        '</li>',
        '<li>',
          '<span class="wv-step-num">3</span>',
          '<span>Or copy the address below and paste it in your browser — everything will work perfectly</span>',
        '</li>',
      '</ol>',

      '<div id="wv-guard-url">', origin, '</div>',

      '<p id="wv-guard-note">',
        'Do not open links directly by tapping from WhatsApp, Telegram, Instagram, or any other app.',
      '</p>',

    '</div>',
  ].join('');

  /* ── Mount overlay as early as possible ────────────────────────────────── */
  function mount() {
    if (document.body) {
      document.body.appendChild(overlay);
    } else {
      document.addEventListener('DOMContentLoaded', function () {
        document.body.appendChild(overlay);
      });
    }
  }

  mount();

  /* ── Block scroll on body so nothing underneath shifts ─────────────────── */
  document.documentElement.style.overflow = 'hidden';
  document.body && (document.body.style.overflow = 'hidden');
  document.addEventListener('DOMContentLoaded', function () {
    document.body.style.overflow = 'hidden';
  });

})();
