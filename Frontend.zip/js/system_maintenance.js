/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║              System Maintenance Overlay                      ║
 * ║                                                              ║
 * ║  Reads from config.js (must be loaded before this script):  ║
 * ║                                                              ║
 * ║  SYS_MAINTAIN_STATUS   "ON"  → maintenance mode is armed.   ║
 * ║                         Overlay shows once the IST clock    ║
 * ║                         reaches MAINTENANCE_START_IST.      ║
 * ║                        "OFF" → does nothing, always.        ║
 * ║                                                              ║
 * ║  MAINTENANCE_START_IST  "YYYY-MM-DD HH:MM" in IST (24-hr). ║
 * ║                         Visitors before this time see the   ║
 * ║                         app normally; at/after it they see  ║
 * ║                         the maintenance overlay.            ║
 * ║                                                              ║
 * ║  No backend call is made. Pure front-end, pure CSS/HTML.    ║
 * ╚══════════════════════════════════════════════════════════════╝
 */
(function () {
  'use strict';

  /* ── 1. Check master switch ────────────────────────────────────────── */
  if (
    typeof SYS_MAINTAIN_STATUS === 'undefined' ||
    String(SYS_MAINTAIN_STATUS).trim().toUpperCase() !== 'ON'
  ) {
    return; // maintenance mode is OFF — do nothing
  }

  /* ── 2. Parse MAINTENANCE_START_IST and compare to current IST time ── */
  (function checkSchedule() {
    var startStr = (typeof MAINTENANCE_START_IST !== 'undefined')
      ? String(MAINTENANCE_START_IST).trim()
      : '2000-01-01 00:00'; // fallback: activate immediately

    // Parse "YYYY-MM-DD HH:MM"
    var parts = startStr.match(/^(\d{4})-(\d{2})-(\d{2})\s+(\d{2}):(\d{2})$/);
    if (!parts) {
      // Malformed string — fail safe: do NOT show maintenance
      console.warn('[Maintenance] MAINTENANCE_START_IST format invalid. Expected "YYYY-MM-DD HH:MM". Got: ' + startStr);
      return;
    }

    // Build a UTC timestamp for the given IST time.
    // IST = UTC+5:30, so IST midnight = UTC 18:30 the previous day.
    // We use Date.UTC and subtract 5h30m (= 19800000 ms) to convert IST → UTC.
    var scheduledUTC = Date.UTC(
      parseInt(parts[1], 10),   // year
      parseInt(parts[2], 10) - 1, // month (0-based)
      parseInt(parts[3], 10),   // day
      parseInt(parts[4], 10),   // hour (IST)
      parseInt(parts[5], 10)    // minute (IST)
    ) - 19800000; // subtract IST offset (5h 30m in ms)

    var nowUTC = Date.now();

    if (nowUTC < scheduledUTC) {
      // Not yet time — do nothing. App loads normally.
      return;
    }
    // Current time is at or past the scheduled IST start — show overlay.
    showOverlay();
  })();

  /* ── 3. Build and mount the maintenance overlay ────────────────────── */

  function showOverlay() {
  /* ── Inject styles ────────────────────────────────────────────────── */
  var style = document.createElement('style');
  style.textContent = [
    '#sys-maintain-overlay{',
      'position:fixed;inset:0;z-index:2147483647;',
      'background:#0b0f1a;',
      'display:flex;flex-direction:column;',
      'align-items:center;justify-content:center;',
      'font-family:"DM Sans","Helvetica Neue",Arial,sans-serif;',
      'padding:24px;box-sizing:border-box;',
      'user-select:none;',
    '}',

    /* gear wrapper */
    '#sys-maintain-gears{',
      'position:relative;width:120px;height:100px;',
      'margin-bottom:36px;flex-shrink:0;',
    '}',

    /* shared gear styles */
    '.sm-gear{',
      'position:absolute;',
      'border-radius:50%;',
    '}',

    /* large gear — left */
    '.sm-gear-big{',
      'width:80px;height:80px;',
      'top:10px;left:0;',
      'animation:smGearCW 3s linear infinite;',
    '}',

    /* small gear — right, counter-rotates */
    '.sm-gear-small{',
      'width:52px;height:52px;',
      'top:24px;left:54px;',
      'animation:smGearCCW 3s linear infinite;',
    '}',

    '@keyframes smGearCW{to{transform:rotate(360deg)}}',
    '@keyframes smGearCCW{to{transform:rotate(-360deg)}}',

    /* heading */
    '#sys-maintain-title{',
      'font-size:clamp(20px,5vw,28px);',
      'font-weight:700;',
      'color:#f1f5f9;',
      'letter-spacing:-0.02em;',
      'margin:0 0 14px;',
      'text-align:center;',
    '}',

    /* sub-text */
    '#sys-maintain-msg{',
      'font-size:clamp(13px,3.5vw,15px);',
      'font-weight:400;',
      'color:rgba(255,255,255,0.45);',
      'line-height:1.65;',
      'text-align:center;',
      'max-width:340px;',
      'margin:0;',
    '}',

    /* pulsing dot strip */
    '#sys-maintain-dots{',
      'display:flex;gap:8px;margin-top:32px;',
    '}',
    '.sm-dot{',
      'width:8px;height:8px;border-radius:50%;',
      'background:rgba(255,255,255,0.25);',
      'animation:smDotPulse 1.4s ease-in-out infinite;',
    '}',
    '.sm-dot:nth-child(2){animation-delay:0.2s}',
    '.sm-dot:nth-child(3){animation-delay:0.4s}',
    '@keyframes smDotPulse{',
      '0%,80%,100%{transform:scale(1);background:rgba(255,255,255,0.2)}',
      '40%{transform:scale(1.4);background:rgba(255,255,255,0.7)}',
    '}',
  ].join('');
  document.head.appendChild(style);

  /* ── Build gear SVG helper ────────────────────────────────────────── */
  function gearSVG(size, teeth, color) {
    var r      = size / 2;            // outer radius
    var ri     = r * 0.62;            // inner radius (circle hole edge)
    var hole   = r * 0.28;            // center hole
    var tDepth = r * 0.18;            // tooth depth
    var tW     = (2 * Math.PI * r) / (teeth * 3.2); // tooth arc width

    var pathD = [];
    for (var i = 0; i < teeth; i++) {
      var angle = (i / teeth) * 2 * Math.PI - Math.PI / 2;
      var a1 = angle - tW / r;
      var a2 = angle + tW / r;
      var a3 = angle + tW / r + 0.08;
      var a4 = angle + (1 / teeth) * 2 * Math.PI - tW / r - 0.08;

      // inner arc point before tooth
      pathD.push(
        (i === 0 ? 'M' : 'L') +
        (r + ri * Math.cos(a1)).toFixed(2) + ',' +
        (r + ri * Math.sin(a1)).toFixed(2)
      );
      // outer tooth edge left
      pathD.push(
        'L' + (r + (ri + tDepth) * Math.cos(a1)).toFixed(2) + ',' +
              (r + (ri + tDepth) * Math.sin(a1)).toFixed(2)
      );
      // outer tooth edge right
      pathD.push(
        'L' + (r + (ri + tDepth) * Math.cos(a2)).toFixed(2) + ',' +
              (r + (ri + tDepth) * Math.sin(a2)).toFixed(2)
      );
      // back to inner after tooth
      pathD.push(
        'L' + (r + ri * Math.cos(a2)).toFixed(2) + ',' +
              (r + ri * Math.sin(a2)).toFixed(2)
      );
      // inner arc to next tooth (approximated with line for simplicity)
      if (a4 > a3) {
        pathD.push(
          'A' + ri.toFixed(2) + ',' + ri.toFixed(2) +
          ' 0 0 1 ' +
          (r + ri * Math.cos(a4)).toFixed(2) + ',' +
          (r + ri * Math.sin(a4)).toFixed(2)
        );
      }
    }
    pathD.push('Z');

    // Centre hole (cut-out)
    var holePath = [
      'M', (r + hole).toFixed(2), r.toFixed(2),
      'A', hole.toFixed(2), hole.toFixed(2), '0 1 0',
      (r - hole).toFixed(2), r.toFixed(2),
      'A', hole.toFixed(2), hole.toFixed(2), '0 1 0',
      (r + hole).toFixed(2), r.toFixed(2),
      'Z'
    ].join(' ');

    var svg =
      '<svg xmlns="http://www.w3.org/2000/svg"' +
      ' width="' + size + '" height="' + size + '"' +
      ' viewBox="0 0 ' + size + ' ' + size + '">' +
      '<path fill="' + color + '" fill-rule="evenodd"' +
      ' d="' + pathD.join(' ') + ' ' + holePath + '"/>' +
      '</svg>';

    return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  }

  /* ── Build overlay DOM ────────────────────────────────────────────── */
  var overlay = document.createElement('div');
  overlay.id = 'sys-maintain-overlay';
  overlay.setAttribute('role', 'alert');
  overlay.setAttribute('aria-live', 'assertive');

  /* Gears container */
  var gearsWrap = document.createElement('div');
  gearsWrap.id = 'sys-maintain-gears';

  var bigGear = document.createElement('img');
  bigGear.className = 'sm-gear sm-gear-big';
  bigGear.src = gearSVG(80, 12, 'rgba(99,130,255,0.85)');
  bigGear.alt = '';
  bigGear.setAttribute('aria-hidden', 'true');

  var smallGear = document.createElement('img');
  smallGear.className = 'sm-gear sm-gear-small';
  smallGear.src = gearSVG(52, 8, 'rgba(148,100,255,0.80)');
  smallGear.alt = '';
  smallGear.setAttribute('aria-hidden', 'true');

  gearsWrap.appendChild(bigGear);
  gearsWrap.appendChild(smallGear);

  /* Title */
  var title = document.createElement('h1');
  title.id = 'sys-maintain-title';
  title.textContent = 'System Under Maintenance';

  /* Message */
  var msg = document.createElement('p');
  msg.id = 'sys-maintain-msg';
  var eta = (typeof MAINTENANCE_ETA_IST !== 'undefined' && String(MAINTENANCE_ETA_IST).trim())
    ? String(MAINTENANCE_ETA_IST).trim()
    : null;
  msg.textContent =
    'We\u2019re upgrading our systems to serve you better. ' +
    'Please check back shortly.' +
    (eta ? ' Estimated Completion Time : ' + eta : '');

  /* Animated dots */
  var dots = document.createElement('div');
  dots.id = 'sys-maintain-dots';
  for (var d = 0; d < 3; d++) {
    var dot = document.createElement('span');
    dot.className = 'sm-dot';
    dots.appendChild(dot);
  }

  overlay.appendChild(gearsWrap);
  overlay.appendChild(title);
  overlay.appendChild(msg);
  overlay.appendChild(dots);

  /* ── Mount as early as possible ──────────────────────────────────── */
  function mount() {
    if (!document.body) {
      // body not yet parsed — wait for it
      document.addEventListener('DOMContentLoaded', function () {
        document.body.appendChild(overlay);
        // Freeze scroll on body
        document.body.style.overflow = 'hidden';
      });
    } else {
      document.body.appendChild(overlay);
      document.body.style.overflow = 'hidden';
    }
  }
  mount();

  /* ── Auto-reload when maintenance is lifted ──────────────────────── */
  // Poll config.js every 15 seconds. When the server redeploys with
  // SYS_MAINTAIN_STATUS = "OFF", the fetched config will no longer
  // contain the "ON" marker and we reload — the maintenance overlay
  // never mounts on the fresh page load.
  (function startPolling() {
    var POLL_INTERVAL = 15000; // ms between checks
    var configUrl = (function () {
      // Find the <script src="...config.js..."> tag to get the exact URL
      // (works even when the page uses cache-busted filenames like config.js?v=42)
      var scripts = document.querySelectorAll('script[src]');
      for (var i = 0; i < scripts.length; i++) {
        if (/config\.js/.test(scripts[i].src)) return scripts[i].src;
      }
      return 'js/config.js'; // fallback relative path
    })();

    function checkIfMaintenanceLifted() {
      var xhr = new XMLHttpRequest();
      // Add a timestamp to bust the browser cache
      var bustUrl = configUrl + (configUrl.indexOf('?') >= 0 ? '&' : '?') + '_t=' + Date.now();
      xhr.open('GET', bustUrl, true);
      xhr.timeout = 8000;
      xhr.onload = function () {
        if (xhr.status >= 200 && xhr.status < 300) {
          // If the response no longer contains SYS_MAINTAIN_STATUS = "ON"
          // (case-insensitive, whitespace-tolerant) the overlay should drop
          var body = xhr.responseText || '';
          var stillOn = /SYS_MAINTAIN_STATUS\s*=\s*["']ON["']/i.test(body);
          if (!stillOn) {
            // Maintenance is over — hard reload to show the real site
            window.location.reload(true);
          }
        }
        // On any error / non-200 we just wait for the next tick
      };
      xhr.onerror   = function () { /* network down — retry next tick */ };
      xhr.ontimeout = function () { /* server slow  — retry next tick */ };
      xhr.send();
    }

    // Start polling after the first interval so we don't fire immediately
    setInterval(checkIfMaintenanceLifted, POLL_INTERVAL);
  })();

  } // end showOverlay()

})();
