/**
 * API Client
 * Security model:
 *   • JWT lives in httpOnly cookie (set by server) — never touched by JS
 *   • userId/email/name stored in localStorage (non-secret display info only)
 *   • Every request signed with HMAC-SHA256 using a per-session key
 *   • Session key rotated every N requests or every 45s
 *   • x-next-key header delivers the next (encrypted) key in responses
 */
const API = (function () {
  'use strict';

  const BASE = API_BASE_URL;

  // Non-secret display info only (no token stored in localStorage)
  const USER_KEY  = 'smcq_user';
  const EMAIL_KEY = 'smcq_email';
  const NAME_KEY  = 'smcq_name';
  const PHONE_KEY = 'smcq_phone';

  // ── In-memory signing state (never persisted) ──────────────────────────
  // These are wiped when the page is closed/refreshed — restored on validateSession.
  let _sessionId  = null;   // identifies which key slot on the server
  let _sessionKey = null;   // hex-encoded 32-byte key for HMAC signing

  // ── User identity helpers (display only, safe in localStorage) ──────────
  function setUserInfo(userId, email, name, phone) {
    if (userId !== undefined) localStorage.setItem(USER_KEY, userId || '');
    if (email  !== undefined) localStorage.setItem(EMAIL_KEY, email  || '');
    if (name   !== undefined) localStorage.setItem(NAME_KEY,  name   || '');
    if (phone  !== undefined) localStorage.setItem(PHONE_KEY, phone  || '');
  }
  function clearUserInfo() {
    localStorage.removeItem(USER_KEY);
    localStorage.removeItem(EMAIL_KEY);
    localStorage.removeItem(NAME_KEY);
    localStorage.removeItem(PHONE_KEY);
  }

  // Legacy compat shims (app.js calls these)
  function setToken(_t, userId, email, name, phone) {
    // Token is now httpOnly cookie — we never store it in JS.
    // Just update display info.
    setUserInfo(userId, email, name, phone);
  }
  function getToken()       { return null; }  // cookie is inaccessible from JS by design
  function clearToken()     { _sessionId = null; _sessionKey = null; clearUserInfo(); }
  function getSavedUser()   { return localStorage.getItem(USER_KEY); }
  function getSavedToken()  { return null; }  // cookie is httpOnly
  function getSavedEmail()  { return localStorage.getItem(EMAIL_KEY); }
  function getSavedName()   { return localStorage.getItem(NAME_KEY)  || ''; }
  function getSavedPhone()  { return localStorage.getItem(PHONE_KEY) || ''; }

  // ── Session key management ─────────────────────────────────────────────
  function applySessionKey(sessionId, sessionKey) {
    _sessionId  = sessionId  || null;
    _sessionKey = sessionKey || null;
  }

  /**
   * Decrypt the x-next-key header value delivered by the server after rotation.
   * Server uses AES-128-GCM with a key derived from JWT_SECRET.
   * We DON'T have JWT_SECRET in the browser — the server sends a client-usable
   * format: the new raw hex key XOR-obfuscated with a per-response nonce.
   *
   * Actually the server sends the raw new key encrypted with AES-128-GCM.
   * The browser cannot decrypt AES-128-GCM without the wrap key.
   * Solution: server sends the new key encrypted with the CURRENT session key
   * (which the browser already has). Format: iv(24 hex) + tag(32 hex) + ct.
   */
  async function decryptNextKey(blob) {
    if (!_sessionKey || !blob) return null;
    try {
      const raw    = Uint8Array.from(blob.match(/../g).map(b => parseInt(b, 16)));
      const iv     = raw.slice(0, 12);
      const tag    = raw.slice(12, 28);
      const ct     = raw.slice(28);
      const taggedCt = new Uint8Array([...ct, ...tag]);
      const keyBuf = Uint8Array.from(_sessionKey.match(/../g).map(b => parseInt(b, 16)));
      const cryptoKey = await crypto.subtle.importKey('raw', keyBuf, { name: 'AES-GCM' }, false, ['decrypt']);
      const plain  = await crypto.subtle.decrypt({ name: 'AES-GCM', iv, tagLength: 128 }, cryptoKey, taggedCt);
      return Array.from(new Uint8Array(plain)).map(b => b.toString(16).padStart(2, '0')).join('');
    } catch { return null; }
  }

  // ── HMAC signing ─────────────────────────────────────────────────────────
  async function signRequest(method, path, bodyStr) {
    if (!_sessionKey || !_sessionId) return null;
    const ts    = String(Date.now());
    const nonce = Array.from(crypto.getRandomValues(new Uint8Array(16)))
                    .map(b => b.toString(16).padStart(2, '0')).join('');
    const msg   = [method.toUpperCase(), path, bodyStr || '', ts, nonce].join('\n');
    const keyBuf = Uint8Array.from(_sessionKey.match(/../g).map(b => parseInt(b, 16)));
    const cryptoKey = await crypto.subtle.importKey(
      'raw', keyBuf, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']
    );
    const sigBuf = await crypto.subtle.sign('HMAC', cryptoKey, new TextEncoder().encode(msg));
    const sign   = Array.from(new Uint8Array(sigBuf)).map(b => b.toString(16).padStart(2, '0')).join('');
    return { ts, nonce, sign };
  }

  // ── Core request function ─────────────────────────────────────────────────
  async function request(method, path, body = null, timeoutMs = 15000, signal = null) {
    const headers = { 'Content-Type': 'application/json' };
    const bodyStr = body ? JSON.stringify(body) : null;

    // Add HMAC signature headers if we have a session key
    if (_sessionKey && _sessionId) {
      const sig = await signRequest(method, path, bodyStr || '');
      if (sig) {
        headers['x-session-id'] = _sessionId;
        headers['x-ts']         = sig.ts;
        headers['x-nonce']      = sig.nonce;
        headers['x-sign']       = sig.sign;
      }
    }

    const opts = { method, headers, credentials: 'include' };  // credentials:include sends the httpOnly cookie
    if (bodyStr) opts.body = bodyStr;

    // Combine per-request timeout with optional external abort signal
    const localCtrl = new AbortController();
    const timer = setTimeout(() => localCtrl.abort(), timeoutMs);
    if (signal) {
      if (signal.aborted) { clearTimeout(timer); throw new Error('Request cancelled.'); }
      signal.addEventListener('abort', function() { localCtrl.abort(); }, { once: true });
    }
    opts.signal = localCtrl.signal;

    try {
      const res = await fetch(BASE + path, opts);
      clearTimeout(timer);
      const data = await res.json();

      // ── Transparent key recovery after server restart / pm2 reload ──────
      // In-memory signing key store is wiped on every reload. When this happens
      // the server returns code:'KEY_MISSING'. We silently re-call validateSession
      // (cookie + DB session still valid) to get a fresh key, then retry once.
      if (!res.ok && data.code === 'KEY_MISSING' && path !== '/api/auth/validate') {
        try {
          const sessRes = await fetch(BASE + '/api/auth/validate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include'
          });
          const sessData = await sessRes.json();
          if (sessRes.ok && sessData.sessionId && sessData.sessionKey) {
            applySessionKey(sessData.sessionId, sessData.sessionKey);
            if (sessData.userId) setUserInfo(sessData.userId, sessData.email, sessData.name, sessData.phone);
            // Retry the original request once with the fresh key
            return request(method, path, body, timeoutMs, signal);
          }
        } catch { /* fall through to normal error if recovery fails */ }
      }

      if (!res.ok) throw new Error(data.error || 'Request failed');

      // Handle key rotation — server sends x-next-key when threshold is hit
      const nextKeyBlob = res.headers.get('x-next-key');
      if (nextKeyBlob && _sessionKey) {
        // Decrypt with current session key, apply new key
        const newKey = await decryptNextKey(nextKeyBlob);
        if (newKey) _sessionKey = newKey;
        // sessionId stays the same across rotation
      }

      return data;
    } catch (err) {
      clearTimeout(timer);
      if (err.name === 'AbortError') {
        if (signal && signal.aborted) throw new Error('Request cancelled.');
        throw new Error('Request timed out. Server may be starting up, please retry.');
      }
      throw err;
    }
  }
  // ── App config ───────────────────────────────────────────
  // Feature flags are now read directly from config.js constants
  // (FEATURE_PHONE_AUTH / FEATURE_LEGACY_LOGIN) — no backend round-trip needed.
  // The backend env vars (PHONE_SIGNUP_SIGNIN / LEGACY_LOGIN) still guard the
  // actual API routes; these flags only control UI visibility.
  async function getConfig() {
    const phoneAuth   = (typeof FEATURE_PHONE_AUTH   !== 'undefined')
      ? FEATURE_PHONE_AUTH.trim().toUpperCase()   !== 'OFF'
      : true;  // default ON if constant missing
    const legacyLogin = (typeof FEATURE_LEGACY_LOGIN !== 'undefined')
      ? FEATURE_LEGACY_LOGIN.trim().toUpperCase() !== 'OFF'
      : true;  // default ON if constant missing
    return { phoneAuth, legacyLogin };
  }

  // ── Auth ──────────────────────────────────────────────
  async function sendOTP(email, purpose) {
    return request('POST', '/api/auth/send-otp', { email, purpose });
  }

  async function verifyOTP(email, otp) {
    return request('POST', '/api/auth/verify-otp', { email, otp });
  }

  async function signup(email, otp, password, name) {
    const data = await request('POST', '/api/auth/signup', { email, otp, password, name });
        applySessionKey(data.sessionId, data.sessionKey);
    setUserInfo(data.userId, data.email, data.name);
    return data;
  }

  async function emailLogin(email, password) {
    const data = await request('POST', '/api/auth/login', { email, password });
        applySessionKey(data.sessionId, data.sessionKey);
    setUserInfo(data.userId, data.email, data.name);
    return data;
  }

  async function resetPassword(email, otp, newPassword) {
    return request('POST', '/api/auth/reset-password', { email, otp, newPassword });
  }

  // Legacy login (old applicationNo-based accounts)
  async function legacyLogin(applicationNo, password) {
    const data = await request('POST', '/api/auth/legacy-login', { applicationNo, password });
    if (!data.needsEmailMigration) {
      applySessionKey(data.sessionId, data.sessionKey);
      setUserInfo(data.userId, data.email, data.name || '');
    }
    return data;
  }

  // Complete migration: link email to legacy account
  async function migrateEmail(migrationToken, email, otp, password, name) {
    const data = await request('POST', '/api/auth/migrate-email', { migrationToken, email, otp, password, name });
        applySessionKey(data.sessionId, data.sessionKey);
    setUserInfo(data.userId, data.email, data.name || '');
    return data;
  }

  // ── Phone auth ────────────────────────────────────────────
  async function phoneSendOTP(phone, purpose) {
    return request('POST', '/api/auth/phone/send-otp', { phone, purpose });
  }

  async function phoneVerifyOTP(phone, otp) {
    return request('POST', '/api/auth/phone/verify-otp', { phone, otp });
  }

  async function phoneSignup(phone, otp, password, name) {
    const data = await request('POST', '/api/auth/phone/signup', { phone, otp, password, name });
        applySessionKey(data.sessionId, data.sessionKey);
    setUserInfo(data.userId, undefined, data.name, data.phone);
    return data;
  }

  async function phoneLogin(phone, password) {
    const data = await request('POST', '/api/auth/phone/login', { phone, password });
        applySessionKey(data.sessionId, data.sessionKey);
    setUserInfo(data.userId, undefined, data.name, data.phone);
    return data;
  }

  async function phoneResetPassword(phone, otp, newPassword) {
    return request('POST', '/api/auth/phone/reset-password', { phone, otp, newPassword });
  }

  async function getSubjects(signal) { return request('GET', '/api/subjects', null, 15000, signal); }
  async function getMainSubjects(signal) { return request('GET', '/api/main-subjects', null, 15000, signal); }

  /**
   * filter: 'all' | 'incorrect' | 'skipped'
   */
  async function createSession(subjKey, topicId, mode, filter = 'all') {
    return request('POST', '/api/session/create', { subjKey, topicId, mode, filter });
  }

  async function getQuestion(sessionId, index) {
    return request('GET', `/api/session/${sessionId}/question/${index}`);
  }

  async function getSectionQuestions(sessionId, secIndex) {
    return request('GET', `/api/session/${sessionId}/section/${secIndex}/questions`);
  }

  async function getSectionTimer(sessionId, secIndex) {
    return request('GET', `/api/session/${sessionId}/section/${secIndex}/timer`);
  }

  async function expireSection(sessionId, secIndex) {
    return request('POST', `/api/session/${sessionId}/section/${secIndex}/expire`);
  }

  async function submitAnswer(sessionId, index, selected) {
    return request('POST', `/api/session/${sessionId}/answer`, { index, selected });
  }

  async function finishSession(sessionId) {
    return request('POST', `/api/session/${sessionId}/finish`);
  }

  async function getProgress(signal) {
    return request('GET', '/api/user/progress', null, 15000, signal);
  }

  async function saveProgress(progress) {
    return request('POST', '/api/user/progress', { progress });
  }

  async function getResume(signal) {
    return request('GET', '/api/user/resume', null, 15000, signal);
  }

  async function saveResume(resume) {
    return request('POST', '/api/user/resume', { resume });
  }

  async function getLiveExam(signal) {
    return request('GET', '/api/user/live-exam', null, 15000, signal);
  }

  async function saveLiveExam(liveExam) {
    return request('POST', '/api/user/live-exam', { liveExam });
  }

  /** Get all topic stats for the current user */
  async function getTopicStats(signal) {
    return request('GET', '/api/user/topic-stats', null, 15000, signal);
  }

  /**
   * Save topic stats after finishing a session.
   * results: array of { globalIndex, isCorrect, skipped }
   */
  async function saveTopicStats(subjKey, topicId, results) {
    return request('POST', '/api/user/topic-stats', { subjKey, topicId, results });
  }

  /**
   * Get all test reviews for the current user (last submitted result per topic).
   */
  async function getTestReviews(signal) {
    return request('GET', '/api/user/test-reviews', null, 15000, signal);
  }

  /**
   * Called once on every app open / page load.
   * Sends the stored JWT to the server which verifies it AND checks the DB.
   * Returns { ok, userId, email, name, phone } on success, throws on 401.
   */
  async function validateSession(signal) {
    // ── Post-nuke bootstrap ────────────────────────────────────────────────
    // After a cache nuke (version bump), _sessionKey is wiped from memory.
    // request() only adds HMAC headers when _sessionKey is present, so the
    // first call goes out unsigned and the server rejects it — logging the
    // user out despite their cookie still being valid.
    //
    // Fix: if we have no session key yet, do one plain fetch to /api/auth/validate
    // (identical to what the KEY_MISSING recovery block does for other routes).
    // A successful response gives us the key; we then fall through to the normal
    // request() path below which will now include signed HMAC headers.
    if (!_sessionKey) {
      try {
        const localCtrl = new AbortController();
        const timer = setTimeout(() => localCtrl.abort(), 10000);
        if (signal) signal.addEventListener('abort', () => localCtrl.abort(), { once: true });
        const bootstrapRes = await fetch(BASE + '/api/auth/validate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          signal: localCtrl.signal,
        });
        clearTimeout(timer);
        const bootstrapData = await bootstrapRes.json();
        if (bootstrapRes.ok && bootstrapData.sessionId && bootstrapData.sessionKey) {
          applySessionKey(bootstrapData.sessionId, bootstrapData.sessionKey);
          setUserInfo(bootstrapData.userId, bootstrapData.email, bootstrapData.name, bootstrapData.phone);
          return bootstrapData;
        }
        // Server rejected the unsigned validate — session truly invalid
        if (!bootstrapRes.ok) throw new Error(bootstrapData.error || 'Session invalid');
      } catch (err) {
        if (err.name === 'AbortError') throw new Error('Request cancelled.');
        throw err;
      }
    }
    // Normal path — _sessionKey is present, request() will sign the call
    const data = await request('POST', '/api/auth/validate', null, 10000, signal);
    if (data.sessionId && data.sessionKey) {
      applySessionKey(data.sessionId, data.sessionKey);
      setUserInfo(data.userId, data.email, data.name, data.phone);
    }
    return data;
  }

  /**
   * Invalidates the session in the DB, then clears local storage.
   */
  async function logout() {
    try { await request('POST', '/api/auth/logout', null, 8000); } catch { /* best-effort */ }
    clearToken();    // clears _sessionId, _sessionKey, and localStorage display info
  }

  async function getDashboard(signal) {
    return request('GET', '/api/user/dashboard', null, 15000, signal);
  }

  /**
   * Save/overwrite the test review for a topic.
   * results: full array from finishSession response
   * score: score object from finishSession response
   * timeTaken: seconds from finishSession response
   */
  async function saveTestReview(subjKey, topicId, results, score, timeTaken, mode) {
    return request('POST', '/api/user/test-reviews', { subjKey, topicId, results, score, timeTaken, mode });
  }


  // ── OAuth social sign-in ─────────────────────────────────
  /**
   * Returns { providers: ['google','github', ...] } based on config.js flags.
   * No network call — visibility is controlled entirely by FEATURE_OAUTH_*
   * constants in config.js (same pattern as FEATURE_PHONE_AUTH).
   * The backend OAuth routes remain protected by the server's own env vars.
   */
  function getEnabledOAuthProviders() {
    const map = {
      google: (typeof FEATURE_OAUTH_GOOGLE !== 'undefined') ? FEATURE_OAUTH_GOOGLE : 'ON',
      github: (typeof FEATURE_OAUTH_GITHUB !== 'undefined') ? FEATURE_OAUTH_GITHUB : 'ON',
      apple:  (typeof FEATURE_OAUTH_APPLE  !== 'undefined') ? FEATURE_OAUTH_APPLE  : 'OFF',
    };
    const providers = Object.entries(map)
      .filter(([, v]) => v.trim().toUpperCase() !== 'OFF')
      .map(([k]) => k);
    return { providers };
  }

  async function getOAuthURL(provider) {
    return request('GET', `/api/auth/oauth/url/${provider}`);
  }

  /**
   * Returns true when running inside an environment where window.open() is
   * unreliable or blocked without a synchronous user gesture:
   *   • Android Chrome (popup blocker fires when open() is called after an
   *     async gap caused by the getOAuthURL fetch)
   *   • Android WebView / Chrome Custom Tabs (window.open always returns null)
   *   • Any standalone PWA on Android (display-mode: standalone strips opener)
   */
  function _shouldUseSameTab() {
    var ua = navigator.userAgent || '';

    // Android: window.open() is broken across the board — Chrome's popup blocker
    // fires after async gaps, WebView returns null, Custom Tabs strip opener.
    // Treat ALL Android as same-tab regardless of which app opened the link.
    if (/Android/i.test(ua)) return true;

    // iOS in-app WebViews: WKWebView blocks window.open() completely and
    // reports a Safari-like UA, so we can't detect it via OS alone.
    // Identify known in-app browsers by their injected UA tokens:
    //   Telegram iOS  → "Telegram"
    //   WhatsApp iOS  → "WhatsApp/"
    //   Instagram iOS → "Instagram"
    //   Facebook iOS  → "FBAN" or "FBAV"
    //   Twitter/X iOS → "Twitter"
    //   LinkedIn iOS  → "LinkedInApp"
    //   Snapchat iOS  → "Snapchat"
    //   Line iOS      → "Line/"
    //   Gmail/GSA iOS → "GSA/" (Google Search App, which Gmail links open in)
    // Any of these on iOS means WKWebView — skip popup, use same-tab.
    if (/iPhone|iPad|iPod/i.test(ua)) {
      if (/WhatsApp\/|Telegram|FBAN|FBAV|Instagram|Twitter\/|LinkedInApp|Snapchat|Line\/|GSA\//i.test(ua)) {
        return true;
      }
    }

    return false;
  }

  /**
   * Opens a popup for the given provider, waits for postMessage result,
   * stores the token, and returns { token, userId, name, email }.
   *
   * The callback lives on api.sharepremium.in (different origin from this
   * frontend). Two result-delivery paths:
   *   1. Popup flow (desktop / iOS)
   *        → callback page calls window.opener.postMessage(…)
   *   2. Same-tab redirect (Android, or when popup is blocked)
   *        → we open the popup window immediately (synchronous, inside the
   *          user-gesture frame), then navigate IT to the URL once fetched.
   *          If the window is null the main tab navigates instead.
   *        → callback page redirects to mcq.sharepremium.in/#oauth=<encoded>
   *          checkPendingOAuthResult() reads and clears the hash on load.
   *
   * Android fix: window.open() MUST be called synchronously inside the click
   * handler (user-gesture frame). Calling it after an await/fetch loses the
   * gesture context and Chrome blocks the popup silently, returning null.
   * Strategy: open a blank window immediately, then navigate it to the real
   * URL once the fetch completes. On Android we skip straight to same-tab.
   */
  // Written without async/await and using var/let (never const) for all
  // variables referenced inside closures. Safari on iPhone throws
  // "Cannot access uninitialized variable" (TDZ) when a const is read inside a
  // callback that executes before the const declaration is reached.
  function oauthLogin(provider) {
    return new Promise(function(resolve, reject) {

      // ── Determine strategy BEFORE any async work ─────────────────────────
      var useSameTab = _shouldUseSameTab();

      // On desktop/iOS: open a blank popup NOW (inside the user-gesture frame)
      // so the browser doesn't classify window.open() as a popup after the
      // async fetch below. We'll navigate it to the real URL once we have it.
      // On Android: skip the popup entirely — use same-tab redirect.
      var popup = null;
      if (!useSameTab) {
        popup = window.open('', 'oauth_popup', 'width=520,height=620,left=200,top=100');
        // If even the blank open was blocked (very rare), fall back to same-tab
        if (!popup) { useSameTab = true; }
      }

      // Declare ALL closure variables before any callbacks reference them
      var done = false;
      var msgHandler = null;
      var closeWatcher = null;

      function cleanup() {
        if (done) return;
        done = true;
        if (msgHandler) window.removeEventListener('message', msgHandler);
        if (closeWatcher) { clearInterval(closeWatcher); closeWatcher = null; }
        // Close the blank popup if we never navigated it (e.g. fetch failed)
        if (popup && !popup.closed) { try { popup.close(); } catch(_) {} }
      }

      function handleResult(p) {
        cleanup();
        if (p.error) { reject(new Error(p.error)); return; }
        // Token is now in httpOnly cookie (set by server in OAuth callback response)
        // Just apply the session key and store display info
        if (p.sessionId && p.sessionKey) applySessionKey(p.sessionId, p.sessionKey);
        if (p.userId || p.email || p.name !== undefined) {
          setUserInfo(p.userId, p.email, p.name, p.phone);
        }
        resolve(p);
      }

      msgHandler = function(e) {
        if (e.data && e.data.type === 'OAUTH_RESULT') {
          handleResult(e.data.payload);
        }
      };
      window.addEventListener('message', msgHandler);

      // Now fetch the real OAuth URL (async — gesture frame no longer matters
      // because window.open was already called above)
      getOAuthURL(provider).then(function(urlResult) {
        var url = urlResult && urlResult.url;
        if (!url) {
          cleanup();
          reject(new Error('Could not get auth URL. Check server config.'));
          return;
        }

        if (useSameTab) {
          // Android / popup-blocked path: navigate the main tab
          cleanup();
          window.location.href = url;
          return;
        }

        // Desktop / iOS path: navigate the already-open blank popup
        try {
          popup.location.href = url;
        } catch(_) {
          // Cross-origin write to popup.location failed (very unusual)
          cleanup();
          window.location.href = url;
          return;
        }

        // Detect popup closed without posting a message
        closeWatcher = setInterval(function() {
          if (popup && popup.closed) {
            clearInterval(closeWatcher);
            closeWatcher = null;
            setTimeout(function() {
              if (!done) { cleanup(); reject(new Error('Sign-in cancelled.')); }
            }, 700);
          }
        }, 500);

      }).catch(function(e) {
        cleanup();
        reject(e);
      });
    });
  }

  /**
   * Call once at app start (in init()).
   * Handles the same-tab redirect fallback: the callback page encodes the
   * result in the URL hash as #oauth=<urlencoded-JSON> and redirects here.
   * Returns the payload object or null.
   */
  function checkPendingOAuthResult() {
    try {
      const hash = window.location.hash;
      if (!hash.startsWith('#oauth=')) return null;
      // Clear the hash immediately so it's not re-processed on back/forward
      window.history.replaceState(null, '', window.location.pathname + window.location.search);
      const payload = JSON.parse(decodeURIComponent(hash.slice('#oauth='.length)));
      if (!payload) return null;
      // Token is in httpOnly cookie; apply session key and display info only
      if (payload.sessionId && payload.sessionKey) applySessionKey(payload.sessionId, payload.sessionKey);
      if (payload.userId || payload.email || payload.name !== undefined) {
        setUserInfo(payload.userId, payload.email, payload.name, payload.phone);
      }
      return payload;
    } catch(_) { return null; }
  }
  return {
    getConfig,
    validateSession, logout,
    legacyLogin, migrateEmail,
    sendOTP, verifyOTP, signup, emailLogin, resetPassword,
    phoneSendOTP, phoneVerifyOTP, phoneSignup, phoneLogin, phoneResetPassword,
    getSubjects, getMainSubjects, createSession, getQuestion,
    getSectionQuestions, getSectionTimer, expireSection,
    submitAnswer, finishSession,
    getProgress, saveProgress, getResume, saveResume, getLiveExam, saveLiveExam,
    getTopicStats, saveTopicStats,
    getDashboard, getTestReviews, saveTestReview,
    getEnabledOAuthProviders, oauthLogin, checkPendingOAuthResult,
    setToken, getToken, clearToken, getSavedUser, getSavedToken, getSavedEmail, getSavedName, getSavedPhone
  };
})();
