/**
 * SolveMCQ v8 (frontend_v4) — Main Application
 * Changes from v7:
 *  - Timer expiry at last question (Q40): disables Save & Next + Next buttons
 *  - Replaced all browser confirm()/alert() dialogs with custom modals
 *  - Sidebar: jumped-over questions correctly shown as "Not Visited" (not "Not Answered")
 *  - PWA install banner for iOS/Android users on first login
 */
(function () {
  'use strict';

  const SECS_PER_Q = 63;
  const MAX_SEC_SIZE = 40;
  const SEC_NAMES = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  let _qTimerPaused = false;
  let _progressSaveTimer = null;
  let _progressLoaded = false;  // guard: never save before initial load completes

  // ==================== STATE ====================
  let state = {
    view: 'login',
    userId: null,
    // mainSubjects: { "Cerebellum PYQ": { subjects: { subjKey: { displayName, topics } } } }
    mainSubjects: {},
    // flat subjects for progress lookup
    subjects: {},
    progress: {},
    topicStats: {},   // "subjKey_topicId" -> { questions: { "0": {correct,incorrect,skipped}, ... } }
    testReviews: {},  // "subjKey_topicId" -> { results, score, timeTaken, submittedAt } (last 24h only)
    reviewDismissedAt: null, // ISO timestamp — hide all review cards submitted before this
    resumeData: null,
    liveExamData: null,  // persisted real exam session state (survives app close)
    selectedMainSubj: null,
    selectedSubj: null,
    selectedTopic: null,
    selectedMode: null,
    selectedFilter: 'all',  // 'all' | 'incorrect' | 'skipped'
    session: resetSession()
  };

  function resetSession() {
    return {
      id: null, mode: null,
      subjKey: null, topicId: null,
      sections: [],
      curSec: 0,
      curQ: 0,
      answers: {},     // answers[secIdx][qIdx] = { selected, submitted, ... }
      marked: {},      // marked[secIdx][qIdx] = true
      visited: {},     // visited[secIdx][qIdx] = true when user actually views that question
      secTimer: null, secTimeLeft: 0,
      qTimer: null, qTimeLeft: 0,
      prefetched: null,
      sectionCache: {},
      sectionLoading: {},
      serverTimerSync: null,
      activeSec: 0,  // mirrors server's activeSec — only this section is unlocked
      timerExpired: false  // true when section/question timer has expired
    };
  }

  const ICONS = ['🧬','🫀','🧠','💊','🦷','🦴','🩺','🔬','🫁','🩻','🧪','🩸','🦠','💉','🏥','🎯','📊','⚕️'];

  // ==================== PROGRESS HELPERS ====================
  function getProgress(sk, tid) { return (state.progress[sk] && state.progress[sk][tid]) || 0; }
  function setProgress(sk, tid, val) {
    if (!state.progress[sk]) state.progress[sk] = {};
    state.progress[sk][tid] = Math.max(getProgress(sk, tid), val);
    scheduleSaveProgress();
  }
  function totalProgress() {
    let done = 0, total = 0;
    // Count subjects solved: a subject (e.g. "Pharmacology") is solved when
    // all its topics are fully attempted.
    let subjSolved = 0, subjTotal = 0, topicsSolved = 0, topicsTotal = 0;
    for (const [sk, subj] of Object.entries(state.subjects)) {
      let subjDone = 0, subjQ = 0;
      for (const t of subj.topics) {
        total += t.count;
        const prog = getProgress(sk, t.id);
        done += prog;
        subjQ  += t.count;
        subjDone += prog;
      }
      subjTotal++;
      if (subjQ > 0 && subjDone >= subjQ) subjSolved++;
      for (const t of subj.topics) {
        topicsTotal++;
        if (t.count > 0 && getProgress(sk, t.id) >= t.count) topicsSolved++;
      }
    }
    // Count main cards (top-level exam groups e.g. "Cerebellum PYQ") solved
    let mainSolved = 0, mainTotal = 0;
    for (const [, mainData] of Object.entries(state.mainSubjects)) {
      mainTotal++;
      let mDone = 0, mTotal = 0;
      for (const [sk, subj] of Object.entries(mainData.subjects || {})) {
        for (const t of (subj.topics || [])) {
          mTotal += t.count;
          mDone  += getProgress(sk, t.id);
        }
      }
      if (mTotal > 0 && mDone >= mTotal) mainSolved++;
    }
    return {
      done, total,
      pct: total ? parseFloat(((done / total) * 100).toFixed(2)) : 0,
      subjSolved, subjTotal, topicsSolved, topicsTotal,
      mainSolved, mainTotal
    };
  }
  function scheduleSaveProgress() {
    if (!_progressLoaded) return;  // never overwrite DB before we've loaded existing data
    clearTimeout(_progressSaveTimer);
    _progressSaveTimer = setTimeout(async () => {
      try { await API.saveProgress(state.progress); } catch {}
    }, 1500);
  }

  // ==================== RESUME HELPERS ====================
  async function saveResumeCheckpoint() {
    if (state.session.mode !== 'test' || !state.session.id) return;
    const ses = state.session;
    const sec = ses.sections[ses.curSec];
    const globalIdx = (sec ? (sec.start || 0) : 0) + ses.curQ;
    const subj = state.subjects[ses.subjKey];
    const topic = subj?.topics.find(t => t.id == ses.topicId);
    try {
      await API.saveResume({
        subjKey: ses.subjKey,
        topicId: ses.topicId,
        subjName: subj?.displayName || '',
        topicName: topic?.name || '',
        globalIdx,
        answers: ses.answers[ses.curSec] || {},
        total: sec ? sec.total : 0,
        savedAt: new Date().toISOString()
      });
    } catch {}
  }

  /**
   * After a resume, the server session is brand-new and has no record of
   * previously answered questions. Re-submit them all so finishSession()
   * sees the correct answer map and does not count them as skipped.
   */
  async function resubmitResumedAnswers() {
    const ses = state.session;
    const secAnswers = ses.answers[0] || {};
    const sec = ses.sections[0];
    const secStart = sec ? (sec.start || 0) : 0;

    // Build sorted list of answers that still need to be sent to the new server session
    const pending = Object.entries(secAnswers)
      .map(([k, v]) => [parseInt(k, 10), v])
      .filter(([, ans]) => ans.selected && !ans.submitted)
      .sort((a, b) => a[0] - b[0]);

    for (const [localIdx, ans] of pending) {
      const globalIdx = secStart + localIdx;
      try {
        const res = await API.submitAnswer(ses.id, globalIdx, ans.selected);
        ans.submitted = true;
        ans.isCorrect = res.isCorrect;
        ans.correctLabel = res.correctLabel;
      } catch {
        // Leave submitted:false so flushPending can retry if needed
      }
    }
  }

  async function clearResume() {
    try { await API.saveResume(null); } catch {}
    state.resumeData = null;
    renderResumeCard();
  }

  function renderResumeCard() {
    const r = state.resumeData;
    let el = document.getElementById('resume-card');
    if (!el) return;
    if (!r) { el.style.display = 'none'; return; }
    el.style.display = 'block';
    const saved = new Date(r.savedAt);
    const timeStr = saved.toLocaleDateString('en-IN', { day:'2-digit', month:'short' }) + ' ' +
      saved.toLocaleTimeString('en-IN', { hour:'2-digit', minute:'2-digit' });
    el.innerHTML = `
      <div class="resume-card-inner" id="resume-card-inner" role="button" tabindex="0">
        <div class="resume-icon">▶</div>
        <div class="resume-info">
          <div class="resume-title">Resume where you left off</div>
          <div class="resume-meta">${esc(r.subjName)} · ${esc(r.topicName)} · Q${r.globalIdx + 1} · Saved ${timeStr}</div>
        </div>
        <div class="resume-actions">
          <button class="btn-resume-discard" id="btn-discard-resume">Discard</button>
        </div>
      </div>`;
    document.getElementById('resume-card-inner').addEventListener('click', (e) => {
      if (e.target.closest('#btn-discard-resume')) return;
      doResume();
    });
    document.getElementById('btn-discard-resume').addEventListener('click', (e) => {
      e.stopPropagation();
      clearResume();
    });
  }

  /**
   * Render one card per topic that has a valid (< 24h) test review.
   * Styled like the resume card but amber-toned.
   * Shows: subject · topic name · score · submitted time · "Review" button · "Dismiss" button.
   */
  function renderReviewCards() {
    const container = document.getElementById('review-cards');
    if (!container) return;
    container.innerHTML = '';

    const reviews = state.testReviews || {};
    const now = Date.now();
    const validEntries = [];

    for (const [reviewKey, review] of Object.entries(reviews)) {
      if (!review || !review.submittedAt) continue;
      const submittedAt = new Date(review.submittedAt);
      const elapsed = (now - submittedAt) / (1000 * 60 * 60);
      if (elapsed >= 24) continue;
      // Skip if this review was submitted before the user last dismissed
      if (state.reviewDismissedAt && submittedAt <= new Date(state.reviewDismissedAt)) continue;

      // Resolve subject/topic display names from state.subjects
      const [sk, tid] = reviewKey.split(/_(?=\d+$)/); // split on last underscore before digits
      let subjName = sk, topicName = '';
      for (const [key, subj] of Object.entries(state.subjects || {})) {
        if (key === sk) {
          subjName = subj.displayName || sk;
          const topic = subj.topics.find(t => String(t.id) === String(tid));
          if (topic) topicName = topic.name;
          break;
        }
      }

      const hoursLeft = Math.max(0, 24 - elapsed);
      const hLeft = Math.floor(hoursLeft);
      const mLeft = Math.round((hoursLeft - hLeft) * 60);
      const expiryStr = hLeft > 0 ? `${hLeft}h ${mLeft}m` : `${mLeft}m`;

      const submitted = new Date(review.submittedAt);
      const timeStr = submitted.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' }) + ' ' +
        submitted.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });

      const score = review.score || {};
      const scoreSummary = score.score !== undefined
        ? `Score ${score.score}/${score.maxScore} · ${score.correct}✓ ${score.incorrect}✗ ${score.unattempted || 0}–`
        : '';

      validEntries.push({ reviewKey, review, sk, tid, subjName, topicName, timeStr, expiryStr, scoreSummary });
    }

    if (!validEntries.length) return;

    // Show only the single most recently submitted review
    validEntries.sort((a, b) => new Date(b.review.submittedAt) - new Date(a.review.submittedAt));
    const latest = validEntries[0];
    const { reviewKey, review, sk, tid, subjName, topicName, timeStr, expiryStr, scoreSummary } = latest;

    const card = document.createElement('div');
    card.className = 'review-dash-card';
    card.dataset.key = reviewKey;
    card.innerHTML = `
      <div class="review-dash-inner" role="button" tabindex="0">
        <div class="review-dash-icon">📋</div>
        <div class="review-dash-info">
          <div class="review-dash-title">Tap to Review Last Submitted Test</div>
          <div class="review-dash-meta">${esc(subjName)} · ${esc(topicName)}${scoreSummary ? ' · ' + esc(scoreSummary) : ''} · ${esc(timeStr)}</div>
          <div class="review-dash-expiry">⏳ Expires in ${esc(expiryStr)}</div>
        </div>
        <div class="review-dash-actions">
          <button class="btn-review-dismiss">Dismiss</button>
        </div>
      </div>`;

    // Whole card opens the review; dismiss button removes it and persists deletion
    card.querySelector('.review-dash-inner').addEventListener('click', (e) => {
      if (e.target.closest('.btn-review-dismiss')) return;
      showPreviousTestReview(sk, tid, { ...review, hoursRemaining: 0 });
    });

    card.querySelector('.btn-review-dismiss').addEventListener('click', (e) => {
      e.stopPropagation();
      const dismissedAt = new Date().toISOString();
      state.reviewDismissedAt = dismissedAt;
      localStorage.setItem(`review_dismissed_${state.userId}`, dismissedAt);
      card.remove();
    });

    container.appendChild(card);
  }

  // ==================== LIVE EXAM CARD (Real Exam resumed across app close) ====================

  let _liveExamCountdownTimer = null;

  /**
   * Render the "LIVE NOW" card on dashboard for an active real exam session.
   * Shows a live countdown of remaining time. Auto-submits and removes when time is up.
   */
  function renderLiveExamCard() {
    const container = document.getElementById('live-exam-card');
    if (!container) return;
    container.innerHTML = '';

    // Clear any existing countdown
    if (_liveExamCountdownTimer) { clearInterval(_liveExamCountdownTimer); _liveExamCountdownTimer = null; }

    const le = state.liveExamData;
    if (!le || !le.sessionId || !le.startedAt || !le.totalSecs) return;

    const startedAt = new Date(le.startedAt).getTime();
    const totalSecs = le.totalSecs;

    function getSecsLeft() {
      return Math.max(0, totalSecs - Math.floor((Date.now() - startedAt) / 1000));
    }

    function formatTime(s) {
      const h   = Math.floor(s / 3600);
      const m   = Math.floor((s % 3600) / 60);
      const sec = s % 60;
      return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`;
    }

    const secsLeft = getSecsLeft();
    if (secsLeft <= 0) {
      // Time already up — auto-submit and clear
      handleLiveExamExpired();
      return;
    }

    const card = document.createElement('div');
    card.id = 'live-exam-card-inner';
    card.className = 'live-exam-card';
    card.innerHTML = `
      <div class="live-exam-inner" role="button" tabindex="0" title="Tap to continue your live exam">
        <div class="live-exam-badge">
          <span class="live-dot"></span>
          <span class="live-label">LIVE</span>
        </div>
        <div class="live-exam-info">
         <div class="live-exam-title">Real Exam In Progress</div>
         <div class="live-exam-meta">
           ${le.topicName ? esc(le.topicName) : ''}
         </div>
        </div>
        <div class="live-exam-timer-wrap">
          <div class="live-exam-timer-label">TIME LEFT</div>
          <div class="live-exam-timer" id="live-exam-countdown">${formatTime(secsLeft)}</div>
        </div>
      </div>`;

    card.querySelector('.live-exam-inner').addEventListener('click', () => doResumeLiveExam());
    card.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') doResumeLiveExam(); });
    container.appendChild(card);

    // Live countdown
    _liveExamCountdownTimer = setInterval(() => {
      const s = getSecsLeft();
      const el = document.getElementById('live-exam-countdown');
      if (el) el.textContent = formatTime(s);
      if (s <= 0) {
        clearInterval(_liveExamCountdownTimer);
        _liveExamCountdownTimer = null;
        handleLiveExamExpired();
      }
    }, 1000);
  }

  /** Called when live exam timer reaches zero while user is on dashboard */
  async function handleLiveExamExpired() {
    const le = state.liveExamData;
    state.liveExamData = null;
    try { await API.saveLiveExam(null); } catch {}
    const container = document.getElementById('live-exam-card');
    if (container) container.innerHTML = '';
    // Auto-submit the session silently if we have a sessionId
    if (le && le.sessionId) {
      try { await API.finishSession(le.sessionId); } catch {}
    }
  }

  /** Save current real exam state so it can be resumed after app close */
  async function saveLiveExamState() {
    const ses = state.session;
    if (!ses || ses.mode !== 'real' || !ses.id || ses.finished) return;

    // Compute wallclock start time from the session (stored at exam start)
    const le = {
      sessionId:  ses.id,
      subjKey:    ses.subjKey,
      topicId:    ses.topicId,
      subjName:   state.liveExamData?.subjName || state.selectedSubj,
      topicName:  state.liveExamData?.topicName || '',
      startedAt:  state.liveExamData?.startedAt || new Date().toISOString(),
      totalSecs:  state.liveExamData?.totalSecs || (ses.sections.reduce((a, s) => a + s.total, 0) * 63),
      sectionHint: ses.sections[ses.activeSec]
        ? `Currently at Section ${String.fromCharCode(65 + ses.activeSec)} (Section ${ses.activeSec + 1} of ${ses.sections.length})`
        : '',
      savedAt:    new Date().toISOString()
    };
    state.liveExamData = le;
    try { await API.saveLiveExam(le); } catch {}
  }

  /** Clear live exam state (called after successful submit or discard) */
  async function clearLiveExam() {
    state.liveExamData = null;
    if (_liveExamCountdownTimer) { clearInterval(_liveExamCountdownTimer); _liveExamCountdownTimer = null; }
    try { await API.saveLiveExam(null); } catch {}
    const container = document.getElementById('live-exam-card');
    if (container) container.innerHTML = '';
  }

  /** Resume a live real exam session from dashboard card */
  async function doResumeLiveExam() {
    const le = state.liveExamData;
    if (!le || !le.sessionId) return;

    // Check time not expired
    const elapsed = (Date.now() - new Date(le.startedAt).getTime()) / 1000;
    if (elapsed >= le.totalSecs) {
      await handleLiveExamExpired();
      return;
    }

    stopAllTimers();
    showView('exam');
    enterFullscreen();
    showSkeleton();

    state.session = resetSession();
    state.session.mode    = 'real';
    state.session.id      = le.sessionId;
    state.session.subjKey = le.subjKey;
    state.session.topicId = le.topicId;
    state.selectedSubj    = le.subjKey;
    state.selectedTopic   = le.topicId;
    state.selectedMode    = 'real';

    const examView = document.getElementById('view-exam');
    examView.classList.add('real-mode');
    document.getElementById('exam-sidebar').style.display = '';
    document.getElementById('exam-main').classList.remove('full-width');
    document.getElementById('btn-mark').style.display = '';
    document.getElementById('btn-clear').style.display = '';

    try {
      // Fetch section 0 to learn total questions and section structure
      const batch0 = await API.getSectionQuestions(le.sessionId, 0);
      if (!batch0 || !batch0.questions || !batch0.questions.length) throw new Error('Could not load exam');

      const total         = batch0.questions[0].total;
      const totalSections = batch0.section?.totalSections || Math.ceil(total / MAX_SEC_SIZE);

      // Rebuild sections array
      const sections = [];
      let remaining = total;
      for (let i = 0; remaining > 0; i++) {
        const size = Math.min(MAX_SEC_SIZE, remaining);
        sections.push({ name: 'Section ' + SEC_NAMES[i], total: size, start: i * MAX_SEC_SIZE, expired: false });
        remaining -= size;
      }
      state.session.sections = sections;

      // Ask server which section is currently active
      const timerRes = await API.getSectionTimer(le.sessionId, 0).catch(() => ({}));
      const activeSec = typeof timerRes.activeSec === 'number' ? timerRes.activeSec
                      : Math.min(totalSections - 1, Math.floor(elapsed / (sections[0].total * SECS_PER_Q)));

      // Mark all sections before activeSec as expired
      for (let i = 0; i < activeSec; i++) sections[i].expired = true;

      state.session.activeSec = activeSec;
      state.session.curSec    = activeSec;
      state.session.curQ      = 0;

      // Fetch questions for the active section
      const activeBatch = activeSec === 0 ? batch0 : await API.getSectionQuestions(le.sessionId, activeSec);
      if (!activeBatch || !activeBatch.questions || !activeBatch.questions.length) throw new Error('Could not load active section');

      state.session.sectionCache[activeSec] = activeBatch.questions;

      renderSecTabs();
      renderSidebar();
      renderQuestion(activeBatch.questions[0], 0);

      // Get remaining time for this section from server
      const activeTimer = activeSec === 0 ? timerRes : await API.getSectionTimer(le.sessionId, activeSec).catch(() => ({}));
      state.session.secTimeLeft = typeof activeTimer.timeLeft === 'number'
        ? activeTimer.timeLeft
        : sections[activeSec].total * SECS_PER_Q;

      startSecTimer();

      // Update sectionHint
      if (state.liveExamData) {
        state.liveExamData.sectionHint = `Currently at Section ${SEC_NAMES[activeSec]} (Section ${activeSec + 1} of ${sections.length})`;
      }

    } catch (err) {
      // Session may be fully expired on server
      await clearLiveExam();
      showView('dashboard');
      renderLiveExamCard();
      showDialog({ title: 'Exam Ended', message: 'Your exam session could not be resumed — it may have expired.', type: 'alert' });
    }
  }

  async function doResume() {
    const r = state.resumeData;
    if (!r) return;
    state.selectedSubj = r.subjKey;
    state.selectedTopic = r.topicId;
    state.selectedMode = 'test';
    await clearResume();
    startExam(r);
  }

  // ==================== CUSTOM DIALOG (replaces browser confirm/alert) ====================
  /**
   * showDialog({ title, message, confirmText, cancelText, onConfirm, onCancel, type })
   * type: 'confirm' | 'alert'
   */
  function showDialog({ title = '', message = '', confirmText = 'OK', cancelText = 'Cancel', onConfirm, onCancel, type = 'confirm' }) {
    // Remove any existing dialog
    const existing = document.getElementById('custom-dialog-overlay');
    if (existing) existing.remove();

    const overlay = document.createElement('div');
    overlay.id = 'custom-dialog-overlay';
    overlay.className = 'custom-dialog-overlay';

    const isAlert = type === 'alert';
    overlay.innerHTML = `
      <div class="custom-dialog">
        ${title ? `<div class="custom-dialog-title">${esc(title)}</div>` : ''}
        <div class="custom-dialog-message">${esc(message)}</div>
        <div class="custom-dialog-actions">
          ${!isAlert ? `<button class="custom-dialog-btn cancel-btn" id="dlg-cancel">${esc(cancelText)}</button>` : ''}
          <button class="custom-dialog-btn confirm-btn" id="dlg-confirm">${esc(confirmText)}</button>
        </div>
      </div>`;

    document.body.appendChild(overlay);

    const closeDialog = () => overlay.remove();

    document.getElementById('dlg-confirm').addEventListener('click', () => {
      closeDialog();
      if (onConfirm) onConfirm();
    });

    if (!isAlert) {
      const cancelBtn = document.getElementById('dlg-cancel');
      if (cancelBtn) {
        cancelBtn.addEventListener('click', () => {
          closeDialog();
          if (onCancel) onCancel();
        });
      }
      // Click outside to cancel
      overlay.addEventListener('click', e => {
        if (e.target === overlay) { closeDialog(); if (onCancel) onCancel(); }
      });
    }

    // Focus confirm button
    setTimeout(() => {
      const btn = document.getElementById('dlg-confirm');
      if (btn) btn.focus();
    }, 50);
  }

  // ==================== SHELL ====================
  const appEl = document.getElementById('app');

  function renderShell() {
    appEl.innerHTML = `
      <div id="loading-screen"><div class="logo-spin"></div><p>Still Loading ? Close Tab or App & Reopen</p></div>

      <!-- LOGIN -->
      <div class="view" id="view-login">
        <canvas id="ribbon-canvas" aria-hidden="true"></canvas>
        <div class="login-wrap">
          <div class="login-brand">
            <div class="brand-header-band">
              <div class="brand-header-title">PracticeMCQ</div>
              <div class="brand-header-sub">NEET PG &middot; INICET &middot; UPSC CMS</div>
            </div>
          </div>


          <!-- STEP 1: Email entry + mode tabs -->
          <div class="login-card" id="auth-step-email">
            <button class="btn-modal-back" id="btn-auth-close" onclick="document.getElementById('view-auth').style.display='none'" title="Back" style="display:none" aria-label="Close">&#8592; Back</button>
            <div class="auth-tabs">
              <button class="auth-tab active" id="tab-signin" onclick="authSwitchTab('signin')">Sign In</button>
              <button class="auth-tab" id="tab-signup" onclick="authSwitchTab('signup')">Sign Up</button>
              <button class="auth-tab" id="tab-phone" onclick="authSwitchTab('phone')">📱 Mobile</button>
              <button class="auth-tab" id="tab-legacy" onclick="authSwitchTab('legacy')">Old User?</button>
            </div>
            <div class="field-group">
              <div>
                <label class="field-label">Email Address</label>
                <input class="field-input" type="email" id="inp-email" placeholder="Enter Your Valid Email" autocomplete="email" inputmode="email" />
                <div class="field-hint">✅ Allowed: Gmail, Outlook, Yahoo, Rediffmail</div>
              </div>
            </div>
            <button class="btn-primary" id="btn-send-otp">Continue</button>
            <div class="login-err" id="login-err"></div>
            <!-- Inline OAuth buttons (hidden by default; initOAuthButtons() shows enabled ones) -->
            <div class="inline-oauth-wrap" id="inline-oauth-wrap" style="display:none">
              <div class="social-divider inline-oauth-divider"><span>or Continue With</span></div>
              <div class="social-btn-group inline-oauth" id="inline-oauth-group">
                <button class="social-btn social-btn-google" onclick="handleOAuthLogin('google')" aria-label="Sign in with Google">
                  <svg width="18" height="18" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg"><path fill="#4285F4" d="M46.145 24.504c0-1.63-.146-3.198-.418-4.706H24v8.899h12.427c-.536 2.882-2.163 5.325-4.61 6.965v5.79h7.466c4.365-4.021 6.862-9.942 6.862-16.948z"/><path fill="#34A853" d="M24 47c6.237 0 11.467-2.068 15.289-5.605l-7.466-5.79c-2.068 1.385-4.714 2.201-7.823 2.201-6.016 0-11.109-4.062-12.929-9.519H3.386v5.979C7.19 41.896 15.02 47 24 47z"/><path fill="#FBBC05" d="M11.071 28.287A13.924 13.924 0 0 1 10.5 24c0-1.49.256-2.94.571-4.287v-5.979H3.386A22.963 22.963 0 0 0 1 24c0 3.71.888 7.22 2.386 10.266l7.685-5.979z"/><path fill="#EA4335" d="M24 10.194c3.39 0 6.435 1.167 8.827 3.456l6.617-6.617C35.463 3.295 30.233 1 24 1 15.02 1 7.19 6.104 3.386 13.734l7.685 5.979C12.891 14.256 17.984 10.194 24 10.194z"/></svg>
                  Google
                </button>
                <button class="social-btn social-btn-github" onclick="handleOAuthLogin('github')" aria-label="Sign in with GitHub">
                  <svg width="18" height="18" viewBox="0 0 98 96" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M48.854 0C21.839 0 0 22 0 49.217c0 21.756 13.993 40.172 33.405 46.69 2.427.49 3.316-1.059 3.316-2.362 0-1.141-.08-5.052-.08-9.127-13.59 2.934-16.42-5.867-16.42-5.867-2.184-5.704-5.42-7.17-5.42-7.17-4.448-3.015.324-3.015.324-3.015 4.934.326 7.523 5.052 7.523 5.052 4.367 7.496 11.404 5.378 14.235 4.074.404-3.178 1.699-5.378 3.074-6.6-10.839-1.141-22.243-5.378-22.243-24.283 0-5.378 1.94-9.778 5.014-13.2-.485-1.222-2.184-6.275.486-13.038 0 0 4.125-1.304 13.426 5.052a46.97 46.97 0 0 1 12.214-1.63c4.125 0 8.33.571 12.213 1.63 9.302-6.356 13.427-5.052 13.427-5.052 2.67 6.763.97 11.816.485 13.038 3.155 3.422 5.015 7.822 5.015 13.2 0 18.905-11.404 23.06-22.324 24.283 1.78 1.548 3.316 4.481 3.316 9.126 0 6.6-.08 11.897-.08 13.526 0 1.304.89 2.853 3.316 2.364 19.412-6.52 33.405-24.935 33.405-46.691C97.707 22 75.788 0 48.854 0z" fill="currentColor"/></svg>
                  GitHub
                </button>
                <button class="social-btn social-btn-apple" onclick="handleOAuthLogin('apple')" aria-label="Sign in with Apple">
                  <svg width="18" height="18" viewBox="0 0 814 1000" xmlns="http://www.w3.org/2000/svg"><path d="M788.1 340.9c-5.8 4.5-108.2 62.2-108.2 190.5 0 148.4 130.3 200.9 134.2 202.2-.6 3.2-20.7 71.9-68.7 141.9-42.8 61.6-87.5 123.1-155.5 123.1s-85.5-39.5-164-39.5c-76.5 0-103.7 40.8-165.9 40.8s-105-42.3-154.4-112.7C115.7 754.4 77.7 622.5 77.7 496.9c0-193.3 125.3-294.9 250.5-294.9 66.3 0 121.7 43.4 162.6 43.4 39.5 0 101.1-46 176.3-46 28.5 0 130.9 2.6 198.3 99.2zm-234-181.5c31.1-36.9 53.1-88.1 53.1-139.3 0-7.1-.6-14.3-1.9-20.1-50.6 1.9-110.8 33.7-147.1 75.8-28.5 32.4-55.1 83.6-55.1 135.5 0 7.8 1.3 15.6 1.9 18.1 3.2.6 8.4 1.3 13.6 1.3 45.4 0 102.5-30.4 135.5-71.3z" fill="currentColor"/></svg>
                  Apple
                </button>
              </div>
              <div class="login-err" id="social-err" style="text-align:center;margin-top:6px"></div>
            </div>
          </div>

          <!-- PHONE STEP 1: Enter mobile number -->
          <div class="login-card" id="auth-step-phone" style="display:none">
            <button class="btn-modal-back" onclick="authSwitchTab('signin')" aria-label="Go back">&#8592; Back</button>
            <h2 id="phone-step-title">Continue with Mobile</h2>
            <p class="auth-subtitle" id="phone-step-subtitle">Sign up or sign in using your mobile number</p>
            <div class="field-group">
              <div>
                <label class="field-label">Mobile Number</label>
                <div style="display:flex;gap:8px;align-items:center">
                  <span style="padding:10px 12px;background:var(--bg-secondary,#f1f5f9);border:1px solid var(--border,#e2e8f0);border-radius:8px;font-size:14px;color:var(--text-secondary,#64748b);white-space:nowrap">🇮🇳 +91</span>
                  <input class="field-input" type="tel" id="inp-phone" placeholder="10-digit mobile number" autocomplete="tel" inputmode="numeric" maxlength="10" style="flex:1" />
                </div>
                <div class="field-hint">We'll send a 6-digit verification code via SMS</div>
              </div>
            </div>
            <button class="btn-primary" id="btn-phone-send-otp">Send Code</button>
            <div class="login-err" id="phone-err"></div>
          </div>

          <!-- PHONE STEP 2: Verify OTP -->
          <div class="login-card" id="auth-step-phone-otp" style="display:none">
            <button class="btn-modal-back" onclick="phoneShowStep('phone')" aria-label="Go back">&#8592; Back</button>
            <h2>Verify Mobile Number</h2>
            <p class="auth-subtitle">Enter the 6-digit code sent to <strong id="phone-otp-display"></strong></p>
            <div class="otp-box-wrap">
              <div class="otp-label-row">Your verification code</div>
              <div class="otp-digits" id="phone-otp-digit-boxes">
                <input class="otp-digit" type="tel" inputmode="numeric" pattern="[0-9]" maxlength="1" data-idx="0" autocomplete="one-time-code" aria-label="Digit 1" />
                <input class="otp-digit" type="tel" inputmode="numeric" pattern="[0-9]" maxlength="1" data-idx="1" aria-label="Digit 2" />
                <input class="otp-digit" type="tel" inputmode="numeric" pattern="[0-9]" maxlength="1" data-idx="2" aria-label="Digit 3" />
                <input class="otp-digit" type="tel" inputmode="numeric" pattern="[0-9]" maxlength="1" data-idx="3" aria-label="Digit 4" />
                <input class="otp-digit" type="tel" inputmode="numeric" pattern="[0-9]" maxlength="1" data-idx="4" aria-label="Digit 5" />
                <input class="otp-digit" type="tel" inputmode="numeric" pattern="[0-9]" maxlength="1" data-idx="5" aria-label="Digit 6" />
              </div>
              <input type="hidden" id="inp-phone-otp" />
              <div class="otp-expiry-note">Expires in <strong>10 minutes</strong></div>
            </div>
            <button class="btn-primary" id="btn-phone-verify-otp">Verify Code</button>
            <div class="otp-action-row">
              <button class="otp-nav-btn" onclick="phoneShowStep('phone')">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
                Change number
              </button>
              <button class="otp-resend-btn" id="btn-phone-resend-otp">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>
                Resend code
              </button>
            </div>
            <div class="login-err" id="phone-otp-err"></div>
          </div>

          <!-- PHONE STEP 3a: Set name + password (signup) -->
          <div class="login-card" id="auth-step-phone-set-password" style="display:none">
            <button class="btn-modal-back" onclick="phoneShowStep('phone-otp')" aria-label="Go back">&#8592; Back</button>
            <h2>Create Your Account</h2>
            <p class="auth-subtitle">Almost there — set your name and a strong password</p>
            <div class="field-group">
              <div>
                <label class="field-label">Full Name</label>
                <input class="field-input" type="text" id="inp-phone-name" placeholder="e.g. Rahul Sharma (WITHOUT prefix Dr)" autocomplete="name" maxlength="60" />
              </div>
              <div>
                <label class="field-label">Password</label>
                <div class="pw-field-wrap"><input class="field-input" type="password" id="inp-phone-new-pass" placeholder="Min 8 chars" autocomplete="new-password" /><button type="button" class="pw-eye-btn" onclick="togglePasswordVisibility('inp-phone-new-pass',this)" aria-label="Show/hide password">👁</button></div>
              </div>
              <div class="pw-rules" id="pw-rules-phone">
                <span id="pw-phone-rule-len">✗ At least 8 characters</span>
                <span id="pw-phone-rule-upper">✗ One uppercase letter</span>
                <span id="pw-phone-rule-lower">✗ One lowercase letter</span>
                <span id="pw-phone-rule-num">✗ One number</span>
              </div>
              <div>
                <label class="field-label">Confirm Password</label>
                <input class="field-input" type="password" id="inp-phone-confirm-pass" placeholder="Re-enter password" autocomplete="new-password" />
              </div>
            </div>
            <button class="btn-primary" id="btn-phone-create-account">Create Account</button>
            <div class="login-err" id="phone-signup-err"></div>
          </div>

          <!-- PHONE STEP 3b: Enter password (login) -->
          <div class="login-card" id="auth-step-phone-enter-password" style="display:none">
            <button class="btn-modal-back" onclick="phoneShowStep('phone')" aria-label="Go back">&#8592; Back</button>
            <h2>Welcome Back</h2>
            <p class="auth-subtitle" id="phone-signin-display"></p>
            <div class="field-group">
              <div>
                <label class="field-label">Password</label>
                <div class="pw-field-wrap"><input class="field-input" type="password" id="inp-phone-pass" placeholder="Enter your password" autocomplete="current-password" /><button type="button" class="pw-eye-btn" onclick="togglePasswordVisibility('inp-phone-pass',this)" aria-label="Show/hide password">👁</button></div>
              </div>
            </div>
            <button class="btn-primary" id="btn-phone-login">Sign In</button>
            <button class="btn-link" id="btn-phone-forgot">Forgot password?</button>
            <div class="login-err" id="phone-signin-err"></div>
          </div>

          <!-- PHONE STEP 3c: Reset password -->
          <div class="login-card" id="auth-step-phone-reset-password" style="display:none">
            <button class="btn-modal-back" onclick="phoneShowStep('phone-otp')" aria-label="Go back">&#8592; Back</button>
            <h2>Reset Password</h2>
            <p class="auth-subtitle">Set a new password for your account</p>
            <div class="field-group">
              <div>
                <label class="field-label">New Password</label>
                <div class="pw-field-wrap"><input class="field-input" type="password" id="inp-phone-reset-pass" placeholder="Min 8 chars" autocomplete="new-password" /><button type="button" class="pw-eye-btn" onclick="togglePasswordVisibility('inp-phone-reset-pass',this)" aria-label="Show/hide password">👁</button></div>
              </div>
              <div>
                <label class="field-label">Confirm New Password</label>
                <input class="field-input" type="password" id="inp-phone-reset-confirm" placeholder="Re-enter password" autocomplete="new-password" />
              </div>
            </div>
            <button class="btn-primary" id="btn-phone-reset-password">Reset Password</button>
            <div class="login-err" id="phone-reset-err"></div>
          </div>

          <!-- STEP 1 (legacy): Application No + Password for old users -->
          <div class="login-card" id="auth-step-legacy" style="display:none">
            <button class="btn-modal-back" onclick="authSwitchTab('signin')" aria-label="Go back">&#8592; Back</button>
            <h2>Old Account Sign In</h2>
            <p class="auth-subtitle">Sign in with your original Application Number and Password. You'll be asked to link an email once. Just follow the steps. Thereafter use this Email and Password to Sign In in future. By migrating, your EXISTING DATA will remain PRESERVED</p>
            <div class="field-group">
              <div>
                <label class="field-label">Application Number</label>
                <input class="field-input" type="text" id="inp-appno" placeholder="Your original application number" autocomplete="off" spellcheck="false" inputmode="text" />
              </div>
              <div>
                <label class="field-label">Password</label>
                <div class="pw-field-wrap"><input class="field-input" type="password" id="inp-appno-pass" placeholder="Same as application number" autocomplete="off" /><button type="button" class="pw-eye-btn" onclick="togglePasswordVisibility('inp-appno-pass',this)" aria-label="Show/hide password">👁</button></div>
              </div>
            </div>
            <button class="btn-primary" id="btn-legacy-login">Sign In</button>
            <div class="login-err" id="legacy-err"></div>
          </div>
          <div class="login-card" id="auth-step-otp" style="display:none">
            <button class="btn-modal-back" onclick="authShowStep('email')" aria-label="Go back">&#8592; Back</button>
            <h2 id="otp-step-title">Verify Email</h2>
            <p class="auth-subtitle" id="otp-desc">Enter the 6-digit code sent to <strong id="otp-email-display"></strong></p>
            <p class="auth-hint">(If not received, check in <strong>All inboxes</strong> or <strong>Updates</strong> or <strong>Spam</strong> otherwise <strong>Continue with Google or Github</strong>)</p>
            <div class="otp-box-wrap">
              <div class="otp-label-row">Your verification code</div>
              <div class="otp-digits" id="otp-digit-boxes">
                <input class="otp-digit" type="tel" inputmode="numeric" pattern="[0-9]" maxlength="1" data-idx="0" autocomplete="one-time-code" aria-label="Digit 1" />
                <input class="otp-digit" type="tel" inputmode="numeric" pattern="[0-9]" maxlength="1" data-idx="1" aria-label="Digit 2" />
                <input class="otp-digit" type="tel" inputmode="numeric" pattern="[0-9]" maxlength="1" data-idx="2" aria-label="Digit 3" />
                <input class="otp-digit" type="tel" inputmode="numeric" pattern="[0-9]" maxlength="1" data-idx="3" aria-label="Digit 4" />
                <input class="otp-digit" type="tel" inputmode="numeric" pattern="[0-9]" maxlength="1" data-idx="4" aria-label="Digit 5" />
                <input class="otp-digit" type="tel" inputmode="numeric" pattern="[0-9]" maxlength="1" data-idx="5" aria-label="Digit 6" />
              </div>
              <input type="hidden" id="inp-otp" />
              <div class="otp-expiry-note">Expires in <strong>10 minutes</strong></div>
            </div>
            <button class="btn-primary" id="btn-verify-otp">Verify Code</button>
            <div class="otp-action-row">
              <button class="otp-nav-btn" id="btn-back-email">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
                Change email
              </button>
              <button class="otp-resend-btn" id="btn-resend-otp">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>
                Resend code
              </button>
            </div>
            <div class="login-err" id="otp-err"></div>
          </div>

          <!-- STEP 3a: Set password (signup) -->
          <div class="login-card" id="auth-step-set-password" style="display:none">
            <button class="btn-modal-back" onclick="authShowStep('otp')" aria-label="Go back">&#8592; Back</button>
            <h2>Create Your Account</h2>
            <p class="auth-subtitle">Almost there — set your name and password</p>
            <div class="field-group">
              <div>
                <label class="field-label">Full Name</label>
                <input class="field-input" type="text" id="inp-name" placeholder="Your name (e.g. Rahul Sharma)" autocomplete="name" maxlength="60" />
              </div>
              <div>
                <label class="field-label">Password</label>
                <div class="pw-field-wrap"><input class="field-input" type="password" id="inp-new-pass" placeholder="Min 8 chars" autocomplete="new-password" /><button type="button" class="pw-eye-btn" onclick="togglePasswordVisibility('inp-new-pass',this)" aria-label="Show/hide password">👁</button></div>
              </div>
              <div class="pw-rules" id="pw-rules">
                <span id="pw-rule-len">✗ At least 8 characters</span>
                <span id="pw-rule-upper">✗ One uppercase letter</span>
                <span id="pw-rule-lower">✗ One lowercase letter</span>
                <span id="pw-rule-num">✗ One number</span>
              </div>
              <div>
                <label class="field-label">Confirm Password</label>
                <input class="field-input" type="password" id="inp-confirm-pass" placeholder="Re-enter password" autocomplete="new-password" />
              </div>
            </div>
            <button class="btn-primary" id="btn-create-account">Create Account</button>
            <div class="login-err" id="signup-err"></div>
          </div>

          <!-- STEP 3b: Enter password (signin) -->
          <div class="login-card" id="auth-step-enter-password" style="display:none">
            <button class="btn-modal-back" onclick="authShowStep('email')" aria-label="Go back">&#8592; Back</button>
            <h2>Enter Password</h2>
            <p class="auth-subtitle" id="signin-email-display"></p>
            <div class="field-group">
              <div>
                <label class="field-label">Password</label>
                <div class="pw-field-wrap"><input class="field-input" type="password" id="inp-pass" placeholder="Enter your password" autocomplete="current-password" /><button type="button" class="pw-eye-btn" onclick="togglePasswordVisibility('inp-pass',this)" aria-label="Show/hide password">👁</button></div>
              </div>
            </div>
            <button class="btn-primary" id="btn-login">Sign In</button>
            <button class="btn-link" id="btn-forgot-password">Forgot password?</button>
            <div class="login-err" id="signin-err"></div>
          </div>

          <!-- STEP 3c: Reset password -->
          <div class="login-card" id="auth-step-reset-password" style="display:none">
            <h2>Reset Password</h2>
            <p class="auth-subtitle">Set a new password for your account</p>
            <div class="field-group">
              <div>
                <label class="field-label">New Password</label>
                <div class="pw-field-wrap"><input class="field-input" type="password" id="inp-reset-pass" placeholder="Min 8 chars" autocomplete="new-password" /><button type="button" class="pw-eye-btn" onclick="togglePasswordVisibility('inp-reset-pass',this)" aria-label="Show/hide password">👁</button></div>
              </div>
              <div>
                <label class="field-label">Confirm New Password</label>
                <input class="field-input" type="password" id="inp-reset-confirm" placeholder="Re-enter password" autocomplete="new-password" />
              </div>
            </div>
            <button class="btn-primary" id="btn-reset-password">Reset Password</button>
            <div class="login-err" id="reset-err"></div>
          </div>

        </div>
      </div>

      <!-- DASHBOARD -->
      <div class="view" id="view-dashboard">
        <nav class="nav">
          <div class="nav-brand">PracticeMCQ</div>
          <div class="nav-right">
            <span class="nav-user" id="nav-user-label"></span>
            <button class="btn-theme-toggle" id="btn-theme-toggle" title="Toggle dark/light mode">☀️</button>
            <button class="btn-logout" id="btn-logout">LOGOUT</button>
          </div>
        </nav>
        <!-- ── Notification Bar (controlled via config.js NOTIFICATION flag) ── -->
        <div class="notif-bar notif-bar--hidden" id="notif-bar" role="status" aria-live="polite">
          <span class="notif-bar-text" id="notif-bar-text"></span>
          <button class="notif-bar-close" id="notif-bar-close" aria-label="Dismiss notification">✕</button>
        </div>

        <!-- Mobile-only greeting banner (hidden on desktop via CSS) -->
        <div class="mobile-greeting-banner" id="mobile-greeting-banner" aria-live="polite">
          <span class="mobile-greeting-text" id="mobile-greeting-text"></span>
        </div>
        <div class="dashboard-hero">
          <!-- ECG waveform canvas -->
          <div class="ecg-wrap">
            <canvas class="ecg-canvas" id="ecg-canvas" aria-hidden="true"></canvas>
          </div>
          <!-- Exam title row -->
          <div class="hero-exam-badges">
            <span class="hero-badge hero-badge--neet">NEET PG</span>
            <img src="icons/live.gif" class="live-sep-gif" alt="LIVE" />
            <span class="hero-badge hero-badge--inicet">INICET</span>
            <img src="icons/live.gif" class="live-sep-gif" alt="LIVE" />
            <span class="hero-badge hero-badge--upsc">UPSC CMS</span>
          </div>
          <!-- Coloured underlines matching image reference -->
          <div class="hero-underlines" aria-hidden="true">
            <span class="hero-ul hero-ul--neet"></span>
            <span class="hero-ul hero-ul--inicet"></span>
            <span class="hero-ul hero-ul--upsc"></span>
          </div>
        </div>
        <div class="progress-banner" id="progress-banner" style="display:none">
          <div class="progress-banner-inner">
            <div class="progress-banner-header">
              <span class="progress-banner-label">Overall Progress</span>
              <span class="progress-detail" id="dash-progress-detail">0 / 0 Questions</span>
            </div>
            <div class="progress-bar-track"><div class="progress-bar-fill" id="dash-progress-fill" style="width:0%"></div></div>
            <div class="progress-stats-row">
              <div class="progress-stat-tile">
                <span class="progress-stat-value" id="dash-stat-solved">0</span>
                <span class="progress-stat-label">Questions solved</span>
              </div>
              <div class="progress-stat-tile">
                <span class="progress-stat-value" id="dash-stat-topics">0 / 0</span>
                <span class="progress-stat-label">Topics Completed</span>
              </div>
              <div class="progress-stat-tile">
                <span class="progress-stat-value" id="dash-stat-topic-solved">0 / 0</span>
                <span class="progress-stat-label">Sub-topics solved</span>
              </div>
              <div class="progress-stat-tile">
                <span class="progress-stat-value progress-pct" id="dash-progress-pct">0%</span>
                <span class="progress-stat-label">Complete</span>
              </div>
            </div>
            <div class="progress-cards-row">
              <span class="progress-cards-badge" id="dash-stat-cards">0 / 0 exam cards solved</span>
            </div>
          </div>
        </div>
        <div class="resume-card" id="resume-card" style="display:none"></div>
        <div id="live-exam-card"></div>
        <div id="review-cards"></div>
        <p class="hero-sub subjects-label">Choose any one to begin practicing</p>
        <div class="subjects-grid" id="subjects-grid"></div>
        <p class="app-version-label" id="app-version-label">v${APP_VERSION}</p>
        <div class="bottom-bar">These are not AI generated content. We do not own the rights. For any issue , mail at inbox@sharepremium.in</div>
      </div>

      <!-- SUBJECT MODAL (3-step: subject_name picker + topic picker + mode) -->
      <div class="modal-overlay" id="modal-subject">
        <div class="modal">
          <button class="modal-close" id="modal-close">×</button>
          <h3 id="modal-title">Select Options</h3>

          <!-- Step 1: Subject Name (only shown when main_subject has multiple subjects) -->
          <div id="modal-step-subject" style="display:none">
            <label class="field-label">Topic</label>
            <select class="select-field" id="sel-subject"><option value="">-- Select a topic --</option></select>
          </div>

          <!-- Step 2: Topic -->
          <div id="modal-step-topic">
            <label class="field-label">Sub-topic</label>
            <select class="select-field" id="sel-topic"><option value="">-- Select a sub-topic --</option></select>
          </div>

          <!-- Topic solve status badge -->
          <div id="topic-status-wrap" style="display:none; margin-bottom:12px;">
            <!-- Previous Test Review button (injected by JS when review exists within 24h) -->
            <div id="topic-review-btn-wrap" style="display:none; text-align:center; margin-bottom:10px;"></div>
            <div id="topic-status-badge" style="text-align:center;"></div>
            <!-- Filter tags: only shown when topic is solved -->
            <div id="topic-filter-wrap" style="display:none; margin-top:10px;">
              <div class="filter-label">Practice:</div>
              <div class="filter-tags" id="filter-tags">
                <button class="filter-tag" data-filter="incorrect">Incorrect</button>
                <button class="filter-tag" data-filter="skipped">Skipped</button>
                <button class="filter-tag active" data-filter="all">Repeat All</button>
              </div>
            </div>
          </div>

          <!-- Step 3: Mode -->
          <div style="margin-bottom:8px"><label class="field-label">Exam Mode</label></div>
          <div class="mode-options">
            <div class="mode-option selected" data-mode="real">
              <div class="mode-title"><span class="mode-dot"></span>Real Exam Mode</div>
              <ul class="mode-bullets">
                <li>For Best experience, Use LAPTOP or DESKTOP</li>
                <li>EACH SECTION consists of max 40 questions</li>
                <li>Answers &amp; scores and explanation shown only at the end</li>
                <li>Its just Simulation of how Final Exam interface Looks</li>
              </ul>
            </div>
            <div class="mode-option" data-mode="test">
              <div class="mode-title"><span class="mode-dot"></span>Test Mode</div>
              <ul class="mode-bullets">
                <li>Timer based Practicing with explanation</li>
                <li>Answer &amp; explanation shown immediately after each question</li>
                <li>Resume from where you left off on next visit</li>
                <li>Tap over image/table to zoom it</li>
              </ul>
            </div>
          </div>
          
          <button class="btn-primary" id="btn-start-exam">I AGREE to Proceed</button>
        </div>
      </div>

      <!-- INSTRUCTIONS MODAL (Real mode only) -->
      <!-- MIGRATION MODAL: legacy users link their email -->
      <div class="modal-overlay" id="modal-migration" style="z-index:9999">
        <div class="modal migration-modal">
          <button class="modal-close" id="mig-btn-close" aria-label="Close and sign out" title="Close and sign out">×</button>
          <div class="migration-header">
            <div class="migration-icon">🔐</div>
            <h3>One-Time Account Upgrade</h3>
            <p class="migration-subtitle">Your account needs an email address for secure sign-in going forward. Your progress, stats, and history are all safe.</p>
          </div>

          <!-- Sub-step A: enter email -->
          <div id="mig-step-email">
            <div class="field-group">
              <div>
                <label class="field-label">Your Email Address</label>
                <input class="field-input" type="email" id="mig-inp-email" placeholder="you@gmail.com / outlook / yahoo / rediffmail" autocomplete="email" inputmode="email" />
                <div class="field-hint">✅ Gmail, Outlook, Hotmail, Yahoo, Rediffmail only</div>
              </div>
            </div>
            <button class="btn-primary" id="mig-btn-send-otp">Send Verification Code</button>
            <div class="login-err" id="mig-err-email"></div>
          </div>

          <!-- Sub-step B: verify OTP -->
          <div id="mig-step-otp" style="display:none">
            <button class="btn-modal-back" onclick="document.getElementById('mig-step-otp').style.display='none';document.getElementById('mig-step-email').style.display=''" aria-label="Go back">&#8592; Back</button>
            <p class="auth-subtitle">Enter the 6-digit code sent to <strong id="mig-otp-email-display"></strong></p>
            <div class="otp-box-wrap">
              <div class="otp-label-row">Your verification code</div>
              <div class="otp-digits" id="mig-otp-digit-boxes">
                <input class="otp-digit" type="tel" inputmode="numeric" pattern="[0-9]" maxlength="1" data-idx="0" autocomplete="one-time-code" aria-label="Digit 1" />
                <input class="otp-digit" type="tel" inputmode="numeric" pattern="[0-9]" maxlength="1" data-idx="1" aria-label="Digit 2" />
                <input class="otp-digit" type="tel" inputmode="numeric" pattern="[0-9]" maxlength="1" data-idx="2" aria-label="Digit 3" />
                <input class="otp-digit" type="tel" inputmode="numeric" pattern="[0-9]" maxlength="1" data-idx="3" aria-label="Digit 4" />
                <input class="otp-digit" type="tel" inputmode="numeric" pattern="[0-9]" maxlength="1" data-idx="4" aria-label="Digit 5" />
                <input class="otp-digit" type="tel" inputmode="numeric" pattern="[0-9]" maxlength="1" data-idx="5" aria-label="Digit 6" />
              </div>
              <input type="hidden" id="mig-inp-otp" />
              <div class="otp-expiry-note">Expires in <strong>10 minutes</strong></div>
            </div>
            <button class="btn-primary" id="mig-btn-verify-otp">Verify Code</button>
            <div class="otp-action-row">
              <button class="otp-nav-btn" onclick="document.getElementById('mig-step-otp').style.display='none';document.getElementById('mig-step-email').style.display=''">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
                Change email
              </button>
              <button class="otp-resend-btn" id="mig-btn-resend-otp">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>
                Resend code
              </button>
            </div>
            <div class="login-err" id="mig-err-otp"></div>
          </div>

          <!-- Sub-step C: set name + new password -->
          <div id="mig-step-password" style="display:none">
            <button class="btn-modal-back" onclick="document.getElementById('mig-step-password').style.display='none';document.getElementById('mig-step-otp').style.display=''" aria-label="Go back">&#8592; Back</button>
            <p class="auth-subtitle">Almost done — set your name and a secure password</p>
            <div class="field-group">
              <div>
                <label class="field-label">Full Name</label>
                <input class="field-input" type="text" id="mig-inp-name" placeholder="Your name (e.g. Rahul Sharma)" autocomplete="name" maxlength="60" />
              </div>
              <div>
                <label class="field-label">New Password</label>
                <div class="pw-field-wrap"><input class="field-input" type="password" id="mig-inp-pass" placeholder="Min 8 chars" autocomplete="new-password" /><button type="button" class="pw-eye-btn" onclick="togglePasswordVisibility('mig-inp-pass',this)" aria-label="Show/hide password">👁</button></div>
              </div>
              <div>
                <label class="field-label">Confirm Password</label>
                <input class="field-input" type="password" id="mig-inp-pass-confirm" placeholder="Re-enter password" autocomplete="new-password" />
              </div>
              <div class="pw-rules" id="mig-pw-rules">
                <span id="mig-pw-rule-len">✗ At least 8 characters</span>
                <span id="mig-pw-rule-upper">✗ One uppercase letter</span>
                <span id="mig-pw-rule-lower">✗ One lowercase letter</span>
                <span id="mig-pw-rule-num">✗ One number</span>
              </div>
            </div>
            <button class="btn-primary" id="mig-btn-complete">Complete Upgrade</button>
            <div class="login-err" id="mig-err-pass"></div>
          </div>

          <!-- Sub-step D: success -->
          <div id="mig-step-done" style="display:none;text-align:center;padding:16px 0">
            <div style="font-size:48px;margin-bottom:12px">✅</div>
            <h3 style="margin-bottom:8px">Account Upgraded!</h3>
            <p style="color:var(--text2);font-size:14px">Your email is now linked. All your progress is intact.</p>
            <button class="btn-primary" id="mig-btn-continue" style="margin-top:16px">Continue to App</button>
          </div>
        </div>
      </div>

      <div class="modal-overlay" id="modal-instructions">
        <div class="modal" style="max-width:600px">
          <button class="modal-close" id="instr-close">×</button>
          <h3>Real Exam Instructions</h3>
          <div style="background:#f8fafc;border-radius:8px;padding:16px;margin-bottom:16px;border:1px solid #e2e8f0;">
            <ol style="padding-left:20px;font-size:13.5px;line-height:1.9;color:#475569;">
              <li>Total Questions are split into <strong>sections of max 40 each</strong>.</li>
              <li>You <strong>cannot access other sections</strong> until the timer expires for the current section.</li>
              <li>When timer hits zero, section is locked and exam moves to the next section automatically.</li>
              <li>Scoring: <strong style="color:#16a34a">+4 correct</strong> · <strong style="color:#dc2626">−1 incorrect</strong> · 0 skipped.</li>
              <li style="color:#d97706">You cannot go back to a previous section.</li>
            </ol>
          </div>
          <button class="btn-primary" id="btn-begin-exam">Start Exam Now</button>
        </div>
      </div>

      <!-- EXAM VIEW -->
      <div class="view" id="view-exam">
        <div class="exam-watermark" id="exam-watermark"></div>
        <div class="exam-header">
          <div class="exam-brand">NEET PG | INICET</div>
          <div class="exam-sections" id="exam-sections"></div>
          <div class="exam-timer" id="exam-timer">--:--</div>
        </div>
        <div class="exam-body">
          <div class="exam-main" id="exam-main"></div>
          <div class="exam-sidebar" id="exam-sidebar"></div>
        </div>
        <div class="exam-footer">
          <button class="btn-exam btn-prev-q" id="btn-prev-q" title="Previous Question">&#8592; Prev</button>
          <button class="btn-exam btn-mark-review" id="btn-mark">Mark for Review</button>
          <button class="btn-exam btn-clear" id="btn-clear">Clear Response</button>
          <div style="flex:1"></div>
          <button class="btn-exam btn-submit-section" id="btn-submit">Submit</button>
          <button class="btn-exam btn-save-next" id="btn-save-next">Save &amp; Next</button>
        </div>
      </div>

      <!-- RESULTS VIEW -->
      <div class="view" id="view-results">
        <nav class="nav result-nav-fixed">
          <div class="nav-left-group">
            <button class="btn-home-icon" id="btn-home-result" title="Go to Dashboard" aria-label="Home">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9.5L12 3l9 6.5V20a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V9.5z"/><polyline points="9 21 9 12 15 12 15 21"/></svg>
            </button>
            <button class="nav-brand nav-brand-btn" id="result-brand-btn">PracticeMCQ</button>
          </div>
          <div class="nav-right">
            <span class="nav-user" id="result-nav-user-label"></span>
            <button class="btn-theme-toggle" id="btn-theme-toggle-result" title="Toggle dark/light mode">☀️</button>
            <button class="btn-logout" id="btn-result-logout">LOGOUT</button>
          </div>
        </nav>
        <div class="results-page-body">
          <!-- SIDEBAR SCOREBOARD -->
          <aside class="results-sidebar" id="results-sidebar">
            <div class="results-sidebar-inner">
              <div class="rs-label">Your Score</div>
              <div class="rs-score" id="result-score">0</div>
              <div class="rs-max" id="result-max">out of 0</div>
              <div class="rs-time" id="result-subtitle"></div>
              <div class="rs-stats">
                <div class="rs-stat correct">
                  <div class="rs-stat-val" id="stat-correct">0</div>
                  <div class="rs-stat-lbl">Correct<br/><small>+4 each</small></div>
                </div>
                <div class="rs-stat wrong">
                  <div class="rs-stat-val" id="stat-wrong">0</div>
                  <div class="rs-stat-lbl">Wrong<br/><small>−1 each</small></div>
                </div>
                <div class="rs-stat skip">
                  <div class="rs-stat-val" id="stat-skip">0</div>
                  <div class="rs-stat-lbl">Skipped<br/><small>0 marks</small></div>
                </div>
              </div>
              <div class="rs-bar-wrap">
                <div class="rs-bar-track">
                  <div class="rs-bar-fill" id="rs-bar-fill" style="width:0%"></div>
                </div>
                <div class="rs-bar-label" id="rs-bar-label">0% accuracy</div>
              </div>
              <button class="btn-back-dash" id="btn-back-dash">← Back to Homepage</button>
            </div>
            <!-- Center toggle arrow -->
            <button class="sidebar-toggle-arrow" id="sidebar-toggle-arrow" title="Toggle scoreboard" aria-label="Toggle scoreboard">
              <span class="sidebar-arrow-icon">&#8249;</span>
            </button>
          </aside>
          <!-- MAIN CONTENT -->
          <div class="results-main-content" id="results-main-content">
            <div class="results-list-header">
              <div class="results-list-title-row">
                <h3>Question Review</h3>
              </div>
              <div class="results-filter" id="results-filter">
                <button class="rf-btn active" data-filter="all">All</button>
                <button class="rf-btn" data-filter="correct">Correct</button>
                <button class="rf-btn" data-filter="wrong">Wrong</button>
                <button class="rf-btn" data-filter="skipped">Skipped</button>
              </div>
            </div>
            <div class="results-list" id="results-list"></div>
          </div>
        </div>
        <div class="bottom-bar">These are not AI generated content. We do not own the rights. For any issue , mail at inbox@sharepremium.in</div>
      </div>
    `;
    bindEvents();
  }

  // ==================== SIDEBAR TOGGLE (shared scope — used by bindEvents AND renderResults) ====================
  function setSidebarCollapsed(collapsed) {
    const sidebar = document.getElementById('results-sidebar');
    const arrowIcon = document.querySelector('.sidebar-arrow-icon');
    if (!sidebar) return;
    sidebar.classList.toggle('sidebar-collapsed', collapsed);
    if (arrowIcon) arrowIcon.innerHTML = collapsed ? '&#8250;' : '&#8249;';

    // Mobile overlay backdrop
    let backdrop = document.getElementById('score-overlay-backdrop');
    if (!backdrop) {
      backdrop = document.createElement('div');
      backdrop.id = 'score-overlay-backdrop';
      backdrop.className = 'score-overlay-backdrop';
      document.body.appendChild(backdrop);
      backdrop.addEventListener('click', () => setSidebarCollapsed(true));
    }
    if (!collapsed && window.innerWidth <= 900) {
      backdrop.classList.add('visible');
    } else {
      backdrop.classList.remove('visible');
    }
  }

  // ==================== NAV ====================
  function showView(v) {
    document.querySelectorAll('.view').forEach(el => el.classList.remove('active'));
    const el = document.getElementById('view-' + v);
    if (el) el.classList.add('active');
    state.view = v;
    window.scrollTo({ top: 0, behavior: 'instant' });
    // ECG: run only on dashboard
    if (v === 'dashboard') { if (typeof startECG === 'function') startECG(); initNotifBar(); }
    else { if (typeof stopECG === 'function') stopECG(); }
  }

  // ==================== EVENTS ====================
  // ── OTP digit-box controller ──────────────────────────────
  // Each .otp-digit is now a real <input type="tel"> → keyboard opens on mobile.
  // Reads collected value into the hidden <input> (id from data-target, or sibling).
  // Auto-submits when all boxes are filled.
  //
  // Map: otp-digits group id → { verifyBtnId, verifyFn }
  // verifyFn is resolved lazily (after all handlers are bound) so no ordering issue.
  const OTP_GROUP_MAP = {
    'otp-digit-boxes':       { verifyBtnId: 'btn-verify-otp',       verifyFn: () => authVerifyOTP() },
    'phone-otp-digit-boxes': { verifyBtnId: 'btn-phone-verify-otp', verifyFn: () => phoneVerifyOTP() },
    'mig-otp-digit-boxes':   { verifyBtnId: 'mig-btn-verify-otp',   verifyFn: () => migVerifyOTP() },
  };

  function initOtpBoxes() {
    document.querySelectorAll('.otp-digits').forEach(group => {
      const inputs = Array.from(group.querySelectorAll('input.otp-digit'));
      const N = inputs.length;
      // Get the hidden aggregator — either sibling hidden input or data-target
      const hiddenId = group.dataset.target;
      const hidden = hiddenId
        ? document.getElementById(hiddenId)
        : group.nextElementSibling;

      // Lookup auto-verify config for this group
      const autoVerify = OTP_GROUP_MAP[group.id];

      function syncHidden() {
        if (hidden) hidden.value = inputs.map(i => i.value).join('');
      }

      function tryAutoVerify() {
        if (!autoVerify) return;
        const allFilled = inputs.every(i => i.value.length === 1);
        if (!allFilled) return;
        // Blur all inputs so the keyboard closes on mobile
        inputs.forEach(i => i.blur());
        // Disable the verify button and show "Verifying OTP…"
        const btn = document.getElementById(autoVerify.verifyBtnId);
        if (btn) { btn.disabled = true; btn.textContent = 'Verifying OTP…'; }
        // Small tick so the UI repaints before the async call
        setTimeout(() => autoVerify.verifyFn(), 80);
      }

      inputs.forEach((inp, i) => {
        // On input: accept only one digit, move focus forward, then auto-verify
        inp.addEventListener('input', e => {
          // Strip non-digits, keep only last char
          let val = inp.value.replace(/\D/g, '');
          if (val.length > 1) val = val.slice(-1);
          inp.value = val;
          inp.classList.toggle('filled', val.length > 0);
          syncHidden();
          if (val && i < N - 1) {
            inputs[i + 1].focus();
          } else if (val && i === N - 1) {
            // Last box just filled — trigger auto-verify
            tryAutoVerify();
          }
        });

        // Handle paste — e.g. SMS autofill pastes full 6-digit code
        inp.addEventListener('paste', e => {
          e.preventDefault();
          const text = (e.clipboardData || window.clipboardData)
            .getData('text').replace(/\D/g, '').slice(0, N);
          inputs.forEach((b, j) => {
            b.value = text[j] || '';
            b.classList.toggle('filled', !!text[j]);
          });
          syncHidden();
          inputs[Math.min(text.length, N - 1)].focus();
          // Auto-verify if paste filled all boxes
          if (text.length >= N) tryAutoVerify();
        });

        // Backspace: clear current or move back
        inp.addEventListener('keydown', e => {
          if (e.key === 'Backspace') {
            if (inp.value) {
              inp.value = '';
              inp.classList.remove('filled');
              syncHidden();
            } else if (i > 0) {
              inputs[i - 1].focus();
              inputs[i - 1].value = '';
              inputs[i - 1].classList.remove('filled');
              syncHidden();
            }
            e.preventDefault();
          } else if (e.key === 'ArrowLeft') { e.preventDefault(); if (i > 0) inputs[i-1].focus(); }
          else if (e.key === 'ArrowRight') { e.preventDefault(); if (i < N-1) inputs[i+1].focus(); }
          else if (e.key === 'Enter') {
            e.preventDefault();
            if (hidden) hidden.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
          }
        });

        // On focus: select existing digit so typing replaces it
        inp.addEventListener('focus', () => inp.select());
      });
    });
  }

    // Clear digit boxes when OTP is reset by JS (e.g. resend)
  function clearOtpBoxes(groupId) {
    const group = document.getElementById(groupId);
    if (!group) return;
    group.querySelectorAll('input.otp-digit').forEach(b => {
      b.value = '';
      b.classList.remove('filled');
    });
  }

  // ==================== RIBBON ANIMATION ====================
  function initRibbonCanvas() {
    const canvas = document.getElementById('ribbon-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    const RIBBON_COUNT = 5;
    const SEG = 10;
    const ribbons = [];

    function rnd(a, b) { return a + Math.random() * (b - a); }

    function makeRibbon() {
      const W = canvas.width, H = canvas.height;
      const sx = rnd(0, W), sy = rnd(0, H);
      const pts = [];
      for (let i = 0; i <= SEG; i++) {
        pts.push({
          x: sx + rnd(-60, 60) * i * 0.3,
          y: sy + rnd(-60, 60) * i * 0.3,
          vx: rnd(-0.18, 0.18),
          vy: rnd(-0.18, 0.18),
          ox: rnd(0, Math.PI * 2),
          oy: rnd(0, Math.PI * 2),
          ax: rnd(0.4, 1.2),
          ay: rnd(0.4, 1.2),
          fx: rnd(0.0003, 0.0008),
          fy: rnd(0.0003, 0.0008),
        });
      }
      return {
        pts,
        width:    rnd(4, 10),
        hue:      rnd(0, 360),
        hueSpeed: rnd(-0.04, 0.04),
        alpha:    rnd(0.55, 0.80),
      };
    }

    function resize() {
      canvas.width  = window.innerWidth;
      canvas.height = window.innerHeight;
    }
    resize();
    window.addEventListener('resize', resize);
    for (let i = 0; i < RIBBON_COUNT; i++) ribbons.push(makeRibbon());

    let running = true, t = 0;

    function drawRibbon(r) {
      const pts = r.pts, N = pts.length;
      if (N < 2) return;
      // Main ribbon stroke (quadratic bezier spine)
      ctx.beginPath();
      ctx.moveTo(pts[0].x, pts[0].y);
      for (let i = 0; i < N - 1; i++) {
        const mx = (pts[i].x + pts[i+1].x) / 2;
        const my = (pts[i].y + pts[i+1].y) / 2;
        ctx.quadraticCurveTo(pts[i].x, pts[i].y, mx, my);
      }
      ctx.lineTo(pts[N-1].x, pts[N-1].y);
      ctx.strokeStyle = 'hsla(' + (r.hue % 360) + ',85%,55%,' + r.alpha + ')';
      ctx.lineWidth   = r.width;
      ctx.lineCap     = 'round';
      ctx.lineJoin    = 'round';
      ctx.shadowColor = 'hsla(' + (r.hue % 360) + ',85%,35%,0.18)';
      ctx.shadowBlur  = r.width * 1.8;
      ctx.stroke();
      ctx.shadowBlur  = 0;
      // Highlight streak for 3-D ribbon feel
      ctx.beginPath();
      ctx.moveTo(pts[0].x, pts[0].y);
      for (let i = 0; i < N - 1; i++) {
        const mx = (pts[i].x + pts[i+1].x) / 2;
        const my = (pts[i].y + pts[i+1].y) / 2;
        ctx.quadraticCurveTo(pts[i].x, pts[i].y, mx, my);
      }
      ctx.lineTo(pts[N-1].x, pts[N-1].y);
      ctx.strokeStyle = 'hsla(' + (r.hue % 360) + ',70%,90%,' + (r.alpha * 0.45) + ')';
      ctx.lineWidth   = r.width * 0.35;
      ctx.stroke();
    }

    function updateRibbon(r) {
      const W = canvas.width, H = canvas.height;
      r.hue += r.hueSpeed;
      for (const p of r.pts) {
        p.x += p.vx + Math.sin(t * p.fx + p.ox) * p.ax;
        p.y += p.vy + Math.sin(t * p.fy + p.oy) * p.ay;
      }
      const cx = r.pts.reduce((s, p) => s + p.x, 0) / r.pts.length;
      const cy = r.pts.reduce((s, p) => s + p.y, 0) / r.pts.length;
      if (cx < -120 || cx > W + 120 || cy < -120 || cy > H + 120) {
        const fresh = makeRibbon();
        Object.assign(r, fresh);
      }
    }

    function frame() {
      if (!running) return;
      const lv = document.getElementById('view-login');
      const visible = lv && lv.offsetParent !== null;
      if (!visible) { requestAnimationFrame(frame); return; }
      t++;
      ctx.fillStyle = 'rgba(239,246,255,0.18)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      for (const r of ribbons) { updateRibbon(r); drawRibbon(r); }
      requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);

    document.addEventListener('visibilitychange', () => {
      running = !document.hidden;
      if (running) requestAnimationFrame(frame);
    });
  }
  // ==================== END RIBBON ====================


  function bindEvents() {
    initOtpBoxes();
    initEyeBtns();
    initRibbonCanvas();
    document.getElementById('btn-send-otp').addEventListener('click', authSendOTP);
    document.getElementById('btn-verify-otp').addEventListener('click', authVerifyOTP);
    document.getElementById('btn-create-account').addEventListener('click', authSignup);
    document.getElementById('btn-login').addEventListener('click', doLogin);
    document.getElementById('btn-forgot-password').addEventListener('click', authForgotPassword);
    document.getElementById('btn-reset-password').addEventListener('click', authResetPassword);
    document.getElementById('btn-resend-otp').addEventListener('click', authResendOTP);
    document.getElementById('btn-back-email').addEventListener('click', () => authShowStep('email'));
    document.getElementById('inp-email').addEventListener('keydown', e => { if (e.key === 'Enter') authSendOTP(); });
    document.getElementById('inp-otp').addEventListener('keydown', e => { if (e.key === 'Enter') authVerifyOTP(); });
    document.getElementById('inp-pass').addEventListener('keydown', e => { if (e.key === 'Enter') doLogin(); });
    document.getElementById('inp-new-pass').addEventListener('input', authCheckPasswordRules);
    document.getElementById('inp-confirm-pass').addEventListener('keydown', e => { if (e.key === 'Enter') authSignup(); });
    // Legacy login
    document.getElementById('btn-legacy-login').addEventListener('click', doLegacyLogin);
    document.getElementById('inp-appno').addEventListener('keydown', e => { if (e.key === 'Enter') document.getElementById('inp-appno-pass').focus(); });
    document.getElementById('inp-appno-pass').addEventListener('keydown', e => { if (e.key === 'Enter') doLegacyLogin(); });
    // Phone auth
    document.getElementById('btn-phone-send-otp').addEventListener('click', phoneSendOTP);
    document.getElementById('btn-phone-verify-otp').addEventListener('click', phoneVerifyOTP);
    document.getElementById('btn-phone-resend-otp').addEventListener('click', phoneResendOTP);
    document.getElementById('btn-phone-create-account').addEventListener('click', phoneSignup);
    document.getElementById('btn-phone-login').addEventListener('click', phoneLogin);
    document.getElementById('btn-phone-forgot').addEventListener('click', () => {
      // Reuse already-verified OTP for reset (purpose was 'login', otp verified)
      if (!phoneState.otpVerified) { phoneSetError('phone-signin-err', 'Please verify your number first.'); return; }
      phoneSetError('phone-reset-err', '');
      document.getElementById('inp-phone-reset-pass').value = '';
      document.getElementById('inp-phone-reset-confirm').value = '';
      phoneShowStep('phone-reset-password');
    });
    document.getElementById('btn-phone-reset-password').addEventListener('click', phoneResetPassword);
    document.getElementById('inp-phone').addEventListener('keydown', e => { if (e.key === 'Enter') phoneSendOTP(); });
    document.getElementById('inp-phone-otp').addEventListener('keydown', e => { if (e.key === 'Enter') phoneVerifyOTP(); });
    document.getElementById('inp-phone-pass').addEventListener('keydown', e => { if (e.key === 'Enter') phoneLogin(); });
    document.getElementById('inp-phone-new-pass').addEventListener('input', phoneCheckPasswordRules);
    document.getElementById('inp-phone-confirm-pass').addEventListener('keydown', e => { if (e.key === 'Enter') phoneSignup(); });
    document.getElementById('inp-phone-reset-confirm').addEventListener('keydown', e => { if (e.key === 'Enter') phoneResetPassword(); });
    // Migration modal
    document.getElementById('mig-btn-send-otp').addEventListener('click', migSendOTP);
    document.getElementById('mig-btn-verify-otp').addEventListener('click', migVerifyOTP);
    document.getElementById('mig-btn-resend-otp').addEventListener('click', migResendOTP);
    document.getElementById('mig-btn-complete').addEventListener('click', migComplete);
    document.getElementById('mig-btn-continue').addEventListener('click', migContinue);
    // Close button: dismiss modal and log out
    document.getElementById('mig-btn-close').addEventListener('click', () => {
      document.getElementById('modal-migration').style.display = 'none';
      doLogout();
    });
    // Shake modal (instead of closing) when backdrop is tapped — signals required action
    document.getElementById('modal-migration').addEventListener('click', function(e) {
      if (e.target === this) {
        const modal = this.querySelector('.migration-modal');
        modal.classList.remove('shake');
        void modal.offsetWidth; // reflow to restart animation
        modal.classList.add('shake');
        modal.addEventListener('animationend', () => modal.classList.remove('shake'), { once: true });
      }
    });
    document.getElementById('mig-inp-pass').addEventListener('input', migCheckPasswordRules);
    document.getElementById('mig-inp-email').addEventListener('keydown', e => { if (e.key === 'Enter') migSendOTP(); });
    document.getElementById('mig-inp-otp').addEventListener('keydown', e => { if (e.key === 'Enter') migVerifyOTP(); });
    document.getElementById('mig-inp-pass-confirm').addEventListener('keydown', e => { if (e.key === 'Enter') migComplete(); });
    document.getElementById('btn-logout').addEventListener('click', doLogout);
    document.getElementById('modal-close').addEventListener('click', () => closeModal('modal-subject'));
    document.getElementById('instr-close').addEventListener('click', () => closeModal('modal-instructions'));
    bindThemeButtons();

    // Subject name selector → populate topics
    document.getElementById('sel-subject').addEventListener('change', () => {
      const sk = document.getElementById('sel-subject').value;
      state.selectedSubj = sk || null;
      populateTopicDropdown(sk);
      // Reset topic status when subject changes
      hideTopicStatus();
    });

    document.getElementById('sel-topic').addEventListener('change', () => {
      const tid = document.getElementById('sel-topic').value;
      if (tid && state.selectedSubj) {
        updateTopicStatus(state.selectedSubj, parseInt(tid));
      } else {
        hideTopicStatus();
      }
    });

    document.querySelectorAll('.mode-option').forEach(el => {
      el.addEventListener('click', () => {
        document.querySelectorAll('.mode-option').forEach(e => e.classList.remove('selected'));
        el.classList.add('selected');
        state.selectedMode = el.dataset.mode;
      });
    });
    state.selectedMode = 'real';

    // Filter tag selection
    document.getElementById('filter-tags').addEventListener('click', e => {
      const btn = e.target.closest('.filter-tag');
      if (!btn) return;
      document.querySelectorAll('.filter-tag').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      state.selectedFilter = btn.dataset.filter;
    });

    document.getElementById('btn-start-exam').addEventListener('click', () => {
      const tid = document.getElementById('sel-topic').value;
      if (!state.selectedSubj) { showDialog({ title: 'Selection Required', message: 'Please select a topic', type: 'alert', confirmText: 'OK' }); return; }
      if (!tid) { showDialog({ title: 'Selection Required', message: 'Please select a sub-topic', type: 'alert', confirmText: 'OK' }); return; }
      state.selectedTopic = parseInt(tid);
      closeModal('modal-subject');
      if (state.selectedMode === 'real') {
        openModal('modal-instructions');
      } else {
        startExam();
      }
    });

    document.getElementById('btn-begin-exam').addEventListener('click', () => { closeModal('modal-instructions'); startExam(); });
    document.getElementById('btn-save-next').addEventListener('click', doSaveNext);
    document.getElementById('btn-prev-q').addEventListener('click', doPrevQuestion);
    document.getElementById('btn-mark').addEventListener('click', doMarkReview);
    document.getElementById('btn-clear').addEventListener('click', doClearResponse);
    document.getElementById('btn-submit').addEventListener('click', () => {
      showDialog({
        title: 'Submit Exam',
        message: 'Are you sure you want to submit the exam now?',
        confirmText: 'Yes, Submit',
        cancelText: 'Cancel',
        onConfirm: doSubmitExam
      });
    });
    document.getElementById('btn-back-dash').addEventListener('click', () => {
      showView('dashboard');
      updateDashboardProgress();
      renderReviewCards();
      if (Object.keys(state.mainSubjects).length > 0) renderMainSubjectCards();
      else loadSubjects();
    });
    document.getElementById('btn-result-logout').addEventListener('click', doLogout);

    // Home icon and brand → go to dashboard
    document.getElementById('btn-home-result').addEventListener('click', () => showView('dashboard'));
    document.getElementById('result-brand-btn').addEventListener('click', () => showView('dashboard'));

    // Sidebar toggle — setSidebarCollapsed is defined in outer scope (shared with renderResults)
    document.getElementById('sidebar-toggle-arrow').addEventListener('click', () => {
      const sidebar = document.getElementById('results-sidebar');
      const isCollapsed = sidebar && sidebar.classList.contains('sidebar-collapsed');
      setSidebarCollapsed(!isCollapsed);
    });

    function setScoreCollapsed(collapsed) { setSidebarCollapsed(collapsed); }

    document.getElementById('results-filter').addEventListener('click', e => {
      const btn = e.target.closest('.rf-btn');
      if (!btn) return;
      document.querySelectorAll('.rf-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const f = btn.dataset.filter;
      // Close any open fullscreen card first
      const openCard = document.querySelector('.result-item.ri-fullscreen');
      if (openCard) {
        openCard.querySelector('.result-body')?.classList.remove('open');
        const tog = openCard.querySelector('.result-toggle');
        if (tog) tog.textContent = '▾';
        openCard.classList.remove('ri-expanded', 'ri-fullscreen');
        document.body.classList.remove('has-fullscreen');
      }
      // Show/hide items — use display:none so they take zero space
      document.querySelectorAll('#results-list .result-item').forEach(item => {
        const show = (f === 'all' || item.dataset.type === f);
        item.style.display = show ? '' : 'none';
      });
    });
  }

  function openModal(id) { document.getElementById(id).classList.add('open'); }
  function closeModal(id) { document.getElementById(id).classList.remove('open'); }

  // ==================== AUTH ====================

  // Auth state machine
  const authState = { mode: 'signin', email: '', name: '', otpVerified: false, lastOtp: '', forgotMode: false };
  // Migration state (separate from authState)
  const migState  = { migrationToken: '', userId: '', email: '', lastOtp: '' };

  // ── OAuth Social Sign-In ──────────────────────────────────

  /** Called once on login view render — hides buttons for disabled providers */
  function initOAuthButtons() {
    try {
      const { providers } = API.getEnabledOAuthProviders(); // sync — reads config.js flags
      const all = ['google', 'github', 'apple'];
      all.forEach(p => {
        const btn = document.querySelector(`.social-btn-${p}`);
        if (!btn) return;
        btn.style.display = providers.includes(p) ? '' : 'none';
      });
      // Show/hide the entire inline OAuth wrapper (label + buttons + error)
      const wrap = document.getElementById('inline-oauth-wrap');
      if (wrap) wrap.style.display = providers.length > 0 ? '' : 'none';
    } catch (_) {
      // On error, leave hidden — backend will reject if truly disabled
    }
  }

  window.handleOAuthLogin = async function(provider) {
    const errEl = document.getElementById('social-err');
    if (errEl) errEl.textContent = '';

    // Show a loading state on the button
    const btn = document.querySelector(`.social-btn-${provider}`);
    const originalText = btn ? btn.innerHTML : '';
    if (btn) { btn.disabled = true; btn.style.opacity = '0.65'; }

    try {
      const result = await API.oauthLogin(provider);
      authState.name = result.name || '';
      if (result.email) authState.email = result.email;
      state.userId = result.userId;
      await initUserSession(result.userId);
    } catch (e) {
      const msg = e.message || 'Sign-in failed. Please try again.';
      if (errEl) errEl.textContent = msg;
    } finally {
      if (btn) { btn.disabled = false; btn.style.opacity = ''; btn.innerHTML = originalText; }
    }
  };

  // Kick off provider-flag fetch as soon as the login card is in DOM
  (function waitForLoginView() {
    const wrap = document.getElementById('inline-oauth-wrap');
    if (wrap) { initOAuthButtons(); }
    else { setTimeout(waitForLoginView, 200); }
  })();

  window.authSwitchTab = function(tab) {
    authState.mode = tab;
    ['signin','signup','phone','legacy'].forEach(t => {
      document.getElementById(`tab-${t}`)?.classList.toggle('active', t === tab);
    });
    authSetError('login-err', '');
    const sendBtn = document.getElementById('btn-send-otp');
    if (sendBtn) sendBtn.textContent = tab === 'signup' ? 'Send Verification Code' : 'Continue';
    if (tab === 'legacy') { authShowStep('legacy'); return; }
    if (tab === 'phone')  { phoneShowStep('phone'); return; }
    authShowStep('email');
  };

  // ── Resend countdown helper ──────────────────────────────────
  function startResendCountdown(btn, seconds) {
    let remaining = seconds;
    btn.disabled = true;
    btn.textContent = `Resend code (${remaining}s)`;
    const timer = setInterval(() => {
      remaining--;
      if (remaining <= 0) {
        clearInterval(timer);
        btn.disabled = false;
        btn.textContent = 'Resend code';
      } else {
        btn.textContent = `Resend code (${remaining}s)`;
      }
    }, 1000);
  }

  // ── Password show/hide toggle ────────────────────────────────
  const EYE_OPEN = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>`;
  const EYE_SLASH = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19M1 1l22 22"/></svg>`;
  // FIX: expose on window so onclick="togglePasswordVisibility(...)" in HTML can find it.
  // Previously only defined inside the IIFE closure, invisible to inline onclick handlers
  // which resolve names on the global (window) scope.
  window.togglePasswordVisibility = function(inputId, eyeBtn) {
    const inp = document.getElementById(inputId);
    if (!inp) return;
    const nowHidden = inp.type === 'password';
    inp.type = nowHidden ? 'text' : 'password';
    eyeBtn.innerHTML = nowHidden ? EYE_SLASH : EYE_OPEN;
    eyeBtn.setAttribute('aria-label', nowHidden ? 'Hide password' : 'Show password');
  };
  function initEyeBtns() {
    // Replace emoji 👁 placeholders with SVG on ALL eye buttons including phone steps.
    document.querySelectorAll('.pw-eye-btn').forEach(btn => {
      btn.innerHTML = EYE_OPEN;
      btn.setAttribute('aria-label', 'Show password');
    });
  }

    function authShowStep(step) {
    const steps = ['email','legacy','otp','set-password','enter-password','reset-password'];
    steps.forEach(s => {
      const el = document.getElementById(`auth-step-${s}`);
      if (el) el.style.display = (s === step) ? '' : 'none';
    });
    // always hide all phone steps when email flow is shown
    ['phone','phone-otp','phone-set-password','phone-enter-password','phone-reset-password'].forEach(s => {
      const el = document.getElementById(`auth-step-${s}`);
      if (el) el.style.display = 'none';
    });
  }
  window.authShowStep = authShowStep;

  // ── Phone auth state & step controller ───────────────
  const phoneState = { phone: '', purpose: '', otpVerified: false, lastOtp: '' };
  const phoneStepIds = ['phone','phone-otp','phone-set-password','phone-enter-password','phone-reset-password'];

  function phoneShowStep(step) {
    const emailSteps = ['email','legacy','otp','set-password','enter-password','reset-password'];
    emailSteps.forEach(s => { const el = document.getElementById(`auth-step-${s}`); if (el) el.style.display = 'none'; });
    phoneStepIds.forEach(s => {
      const el = document.getElementById(`auth-step-${s}`);
      if (el) el.style.display = (s === step) ? '' : 'none';
    });
  }
  window.phoneShowStep = phoneShowStep;

  function phoneSetError(id, msg) { const el = document.getElementById(id); if (el) el.textContent = msg; }

  function phoneCheckPasswordRules() {
    const pw = document.getElementById('inp-phone-new-pass').value;
    const set = (id, ok) => {
      const el = document.getElementById(id); if (!el) return;
      el.textContent = (ok ? '✓ ' : '✗ ') + el.textContent.replace(/^[✓✗] /, '');
      el.style.color = ok ? 'var(--color-correct, #22c55e)' : '';
    };
    set('pw-phone-rule-len',   pw.length >= 8);
    set('pw-phone-rule-upper', /[A-Z]/.test(pw));
    set('pw-phone-rule-lower', /[a-z]/.test(pw));
    set('pw-phone-rule-num',   /[0-9]/.test(pw));
  }

  async function phoneSendOTP() {
    const raw = document.getElementById('inp-phone').value.replace(/\D/g,'');
    phoneSetError('phone-err', '');
    if (!raw || raw.length !== 10) { phoneSetError('phone-err', 'Please enter a valid 10-digit mobile number.'); return; }
    const btn = document.getElementById('btn-phone-send-otp');
    btn.disabled = true; btn.textContent = 'Sending…';
    try {
      // Try signup first; if account exists, switch to login OTP
      try {
        await API.phoneSendOTP(raw, 'signup');
        phoneState.phone = raw; phoneState.purpose = 'signup';
      } catch (e) {
        if (e.message && e.message.includes('already exists')) {
          await API.phoneSendOTP(raw, 'login');
          phoneState.phone = raw; phoneState.purpose = 'login';
        } else throw e;
      }
      document.getElementById('phone-otp-display').textContent = '+91 ' + raw;
      document.getElementById('inp-phone-otp').value = ''; clearOtpBoxes('phone-otp-digit-boxes');
      phoneSetError('phone-otp-err', '');
      phoneShowStep('phone-otp');
      startResendCountdown(document.getElementById('btn-phone-resend-otp'), 60);
      const first = document.querySelector('#phone-otp-digit-boxes input.otp-digit');
      if (first) setTimeout(() => first.focus(), 120);
    } catch (err) {
      phoneSetError('phone-err', err.message || 'Failed to send code. Try again.');
    } finally { btn.disabled = false; btn.textContent = 'Send Code'; }
  }

  async function phoneResendOTP() {
    const btn = document.getElementById('btn-phone-resend-otp');
    btn.disabled = true; btn.textContent = 'Sending…';
    phoneSetError('phone-otp-err', '');
    try {
      await API.phoneSendOTP(phoneState.phone, phoneState.purpose);
      phoneSetError('phone-otp-err', '✅ New code sent!');
      document.getElementById('inp-phone-otp').value = ''; clearOtpBoxes('phone-otp-digit-boxes');
    } catch (err) { phoneSetError('phone-otp-err', err.message || 'Failed to resend.'); }
    finally { startResendCountdown(btn, 60); }
  }

  async function phoneVerifyOTP() {
    const otp = document.getElementById('inp-phone-otp').value.trim();
    phoneSetError('phone-otp-err', '');
    if (!otp || otp.length !== 6) { phoneSetError('phone-otp-err', 'Please enter the 6-digit code.'); return; }
    const btn = document.getElementById('btn-phone-verify-otp');
    btn.disabled = true; btn.textContent = 'Verifying…';
    try {
      await API.phoneVerifyOTP(phoneState.phone, otp);
      phoneState.otpVerified = true; phoneState.lastOtp = otp;
      if (phoneState.purpose === 'signup') {
        document.getElementById('inp-phone-name').value = '';
        document.getElementById('inp-phone-new-pass').value = '';
        document.getElementById('inp-phone-confirm-pass').value = '';
        phoneSetError('phone-signup-err', '');
        phoneShowStep('phone-set-password');
        setTimeout(() => document.getElementById('inp-phone-name')?.focus(), 100);
      } else {
        document.getElementById('phone-signin-display').textContent = '+91 ' + phoneState.phone;
        document.getElementById('inp-phone-pass').value = '';
        phoneSetError('phone-signin-err', '');
        phoneShowStep('phone-enter-password');
        setTimeout(() => document.getElementById('inp-phone-pass')?.focus(), 100);
      }
    } catch (err) {
      phoneSetError('phone-otp-err', err.message || 'Invalid code. Please try again.');
    } finally { btn.disabled = false; btn.textContent = 'Verify Code'; }
  }

  async function phoneSignup() {
    const name    = (document.getElementById('inp-phone-name')?.value || '').trim();
    const pass    = document.getElementById('inp-phone-new-pass').value;
    const confirm = document.getElementById('inp-phone-confirm-pass').value;
    phoneSetError('phone-signup-err', '');
    if (!name)            { phoneSetError('phone-signup-err', 'Please enter your name.'); return; }
    if (!pass)            { phoneSetError('phone-signup-err', 'Please enter a password.'); return; }
    if (pass !== confirm) { phoneSetError('phone-signup-err', 'Passwords do not match.'); return; }
    const btn = document.getElementById('btn-phone-create-account');
    btn.disabled = true; btn.textContent = 'Creating account…';
    try {
      const data = await API.phoneSignup(phoneState.phone, phoneState.lastOtp, pass, name);
      authState.name = data.name || name;
      state.userId = data.userId;
      await initUserSession(data.userId);
    } catch (err) {
      phoneSetError('phone-signup-err', err.message || 'Failed to create account.');
    } finally { btn.disabled = false; btn.textContent = 'Create Account'; }
  }

  async function phoneLogin() {
    const pass = document.getElementById('inp-phone-pass').value;
    phoneSetError('phone-signin-err', '');
    if (!pass) { phoneSetError('phone-signin-err', 'Please enter your password.'); return; }
    const btn = document.getElementById('btn-phone-login');
    btn.disabled = true; btn.textContent = 'Signing in…';
    try {
      const data = await API.phoneLogin(phoneState.phone, pass);
      authState.name = data.name || '';
      state.userId = data.userId;
      await initUserSession(data.userId);
    } catch (err) {
      phoneSetError('phone-signin-err', err.message || 'Invalid number or password.');
    } finally { btn.disabled = false; btn.textContent = 'Sign In'; }
  }

  async function phoneResetPassword() {
    const newPass = document.getElementById('inp-phone-reset-pass').value;
    const confirm = document.getElementById('inp-phone-reset-confirm').value;
    phoneSetError('phone-reset-err', '');
    if (!newPass)           { phoneSetError('phone-reset-err', 'Please enter a new password.'); return; }
    if (newPass !== confirm) { phoneSetError('phone-reset-err', 'Passwords do not match.'); return; }
    const btn = document.getElementById('btn-phone-reset-password');
    btn.disabled = true; btn.textContent = 'Resetting…';
    try {
      await API.phoneResetPassword(phoneState.phone, phoneState.lastOtp, newPass);
      phoneSetError('phone-reset-err', '✅ Password reset! Please sign in.');
      setTimeout(() => phoneShowStep('phone'), 1500);
    } catch (err) {
      phoneSetError('phone-reset-err', err.message || 'Failed to reset password.');
    } finally { btn.disabled = false; btn.textContent = 'Reset Password'; }
  }

  function authSetError(stepId, msg) {
    const el = document.getElementById(stepId);
    if (el) el.textContent = msg;
  }

  function authCheckPasswordRules() {
    const pw = document.getElementById('inp-new-pass').value;
    const set = (id, ok) => {
      const el = document.getElementById(id);
      if (!el) return;
      el.textContent = (ok ? '✓ ' : '✗ ') + el.textContent.replace(/^[✓✗] /, '');
      el.style.color = ok ? 'var(--color-correct, #22c55e)' : '';
    };
    set('pw-rule-len',   pw.length >= 8);
    set('pw-rule-upper', /[A-Z]/.test(pw));
    set('pw-rule-lower', /[a-z]/.test(pw));
    set('pw-rule-num',   /[0-9]/.test(pw));
  }

  async function authSendOTP() {
    const email = document.getElementById('inp-email').value.trim().toLowerCase();
    authSetError('login-err', '');
    if (!email) { authSetError('login-err', 'Please enter your email address.'); return; }
    const btn = document.getElementById('btn-send-otp');
    btn.disabled = true; btn.textContent = 'Please wait…';
    try {
      if (authState.mode === 'signin') {
        // For sign-in: no OTP needed — go straight to password entry
        authState.email = email;
        document.getElementById('signin-email-display').textContent = email;
        document.getElementById('inp-pass').value = '';
        authSetError('signin-err', '');
        authShowStep('enter-password');
      } else {
        // For sign-up: send OTP for email verification
        await API.sendOTP(email, 'signup');
        authState.email = email;
        authState.otpVerified = false;
        document.getElementById('otp-email-display').textContent = email;
        document.getElementById('otp-step-title').textContent = 'Verify Email';
        document.getElementById('otp-desc').innerHTML = `Enter the 6-digit code sent to <strong>${esc(email)}</strong>`;
        document.getElementById('inp-otp').value = ''; clearOtpBoxes('otp-digit-boxes');
        authSetError('otp-err', '');
        authShowStep('otp');
        // Auto-start 60s resend cooldown on first send
        startResendCountdown(document.getElementById('btn-resend-otp'), 60);
        // Autofocus first OTP input
        const firstOtp = document.querySelector('#otp-digit-boxes input.otp-digit');
        if (firstOtp) setTimeout(() => firstOtp.focus(), 120);
      }
    } catch (err) {
      authSetError('login-err', err.message || 'Failed to send code. Please try again.');
    } finally {
      btn.disabled = false;
      btn.textContent = authState.mode === 'signup' ? 'Send Verification Code' : 'Continue';
    }
  }

  async function authResendOTP() {
    const btn = document.getElementById('btn-resend-otp');
    btn.disabled = true; btn.textContent = 'Sending…';
    authSetError('otp-err', '');
    try {
      await API.sendOTP(authState.email, authState.mode === 'signup' ? 'signup' : 'login');
      authSetError('otp-err', '✅ New code sent!');
      document.getElementById('inp-otp').value = ''; clearOtpBoxes('otp-digit-boxes');
    } catch (err) {
      authSetError('otp-err', err.message || 'Failed to resend code.');
    } finally {
      startResendCountdown(btn, 60);
    }
  }

  async function authVerifyOTP() {
    const otp = document.getElementById('inp-otp').value.trim();
    authSetError('otp-err', '');
    if (!otp || otp.length !== 6) { authSetError('otp-err', 'Please enter the 6-digit code.'); return; }
    const btn = document.getElementById('btn-verify-otp');
    btn.disabled = true; btn.textContent = 'Verifying…';
    try {
      await API.verifyOTP(authState.email, otp);
      authState.otpVerified = true;
      authState.lastOtp = otp;
      if (authState.mode === 'signup') {
        authShowStep('set-password');
        authSetError('signup-err', '');
      } else if (authState.forgotMode) {
        authShowStep('reset-password');
        authSetError('reset-err', '');
      } else {
        document.getElementById('signin-email-display').textContent = authState.email;
        document.getElementById('inp-pass').value = '';
        authSetError('signin-err', '');
        authShowStep('enter-password');
      }
    } catch (err) {
      authSetError('otp-err', err.message || 'Invalid code. Please try again.');
    } finally {
      btn.disabled = false; btn.textContent = 'Verify Code';
    }
  }

  async function authSignup() {
    const name     = (document.getElementById('inp-name')?.value || '').trim();
    const password = document.getElementById('inp-new-pass').value;
    const confirm  = document.getElementById('inp-confirm-pass').value;
    authSetError('signup-err', '');
    if (!name) { authSetError('signup-err', 'Please enter your name.'); return; }
    if (!password) { authSetError('signup-err', 'Please enter a password.'); return; }
    if (password !== confirm) { authSetError('signup-err', 'Passwords do not match.'); return; }
    const btn = document.getElementById('btn-create-account');
    btn.disabled = true; btn.textContent = 'Creating account…';
    try {
      const data = await API.signup(authState.email, authState.lastOtp, password, name);
      authState.name = data.name || name;
      state.userId = data.userId;
      await initUserSession(data.userId);
    } catch (err) {
      authSetError('signup-err', err.message || 'Sign up failed. Please try again.');
    } finally {
      btn.disabled = false; btn.textContent = 'Create Account';
    }
  }

  async function doLogin() {
    const pass = document.getElementById('inp-pass').value;
    authSetError('signin-err', '');
    if (!pass) { authSetError('signin-err', 'Please enter your password.'); return; }
    const btn = document.getElementById('btn-login');
    btn.disabled = true; btn.textContent = 'Signing in…';
    try {
      const data = await API.emailLogin(authState.email, pass);
      authState.name = data.name || '';
      state.userId = data.userId;
      await initUserSession(data.userId);
    } catch (err) {
      // If backend flags this email needs OTP verification (unverified legacy account)
      if (err.message && err.message.includes('not verified')) {
        authSetError('signin-err', err.message + ' Please use the OTP flow below.');
        // Send OTP for verification and route to OTP step
        try {
          await API.sendOTP(authState.email, 'login');
          authState.otpVerified = false;
          document.getElementById('otp-email-display').textContent = authState.email;
          document.getElementById('otp-step-title').textContent = 'Verify Email';
          document.getElementById('otp-desc').innerHTML = `Enter the 6-digit code sent to <strong>${esc(authState.email)}</strong> to verify your account.`;
          document.getElementById('inp-otp').value = ''; clearOtpBoxes('otp-digit-boxes');
          authSetError('otp-err', '');
          authShowStep('otp');
        } catch {}
      } else {
        authSetError('signin-err', err.message || 'Invalid credentials. Please try again.');
      }
    } finally {
      btn.disabled = false; btn.textContent = 'Sign In';
    }
  }

  function authForgotPassword() {
    authState.forgotMode = true;
    authSetError('signin-err', '');
    // Re-send OTP for reset
    const btn = document.getElementById('btn-send-otp');
    btn.textContent = 'Send Verification Code';
    document.getElementById('otp-step-title').textContent = 'Reset Password';
    document.getElementById('otp-desc').innerHTML = `Enter the 6-digit code sent to <strong>${esc(authState.email)}</strong> to reset your password.`;
    document.getElementById('inp-otp').value = ''; clearOtpBoxes('otp-digit-boxes');
    authSetError('otp-err', '');
    // Reuse send-otp with login purpose
    API.sendOTP(authState.email, 'login').then(() => {
      authShowStep('otp');
    }).catch(err => {
      authSetError('signin-err', err.message || 'Failed to send reset code.');
    });
  }

  async function authResetPassword() {
    const newPass = document.getElementById('inp-reset-pass').value;
    const confirm = document.getElementById('inp-reset-confirm').value;
    authSetError('reset-err', '');
    if (!newPass) { authSetError('reset-err', 'Please enter a new password.'); return; }
    if (newPass !== confirm) { authSetError('reset-err', 'Passwords do not match.'); return; }
    const btn = document.getElementById('btn-reset-password');
    btn.disabled = true; btn.textContent = 'Saving…';
    try {
      await API.resetPassword(authState.email, authState.lastOtp, newPass);
      authState.forgotMode = false;
      authSetError('reset-err', '');
      // Auto sign-in after reset (password-only — reset already proved identity via OTP)
      const data = await API.emailLogin(authState.email, newPass);
      authState.name = data.name || '';
      state.userId = data.userId;
      await initUserSession(data.userId);
    } catch (err) {
      authSetError('reset-err', err.message || 'Failed to reset password.');
    } finally {
      btn.disabled = false; btn.textContent = 'Reset Password';
    }
  }

  // signal: optional AbortSignal from tryAutoLogin's deadline controller.
  // When the 20 s deadline fires, all in-flight startup requests are cancelled
  // immediately rather than continuing to run in the background.
  async function initUserSession(userId, signal) {
    _progressLoaded = false;  // block saves until we know what's in DB
    const displayName = authState.name || API.getSavedName() || authState.email || `ID: ${userId}`;
    // Desktop nav: show "Hello Dr. {name}!" format
    document.getElementById('nav-user-label').textContent = `Hello Dr. ${displayName}!`;
    const resultNavUser = document.getElementById('result-nav-user-label');
    if (resultNavUser) resultNavUser.textContent = `Hello Dr. ${displayName}!`;
    // Mobile greeting banner: animate letter by letter
    (function animateMobileGreeting(name) {
      const banner = document.getElementById('mobile-greeting-banner');
      const el = document.getElementById('mobile-greeting-text');
      if (!el || !banner) return;
      const fullText = 'Hello Dr. ' + name + '!';
      el.textContent = '';
      banner.classList.remove('greeting-visible');
      // small delay to allow CSS transition to trigger properly
      setTimeout(function() {
        banner.classList.add('greeting-visible');
        var i = 0;
        function typeNext() {
          if (i <= fullText.length) {
            el.textContent = fullText.slice(0, i);
            i++;
            setTimeout(typeNext, 60);
          }
        }
        typeNext();
      }, 120);
    })(displayName);
    initTheme();
    bindThemeButtons();
    // NOTE: showView('dashboard') is deliberately NOT called here yet.
    // The loading screen stays visible until loadSubjects() has fully
    // populated the subjects grid — only then do we swap screens.
    // This prevents the blank white flash that occurred when the splash
    // fade-out (400ms setTimeout) finished before the grid was rendered.
    try {
      // Single /api/user/dashboard call replaces 4 separate requests
      // (getProgress + getResume + getTopicStats + getTestReviews).
      // Falls back gracefully to individual calls if the endpoint is unavailable
      // (e.g. during a rolling deploy before server_v2 is live).
      let progress = {}, resume = null, stats = {}, reviews = {}, liveExam = null;
      try {
        const dash = await API.getDashboard(signal);
        progress = dash.progress || {};
        resume   = dash.resume   || null;
        stats    = dash.stats    || {};
        reviews  = dash.reviews  || {};
        liveExam = dash.liveExam || null;
      } catch (dashErr) {
        // Fallback: dashboard endpoint not yet deployed — use individual calls
        if (!signal || !signal.aborted) {
          const [progRes, resumeRes, statsRes, reviewsRes] = await Promise.all([
            API.getProgress(signal),
            API.getResume(signal),
            API.getTopicStats(signal),
            API.getTestReviews(signal)
          ]);
          progress = progRes.progress || {};
          resume   = resumeRes.resume || null;
          stats    = statsRes.stats   || {};
          reviews  = reviewsRes.reviews || {};
        }
      }
      if (Object.keys(progress).length) state.progress = progress;
      state.resumeData    = resume;
      state.liveExamData  = liveExam;
      state.topicStats    = stats;
      state.testReviews   = reviews;
      state.reviewDismissedAt = localStorage.getItem(`review_dismissed_${state.userId}`) || null;
    } catch {}
    _progressLoaded = true;  // safe to save from this point forward

    // If the deadline already aborted us, don't show the dashboard at all —
    // tryAutoLogin will show the login screen instead.
    if (signal && signal.aborted) return;

    let subjectsLoaded = false;
    try {
      await loadSubjects(signal);
      subjectsLoaded = true;
    } catch (e) {
      // loadSubjects failed (timeout or abort) — check abort again before showing dashboard
      if (signal && signal.aborted) return;
    }

    // Only show the dashboard if subjects actually loaded.
    // If loadSubjects failed for a non-abort reason (e.g. 500 error), still show
    // dashboard — user can refresh subjects manually — but the grid will show
    // its own error state from inside loadSubjects.
    try {
      showView('dashboard');
      renderResumeCard();
      renderLiveExamCard();
      renderReviewCards();
      showPWABanner();
    } catch (renderErr) {
      // Defensive: rendering threw unexpectedly — still show the dashboard view
      // so the user isn't left on a blank page.
      console.error('[initUserSession] render error after loadSubjects:', renderErr);
      try { showView('dashboard'); } catch (_) {}
    }
  }

  async function tryAutoLogin() {
    // Token is now an httpOnly cookie — JS cannot read it.
    // We check for a userId in localStorage as a quick pre-flight signal
    // that the user was previously logged in. The real auth check is
    // validateSession() which sends the cookie to the server AND checks the DB.
    const userId = API.getSavedUser();
    if (!userId) return false;
    state.userId = userId;
    const email = API.getSavedEmail();
    if (email) authState.email = email;
    const savedName = API.getSavedName();
    if (savedName) authState.name = savedName;

    const controller = new AbortController();
    const signal = controller.signal;

    let deadlineTimer = null;
    const deadlinePromise = new Promise(function(resolve) {
      deadlineTimer = setTimeout(function() {
        controller.abort();
        resolve('DEADLINE');
      }, 20000);
    });

    const loginAttempt = (async () => {
      const MAX_TRIES = 3;
      for (let attempt = 1; attempt <= MAX_TRIES; attempt++) {
        try {
          // Single DB-validated session check — verifies JWT (via cookie) +
          // confirms session is active in DB. Returns fresh user info + session key.
          const sessionData = await API.validateSession(signal);
          state.userId = sessionData.userId;
          if (sessionData.email) authState.email = sessionData.email;
          if (sessionData.name)  authState.name  = sessionData.name;

          // NOTE: getSubjects is intentionally NOT called here.
          // loadSubjects() inside initUserSession already fetches both
          // getMainSubjects + getSubjects in parallel. Calling getSubjects
          // here too caused a redundant extra round-trip on every signed-in
          // page load, adding needless seconds to the splash screen duration.
          await initUserSession(sessionData.userId, signal);
          return true;
        } catch (err) {
          if (signal.aborted) return false;

          const isTimeout = err.message && err.message.includes('timed out');
          const isAuth    = err.message && (
            err.message.includes('401') ||
            err.message.toLowerCase().includes('unauthorized') ||
            err.message.toLowerCase().includes('invalid token') ||
            err.message.toLowerCase().includes('session expired')
          );
          const isLast = attempt === MAX_TRIES;

          if (isAuth) { API.clearToken(); return false; }
          if (!isTimeout) { API.clearToken(); return false; }

          if (!isLast) {
            const ls = document.getElementById('loading-screen');
            const hint = ls && ls.querySelector('.loading-hint');
            if (hint) hint.textContent = `Connecting… (attempt ${attempt + 1}/${MAX_TRIES})`;
            await new Promise(r => setTimeout(r, 3000));
            continue;
          }
          API.clearToken();
          return false;
        }
      }
      API.clearToken();
      return false;
    })();

    const result = await Promise.race([loginAttempt, deadlinePromise]);
    clearTimeout(deadlineTimer);

    if (result === 'DEADLINE') {
      console.warn('tryAutoLogin: 20 s deadline hit, all requests aborted, showing login');
      return false;
    }
    return result;
  }

  async function doLogout() {
    localStorage.removeItem(`review_dismissed_${API.getSavedUser()}`);
    await API.logout();  // marks session inactive in DB, then clears localStorage + in-memory keys
    _progressLoaded = false;
    state.userId = null; state.subjects = {}; state.mainSubjects = {};
    state.progress = {}; state.topicStats = {}; state.testReviews = {}; state.reviewDismissedAt = null; state.resumeData = null; state.liveExamData = null;
    state.selectedFilter = 'all';
    authState.email = ''; authState.name = ''; authState.otpVerified = false; authState.lastOtp = ''; authState.forgotMode = false;
    stopAllTimers();
    const g = document.getElementById('subjects-grid');
    if (g) g.innerHTML = '';
    showView('login');
    authShowStep('email');
    document.getElementById('inp-email').value = '';
  }

  // ── Legacy login (old Application No = Password users) ──
  async function doLegacyLogin() {
    const appNo = document.getElementById('inp-appno').value.trim();
    const pass  = document.getElementById('inp-appno-pass').value.trim();
    authSetError('legacy-err', '');
    if (!appNo || !pass) { authSetError('legacy-err', 'Please fill in all fields.'); return; }
    const btn = document.getElementById('btn-legacy-login');
    btn.disabled = true; btn.textContent = 'Signing in…';
    try {
      const data = await API.legacyLogin(appNo, pass);
      if (data.needsEmailMigration) {
        // Store migration token and open modal
        migState.migrationToken = data.migrationToken;
        migState.userId = data.userId;
        migState.email  = '';
        migState.lastOtp = '';
        openMigrationModal();
      } else {
        // Already migrated — go straight to app
        authState.email = data.email || '';
        authState.name = data.name || '';
        state.userId = data.userId;
        await initUserSession(data.userId);
      }
    } catch (err) {
      authSetError('legacy-err', err.message || 'Invalid application number or password.');
    } finally {
      btn.disabled = false; btn.textContent = 'Sign In';
    }
  }

  // ── Migration modal helpers ──────────────────────────────
  function openMigrationModal() {
    migShowStep('email');
    document.getElementById('modal-migration').classList.add('open');
    document.getElementById('mig-inp-email').value = '';
    authSetError('mig-err-email', '');
  }

  function migShowStep(step) {
    ['email','otp','password','done'].forEach(s => {
      const el = document.getElementById(`mig-step-${s}`);
      if (el) el.style.display = s === step ? '' : 'none';
    });
  }

  function migCheckPasswordRules() {
    const pw = document.getElementById('mig-inp-pass').value;
    const set = (id, ok) => {
      const el = document.getElementById(id);
      if (!el) return;
      el.textContent = (ok ? '✓ ' : '✗ ') + el.textContent.replace(/^[✓✗] /, '');
      el.style.color = ok ? 'var(--color-correct, #22c55e)' : '';
    };
    set('mig-pw-rule-len',   pw.length >= 8);
    set('mig-pw-rule-upper', /[A-Z]/.test(pw));
    set('mig-pw-rule-lower', /[a-z]/.test(pw));
    set('mig-pw-rule-num',   /[0-9]/.test(pw));
  }

  async function migSendOTP() {
    const email = document.getElementById('mig-inp-email').value.trim().toLowerCase();
    authSetError('mig-err-email', '');
    if (!email) { authSetError('mig-err-email', 'Please enter your email address.'); return; }
    const btn = document.getElementById('mig-btn-send-otp');
    btn.disabled = true; btn.textContent = 'Sending…';
    try {
      await API.sendOTP(email, 'signup');
      migState.email = email;
      document.getElementById('mig-otp-email-display').textContent = email;
      document.getElementById('mig-inp-otp').value = ''; clearOtpBoxes('mig-otp-digit-boxes');
      authSetError('mig-err-otp', '');
      migShowStep('otp');
      startResendCountdown(document.getElementById('mig-btn-resend-otp'), 60);
      const firstMigOtp = document.querySelector('#mig-otp-digit-boxes input.otp-digit');
      if (firstMigOtp) setTimeout(() => firstMigOtp.focus(), 120);
    } catch (err) {
      authSetError('mig-err-email', err.message || 'Failed to send code. Please try again.');
    } finally {
      btn.disabled = false; btn.textContent = 'Send Verification Code';
    }
  }

  async function migResendOTP() {
    const btn = document.getElementById('mig-btn-resend-otp');
    btn.disabled = true; btn.textContent = 'Sending…';
    authSetError('mig-err-otp', '');
    try {
      await API.sendOTP(migState.email, 'signup');
      authSetError('mig-err-otp', '✅ New code sent!');
      document.getElementById('mig-inp-otp').value = ''; clearOtpBoxes('mig-otp-digit-boxes');
    } catch (err) {
      authSetError('mig-err-otp', err.message || 'Failed to resend.');
    } finally {
      startResendCountdown(btn, 60);
    }
  }

  async function migVerifyOTP() {
    const otp = document.getElementById('mig-inp-otp').value.trim();
    authSetError('mig-err-otp', '');
    if (!otp || otp.length !== 6) { authSetError('mig-err-otp', 'Please enter the 6-digit code.'); return; }
    const btn = document.getElementById('mig-btn-verify-otp');
    btn.disabled = true; btn.textContent = 'Verifying…';
    try {
      await API.verifyOTP(migState.email, otp);
      migState.lastOtp = otp;
      document.getElementById('mig-inp-name').value = '';
      document.getElementById('mig-inp-pass').value = '';
      document.getElementById('mig-inp-pass-confirm').value = '';
      authSetError('mig-err-pass', '');
      migShowStep('password');
      // Focus name field
      setTimeout(() => { const n = document.getElementById('mig-inp-name'); if (n) n.focus(); }, 80);
    } catch (err) {
      authSetError('mig-err-otp', err.message || 'Invalid code. Please try again.');
    } finally {
      btn.disabled = false; btn.textContent = 'Verify Code';
    }
  }

  async function migComplete() {
    const name     = (document.getElementById('mig-inp-name').value || '').trim();
    const password = document.getElementById('mig-inp-pass').value;
    const confirm  = document.getElementById('mig-inp-pass-confirm').value;
    authSetError('mig-err-pass', '');
    if (!name) { authSetError('mig-err-pass', 'Please enter your full name.'); document.getElementById('mig-inp-name').focus(); return; }
    if (!password) { authSetError('mig-err-pass', 'Please enter a password.'); return; }
    if (password !== confirm) { authSetError('mig-err-pass', 'Passwords do not match.'); return; }
    const btn = document.getElementById('mig-btn-complete');
    btn.disabled = true; btn.textContent = 'Saving…';
    try {
      const data = await API.migrateEmail(migState.migrationToken, migState.email, migState.lastOtp, password, name);
      // Token now set; store userId/email/name for session
      state.userId  = data.userId;
      authState.email = data.email;
      authState.name = data.name || name;
      migShowStep('done');
    } catch (err) {
      authSetError('mig-err-pass', err.message || 'Migration failed. Please try again.');
    } finally {
      btn.disabled = false; btn.textContent = 'Complete Upgrade';
    }
  }

  async function migContinue() {
    document.getElementById('modal-migration').classList.remove('open');
    await initUserSession(state.userId);
  }

  // ==================== DASHBOARD ====================
  async function loadSubjects(signal) {
    const grid = document.getElementById('subjects-grid');
    grid.innerHTML = `
      <div class="skeleton" style="height:140px;border-radius:12px;"></div>
      <div class="skeleton" style="height:140px;border-radius:12px;"></div>
      <div class="skeleton" style="height:140px;border-radius:12px;"></div>
      <div class="skeleton" style="height:140px;border-radius:12px;"></div>`;
    try {
      // Load both in parallel; signal lets tryAutoLogin cancel these if 20s deadline fires
      const [mainData, flatData] = await Promise.all([
        API.getMainSubjects(signal),
        API.getSubjects(signal)
      ]);
      state.mainSubjects = mainData;
      state.subjects = flatData;

      if (!Object.keys(mainData).length) {
        grid.innerHTML = `<div style="grid-column:1/-1;text-align:center;padding:48px 24px;">
          <div style="font-size:48px;margin-bottom:16px;">📂</div>
          <h3>No topics loaded yet</h3>
          <p style="font-size:14px;color:var(--text2);">Place JSON data files in backend/data/ and restart.</p></div>`;
        return;
      }
      renderMainSubjectCards();
      updateDashboardProgress();
    } catch (err) {
      // Show error UI in the grid for non-abort failures (network error, 500, etc.)
      if (!signal || !signal.aborted) {
        grid.innerHTML = `<div style="grid-column:1/-1;text-align:center;padding:48px 24px;">
          <div style="font-size:40px;margin-bottom:12px;">⚠️</div>
          <p style="font-weight:600;color:var(--danger);">Failed to load topics</p>
          <p style="font-size:13px;color:var(--text2);margin-top:8px;">${esc(err.message || 'Network error.')}</p>
          <button class="btn-primary" style="margin-top:20px;max-width:200px;" onclick="location.reload()">Retry</button></div>`;
      }
      // Re-throw so initUserSession's guard can detect abort vs real error
      throw err;
    }
  }

  // ── Dashboard Notification Bar ────────────────────────────────────────────
  // Reads NOTIFICATION from config.js ("ON_N1" / "OFF_N1") and
  // NOTIFICATION_TEXT from notification.js, then shows / hides the bar.
  // Dismissed state is stored in localStorage keyed by the Nxx version so
  // a new Nxx always reappears even for users who dismissed the previous one.
  function initNotifBar() {
    const bar      = document.getElementById('notif-bar');
    const barText  = document.getElementById('notif-bar-text');
    const closeBtn = document.getElementById('notif-bar-close');
    if (!bar) return;

    // Parse the config flag — expected shape: "ON_N1" or "OFF_N2" etc.
    const cfg = (typeof NOTIFICATION === 'string') ? NOTIFICATION.trim() : '';
    const match = cfg.match(/^(ON|OFF)_(N\d+)$/i);

    // If flag is absent, malformed, or OFF → keep bar hidden
    if (!match || match[1].toUpperCase() === 'OFF') {
      bar.classList.add('notif-bar--hidden');
      return;
    }

    const notifId = match[2].toUpperCase(); // e.g. "N1"
    const lsKey   = 'notif_dismissed_' + notifId;

    // Already dismissed by the user for this Nxx → keep hidden
    if (localStorage.getItem(lsKey) === '1') {
      bar.classList.add('notif-bar--hidden');
      return;
    }

    // Set text from notification.js (fallback to empty string if missing)
    const text = (typeof NOTIFICATION_TEXT === 'string') ? NOTIFICATION_TEXT : '';
    barText.textContent = text;

    // Show the bar
    bar.classList.remove('notif-bar--hidden');

    // Close button — dismiss and remember via localStorage
    // Guard: remove old listener before adding new one (in case dashboard re-opens)
    const freshClose = closeBtn.cloneNode(true);
    closeBtn.parentNode.replaceChild(freshClose, closeBtn);
    freshClose.addEventListener('click', () => {
      localStorage.setItem(lsKey, '1');
      bar.classList.add('notif-bar--hidden');
    });
  }

  function updateDashboardProgress() {
    const p = totalProgress();
    if (!p.total) return;
    document.getElementById('progress-banner').style.display = 'block';
    document.getElementById('dash-progress-fill').style.width = p.pct + '%';
    document.getElementById('dash-progress-pct').textContent = p.pct.toFixed(2) + '%';
    document.getElementById('dash-progress-detail').textContent =
      `${p.done.toLocaleString()} / ${p.total.toLocaleString()} Questions`;
    document.getElementById('dash-stat-solved').textContent = p.done.toLocaleString();
    document.getElementById('dash-stat-topics').textContent = `${p.subjSolved} / ${p.subjTotal}`;
    document.getElementById('dash-stat-topic-solved').textContent = `${p.topicsSolved} / ${p.topicsTotal}`;
    document.getElementById('dash-stat-cards').textContent =
      `${p.mainSolved} / ${p.mainTotal} Below Card List${p.mainTotal !== 1 ? 's' : ''} Fully Solved`;
  }

  /**
   * Render one card per main_subject (e.g. "Cerebellum PYQ").
   * Clicking opens modal with subject_name + topic dropdowns.
   */
  function renderMainSubjectCards() {
    const grid = document.getElementById('subjects-grid');
    grid.innerHTML = '';
    // Sort: PYQ/pyq cards first, then the rest
    const isPyq = name => /pyq/i.test(name);
    const sortedEntries = Object.entries(state.mainSubjects).sort(([a], [b]) => {
      const aPyq = isPyq(a), bPyq = isPyq(b);
      if (aPyq && !bPyq) return -1;
      if (!aPyq && bPyq) return 1;
      return 0;
    });
    sortedEntries.forEach(([mainName, mainData], idx) => {
      const icon = ICONS[idx % ICONS.length];

      // Aggregate totals across all subjects under this main_subject
      let totalQs = 0, doneQs = 0, totalSubTopics = 0;
      for (const [sk, subj] of Object.entries(mainData.subjects)) {
        totalSubTopics += (subj.topics || []).length;
        for (const t of subj.topics) {
          totalQs += t.count;
          doneQs += getProgress(sk, t.id);
        }
      }
      const pct = totalQs ? Math.round((doneQs / totalQs) * 100) : 0;
      const topicCount = Object.keys(mainData.subjects).length;

      const card = document.createElement('div');
      card.className = 'subject-card';
      card.innerHTML = `
        <div class="card-icon">${icon}</div>
        <div class="card-title">${esc(mainName)}</div>
        <div class="card-meta">${topicCount} Topic${topicCount !== 1 ? 's' : ''} · ${totalSubTopics} Sub Topic${totalSubTopics !== 1 ? 's' : ''}</div>
        <div class="card-progress-bar"><div class="card-progress-fill" style="width:${pct}%"></div></div>
        <div class="card-progress-label">${doneQs} / ${totalQs} Questions Solved (${pct}%)</div>`;
      card.addEventListener('click', () => openSubjectModal(mainName, mainData));
      grid.appendChild(card);
    });
  }

  /**
   * Open the modal for a given main_subject.
   * If it has only 1 subject_name, skip the subject dropdown and go straight to topics.
   */
  function openSubjectModal(mainName, mainData) {
    state.selectedMainSubj = mainName;
    state.selectedSubj = null;
    state.selectedTopic = null;
    state.selectedFilter = 'all';

    document.getElementById('modal-title').textContent = esc(mainName);

    const subjKeys = Object.keys(mainData.subjects);
    const stepSubj = document.getElementById('modal-step-subject');
    const selSubj = document.getElementById('sel-subject');

    if (subjKeys.length === 1) {
      // Only one subject — auto-select, hide the subject dropdown
      stepSubj.style.display = 'none';
      state.selectedSubj = subjKeys[0];
      populateTopicDropdown(subjKeys[0]);
      hideTopicStatus();
    } else {
      // Multiple subjects — show the subject dropdown
      stepSubj.style.display = '';
      selSubj.innerHTML = '<option value="">-- Select a topic --</option>';
      for (const sk of subjKeys) {
        const subj = mainData.subjects[sk];
        const o = document.createElement('option');
        o.value = sk;
        o.textContent = subj.displayName;
        selSubj.appendChild(o);
      }
      // Clear topics until subject chosen
      const selTopic = document.getElementById('sel-topic');
      selTopic.innerHTML = '<option value="">-- Select a topic first --</option>';
    }

    // Reset mode selection
    document.querySelectorAll('.mode-option').forEach(e => e.classList.remove('selected'));
    document.querySelector('.mode-option[data-mode="real"]').classList.add('selected');
    state.selectedMode = 'real';

    // Reset filter
    document.querySelectorAll('.filter-tag').forEach(b => {
      b.classList.toggle('active', b.dataset.filter === 'all');
      b.disabled = false;
      b.classList.remove('filter-tag-disabled');
    });
    hideTopicStatus();

    openModal('modal-subject');
  }

  function populateTopicDropdown(sk) {
    const sel = document.getElementById('sel-topic');
    sel.innerHTML = '<option value="">-- Select a sub-topic --</option>';
    hideTopicStatus();
    if (!sk) return;

    // Find subject in mainSubjects
    let topics = null;
    for (const mainData of Object.values(state.mainSubjects)) {
      if (mainData.subjects[sk]) {
        topics = mainData.subjects[sk].topics;
        break;
      }
    }
    if (!topics) return;
    topics.forEach(t => {
      const o = document.createElement('option');
      o.value = t.id;
      o.textContent = `${t.name} (${t.count} Qs)`;
      sel.appendChild(o);
    });
  }

  // ==================== TOPIC STATUS ====================

  function hideTopicStatus() {
    const wrap = document.getElementById('topic-status-wrap');
    if (wrap) wrap.style.display = 'none';
    // Reset filter to 'all' when hiding
    state.selectedFilter = 'all';
    document.querySelectorAll('.filter-tag').forEach(b => {
      b.classList.toggle('active', b.dataset.filter === 'all');
    });
    // Hide/clear the review button (it's a static element inside topic-status-wrap)
    const reviewWrap = document.getElementById('topic-review-btn-wrap');
    if (reviewWrap) { reviewWrap.innerHTML = ''; reviewWrap.style.display = 'none'; }
  }

  /**
   * Compute solved stats for display.
   * Each question has a "state": "correct" | "incorrect" | "skipped".
   * Counts = number of questions currently in each state.
   * correct + incorrect + skipped = total attempted questions.
   */
  function getTopicSolvedInfo(sk, tid) {
    const statsKey = `${sk}_${tid}`;
    const topicSt = state.topicStats[statsKey];
    if (!topicSt || !topicSt.questions || !Object.keys(topicSt.questions).length) {
      return { solved: false };
    }
    let correct = 0, incorrect = 0, skipped = 0;
    for (const qStat of Object.values(topicSt.questions)) {
      // Support both new { state } format and old { correct, incorrect, skipped } accumulator format
      const st = qStat.state;
      if (st === 'correct') correct++;
      else if (st === 'incorrect') incorrect++;
      else if (st === 'skipped') skipped++;
      else {
        // Legacy fallback: old format stored cumulative counts — derive state from which is highest
        const c = qStat.correct || 0, w = qStat.incorrect || 0, s = qStat.skipped || 0;
        if (c > 0) correct++;
        else if (w > 0) incorrect++;
        else if (s > 0) skipped++;
      }
    }
    if (correct + incorrect + skipped === 0) return { solved: false };
    return { solved: true, correct, incorrect, skipped, statsKey };
  }

  /**
   * Returns review data for a topic if it exists and is within 24 hours.
   * Returns null otherwise.
   */
  function getTopicReviewInfo(sk, tid) {
    const reviewKey = `${sk}_${tid}`;
    const review = state.testReviews[reviewKey];
    if (!review || !review.submittedAt) return null;
    const submittedAt = new Date(review.submittedAt);
    const now = new Date();
    const hoursElapsed = (now - submittedAt) / (1000 * 60 * 60);
    if (hoursElapsed >= 24) return null;
    return {
      ...review,
      hoursRemaining: Math.max(0, 24 - hoursElapsed),
      minutesRemaining: Math.max(0, Math.ceil((24 - hoursElapsed) * 60))
    };
  }

  /**
   * Render (or remove) the "Previous Test Review" button below topic-status-wrap.
   * Pass sk=null to just clean up without rendering.
   */
  function renderTopicReviewButton(sk, tid) {
    const btnWrap = document.getElementById('topic-review-btn-wrap');
    if (!btnWrap) return;

    // Clear any previous content
    btnWrap.innerHTML = '';
    btnWrap.style.display = 'none';

    if (!sk || !tid) return;

    const review = getTopicReviewInfo(sk, tid);
    if (!review) return;

    const h = Math.floor(review.hoursRemaining);
    const m = Math.round((review.hoursRemaining - h) * 60);
    const expiryText = h > 0 ? `Expiring Review in ${h}h ${m}m` : `Expiring Review in ${m}m`;

    btnWrap.style.display = 'block';
    btnWrap.innerHTML = `
      <button class="btn-prev-test-review" id="btn-prev-test-review">
        📋 Tap to Review Previous this Topic Test
      </button>
      <div class="topic-review-expiry">⏳ ${esc(expiryText)}</div>`;

    document.getElementById('btn-prev-test-review').addEventListener('click', () => {
      showPreviousTestReview(sk, tid, review);
    });
  }

  /**
   * Show the results view populated with a previous test review (read-only).
   * Adds a "← Back" button that returns to the modal/dashboard without clearing anything.
   */
  function showPreviousTestReview(sk, tid, review) {
    closeModal('modal-subject');
    showView('results');

    // Render the results exactly like doSubmitExam would
    renderResults({
      score: review.score,
      results: review.results,
      timeTaken: review.timeTaken
    });

    // Override the back button to go back to dashboard properly
    const backBtn = document.getElementById('btn-back-dash');
    if (backBtn) {
      // Clone to strip existing handler
      const freshBack = backBtn.cloneNode(true);
      freshBack.textContent = '← Back to Homepage';
      backBtn.parentNode.replaceChild(freshBack, backBtn);
      freshBack.addEventListener('click', () => {
        showView('dashboard');
        updateDashboardProgress();
        renderReviewCards();
        if (Object.keys(state.mainSubjects).length > 0) renderMainSubjectCards();
        else loadSubjects();
      });
    }

    // Show a banner indicating this is a past review
    const submittedDate = new Date(review.submittedAt);
    const timeStr = submittedDate.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' }) + ' ' +
      submittedDate.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });

    const scoreSection = document.querySelector('.results-sidebar-inner');
    if (scoreSection) {
      const existing = document.getElementById('review-mode-banner');
      if (existing) existing.remove();
      const banner = document.createElement('div');
      banner.id = 'review-mode-banner';
      banner.className = 'review-mode-banner';
      banner.innerHTML = `<span class="review-mode-icon">📋</span> <strong>Previous Test Review</strong> — Submitted on ${esc(timeStr)}`;
      scoreSection.insertBefore(banner, scoreSection.firstChild);
    }
  }

  function updateTopicStatus(sk, tid) {
    const wrap = document.getElementById('topic-status-wrap');
    const badge = document.getElementById('topic-status-badge');
    const filterWrap = document.getElementById('topic-filter-wrap');
    if (!wrap || !badge || !filterWrap) return;

    // Reset filter selection to 'all'
    state.selectedFilter = 'all';
    document.querySelectorAll('.filter-tag').forEach(b => {
      b.classList.toggle('active', b.dataset.filter === 'all');
    });

    const info = getTopicSolvedInfo(sk, tid);
    wrap.style.display = 'block';

    if (!info.solved) {
      badge.innerHTML = `<span class="topic-status-tag unsolved">Unsolved</span>`;
      filterWrap.style.display = 'none';
      renderTopicReviewButton(sk, tid);
      return;
    }

    badge.innerHTML = `
      <span class="topic-status-tag solved">Solved</span>
      <span class="topic-stat-tag correct-stat">${info.correct} Correct</span>
      <span class="topic-stat-tag incorrect-stat">${info.incorrect} Incorrect</span>
      <span class="topic-stat-tag skipped-stat">${info.skipped} Skipped</span>`;

    // Show filter tags — disable Incorrect/Skipped if no questions are in that state
    filterWrap.style.display = 'block';

    // Count how many questions would be in each filter
    const statsKey = `${sk}_${tid}`;
    const topicSt = state.topicStats[statsKey];
    const qs = topicSt?.questions || {};
    let hasIncorrect = false, hasSkipped = false;
    for (const q of Object.values(qs)) {
      const st = q.state;
      if (st === 'incorrect' || (!st && (q.incorrect || 0) > 0)) hasIncorrect = true;
      if (st === 'skipped'   || (!st && (q.skipped   || 0) > 0)) hasSkipped   = true;
    }

    document.querySelectorAll('.filter-tag').forEach(btn => {
      const f = btn.dataset.filter;
      if (f === 'incorrect') btn.disabled = !hasIncorrect;
      if (f === 'skipped') btn.disabled = !hasSkipped;
      if (f === 'all') btn.disabled = false;
      btn.classList.toggle('filter-tag-disabled', btn.disabled);
    });

    renderTopicReviewButton(sk, tid);
  }

  // ==================== FULLSCREEN ====================
  function enterFullscreen() {
    // iOS/iPadOS does not support the Fullscreen API — skip entirely to
    // avoid triggering a spurious focus event that pops up the keyboard.
    if (isIOS()) return;
    // Blur whatever element currently has focus (e.g. the topic <select>)
    // before requesting fullscreen. On iPad/Safari a focused element can
    // cause the virtual keyboard to appear mid-transition ("trying to type").
    try { if (document.activeElement) document.activeElement.blur(); } catch {}
    const el = document.documentElement;
    try {
      if (el.requestFullscreen) el.requestFullscreen();
      else if (el.webkitRequestFullscreen) el.webkitRequestFullscreen();
      else if (el.mozRequestFullScreen) el.mozRequestFullScreen();
      else if (el.msRequestFullscreen) el.msRequestFullscreen();
    } catch {}
  }

  function exitFullscreen() {
    if (isIOS()) return;
    try {
      if (document.exitFullscreen) document.exitFullscreen();
      else if (document.webkitExitFullscreen) document.webkitExitFullscreen();
      else if (document.mozCancelFullScreen) document.mozCancelFullScreen();
      else if (document.msExitFullscreen) document.msExitFullscreen();
    } catch {}
  }

  // ==================== EXAM START ====================
  async function startExam(resumeFrom) {
    // Dismiss virtual keyboard on iPad/mobile before transitioning to exam view
    try { if (document.activeElement) document.activeElement.blur(); } catch {}
    showView('exam');
    enterFullscreen();
    stopAllTimers();
    state.session = resetSession();
    state.session.mode = state.selectedMode;
    state.session.subjKey = state.selectedSubj;
    state.session.topicId = state.selectedTopic;

    const examView = document.getElementById('view-exam');
    examView.classList.toggle('real-mode', state.selectedMode === 'real');

    const sidebar = document.getElementById('exam-sidebar');
    const main = document.getElementById('exam-main');
    sidebar.style.display = state.selectedMode === 'real' ? '' : 'none';
    main.classList.toggle('full-width', state.selectedMode === 'test');

    document.getElementById('btn-mark').style.display = state.selectedMode === 'real' ? '' : 'none';
    document.getElementById('btn-clear').style.display = state.selectedMode === 'real' ? '' : 'none';

    showSkeleton();

    try {
      const { sessionId } = await API.createSession(state.selectedSubj, state.selectedTopic, state.selectedMode, state.selectedFilter);
      state.session.id = sessionId;

      if (state.selectedMode === 'real') {
        // ── REAL MODE: batch preload entire first section ──────────────
        const batch = await preloadSection(0);
        if (!batch || !batch.questions || !batch.questions.length) throw new Error('Failed to load section questions');

        const total = batch.questions[0].total;
        const totalSections = batch.section?.totalSections || Math.ceil(total / MAX_SEC_SIZE);
        const sections = [];
        let remaining = total;
        for (let i = 0; remaining > 0; i++) {
          const size = Math.min(MAX_SEC_SIZE, remaining);
          sections.push({ name: 'Section ' + (SEC_NAMES[i] || (i + 1)), total: size, start: i * MAX_SEC_SIZE, expired: false });
          remaining -= size;
        }
        state.session.sections = sections;
        state.session.activeSec = 0;
        state.session.curSec = 0;
        state.session.curQ = 0;
        renderSecTabs();
        renderSidebar();
        renderQuestion(batch.questions[0], 0);

        const timerData = batch.timer || {};
        state.session.secTimeLeft = typeof timerData.timeLeft === 'number'
          ? timerData.timeLeft
          : sections[0].total * SECS_PER_Q;
        startSecTimer();

        // Persist live exam state so dashboard card appears if user closes app
        const totalSecsAll = sections.reduce((a, s) => a + s.total, 0) * SECS_PER_Q;
        state.liveExamData = {
          sessionId:  sessionId,
          subjKey:    state.selectedSubj,
          topicId:    state.selectedTopic,
          subjName:   (() => {
            for (const [key, subj] of Object.entries(state.subjects || {})) {
              if (key === state.selectedSubj) return subj.displayName || state.selectedSubj;
            }
            return state.selectedSubj;
          })(),
          topicName:  (() => {
            for (const [key, subj] of Object.entries(state.subjects || {})) {
              if (key === state.selectedSubj) {
                const t = subj.topics.find(t => String(t.id) === String(state.selectedTopic));
                return t ? t.name : '';
              }
            }
            return '';
          })(),
          startedAt:  new Date().toISOString(),
          totalSecs:  totalSecsAll,
          sectionHint: `Currently at Section A (Section 1 of ${sections.length})`,
          savedAt:    new Date().toISOString()
        };
        saveLiveExamState();

        // Do NOT preload other sections — section locking means they'll be fetched when unlocked

      } else {
        // ── TEST MODE: single question fetch ─────────────────
        const first = await API.getQuestion(sessionId, 0);
        const total = first.question.total;
        state.session.sections = [{ name: 'Section A', total, start: 0, expired: false }];

        if (resumeFrom && resumeFrom.answers) {
          // Mark all restored answers as NOT submitted so they get re-sent
          // to the new server session. Without this the server has no record
          // of Q1…N-1 and counts them all as skipped on finish.
          const restoredAnswers = {};
          for (const [qIdxStr, ans] of Object.entries(resumeFrom.answers)) {
            restoredAnswers[qIdxStr] = { ...ans, submitted: false };
          }
          state.session.answers = { 0: restoredAnswers };
          const resumeLocalIdx = Math.max(0, resumeFrom.globalIdx);
          state.session.curSec = 0; state.session.curQ = resumeLocalIdx;
          renderSecTabs();
          // Re-submit all previously answered questions to the new server session
          // before rendering, so the server state is consistent.
          await resubmitResumedAnswers();
          renderQuestionAt(resumeLocalIdx);
        } else {
          state.session.curSec = 0; state.session.curQ = 0;
          renderSecTabs();
          renderQuestion(first.question, 0);
        }

        state.session.qTimeLeft = SECS_PER_Q;
        startQTimer();
        prefetch(state.session.curQ + 1);
      }

    } catch (err) {
      document.getElementById('exam-main').innerHTML =
        `<p style="color:#ef4444;padding:24px;">Error: ${esc(err.message)}</p>`;
    }
  }

  function showSkeleton() {
    document.getElementById('exam-main').innerHTML = `
      <div class="skeleton" style="height:36px;margin-bottom:10px;"></div>
      <div class="skeleton" style="height:100px;margin-bottom:16px;"></div>
      <div class="skeleton" style="height:52px;margin-bottom:10px;"></div>
      <div class="skeleton" style="height:52px;margin-bottom:10px;"></div>
      <div class="skeleton" style="height:52px;"></div>`;
  }

  // ==================== SECTION TABS ====================
  function renderSecTabs() {
    const container = document.getElementById('exam-sections');
    const ses = state.session;
    if (ses.mode === 'test') { container.innerHTML = ''; return; }

    container.innerHTML = ses.sections.map((s, i) => {
      const isActive = (i === ses.activeSec);
      const isExpired = s.expired;
      const isCurrent = (i === ses.curSec);

      // Locked: not active and not expired (future section)
      // Expired: can no longer access (past section — locked too)
      // Active: current unlocked section — only this one is clickable
      let cls = 'section-tab';
      if (isCurrent) cls += ' active';
      if (isExpired) cls += ' expired';
      if (!isActive) cls += ' locked';

      const lockIcon = isExpired ? ' 🔒' : (!isActive ? ' 🔒' : '');
      const disabled = !isActive ? 'disabled' : '';

      return `<button class="${cls}" data-si="${i}" ${disabled} title="${isExpired ? 'Section expired' : !isActive ? 'Section locked — wait for current timer to expire' : ''}">${esc(s.name)}${lockIcon}</button>`;
    }).join('');

    // Only bind click on the active (unlocked) section tab
    container.querySelectorAll('.section-tab:not([disabled])').forEach(btn => {
      btn.addEventListener('click', () => {
        const si = parseInt(btn.dataset.si);
        if (si === ses.activeSec && si !== ses.curSec) {
          ses.curSec = si; ses.curQ = 0;
          renderSecTabs(); renderSidebar();
          renderQuestionFromCache(si, 0);
        }
      });
    });
  }

  // ==================== TIMERS (SERVER-AUTHORITATIVE) ====================
  function startSecTimer() {
    const ses = state.session;
    updateTimerDisplay(ses.secTimeLeft, 'Section');
    ses.secTimer = setInterval(() => {
      ses.secTimeLeft--;
      updateTimerDisplay(ses.secTimeLeft, 'Section');
      if (ses.secTimeLeft <= 0) {
        stopSecTimer();
        onSectionExpire();
      }
    }, 1000);

    if (ses.serverTimerSync) clearInterval(ses.serverTimerSync);
    ses.serverTimerSync = setInterval(async () => {
      try {
        const t = await API.getSectionTimer(ses.id, ses.curSec);
        if (t && typeof t.timeLeft === 'number') {
          const drift = Math.abs(ses.secTimeLeft - t.timeLeft);
          if (drift > 3) {
            ses.secTimeLeft = t.timeLeft;
            updateTimerDisplay(ses.secTimeLeft, 'Section');
          }
          // Sync activeSec from server
          if (typeof t.activeSec === 'number' && t.activeSec !== ses.activeSec) {
            ses.activeSec = t.activeSec;
            renderSecTabs();
          }
          if (t.expired && ses.secTimeLeft > 0) {
            ses.secTimeLeft = 0;
            stopSecTimer();
            onSectionExpire();
          }
        }
      } catch {}
    }, 60000); // sync every 60s (was 30s) — local countdown handles display; server sync only corrects drift
  }

  function stopSecTimer() {
    clearInterval(state.session.secTimer);
    state.session.secTimer = null;
    clearInterval(state.session.serverTimerSync);
    state.session.serverTimerSync = null;
  }

  async function onSectionExpire() {
    const ses = state.session;
    const expiredSecIdx = ses.curSec;
    ses.sections[expiredSecIdx].expired = true;
    ses.timerExpired = true;

    // Tell server to advance activeSec FIRST — so next section batch fetch is allowed
    try {
      await API.expireSection(ses.id, expiredSecIdx);
    } catch {}

    // Advance client activeSec
    if (ses.activeSec === expiredSecIdx && expiredSecIdx + 1 < ses.sections.length) {
      ses.activeSec = expiredSecIdx + 1;
    }

    await flushPending();
    renderSecTabs();

    if (expiredSecIdx >= ses.sections.length - 1) {
      // Last section — submit exam
      doSubmitExam();
    } else {
      ses.curSec = expiredSecIdx + 1;
      ses.activeSec = ses.curSec;
      ses.curQ = 0;
      ses.timerExpired = false;

      // Update live exam sectionHint so dashboard card reflects current section
      if (state.liveExamData) {
        state.liveExamData.sectionHint = `Currently at Section ${String.fromCharCode(65 + ses.curSec)} (Section ${ses.curSec + 1} of ${ses.sections.length})`;
        saveLiveExamState();
      }

      // Re-enable buttons for next section
      const btnSaveNext = document.getElementById('btn-save-next');
      const btnMark = document.getElementById('btn-mark');
      if (btnSaveNext) { btnSaveNext.disabled = false; btnSaveNext.classList.remove('btn-disabled-expired'); btnSaveNext.title = ''; }
      if (btnMark) { btnMark.disabled = false; btnMark.classList.remove('btn-disabled-expired'); btnMark.title = ''; }

      // Now batch-fetch all questions for the newly unlocked section
      const nextBatch = await preloadSection(ses.curSec);
      if (!nextBatch || !nextBatch.questions) {
        document.getElementById('exam-main').innerHTML =
          `<p style="color:#ef4444;padding:24px;">Failed to load Section ${ses.curSec + 1}. Please contact support.</p>`;
        return;
      }
      ses.secTimeLeft = nextBatch.timer ? nextBatch.timer.timeLeft : ses.sections[ses.curSec].total * SECS_PER_Q;
      renderSecTabs();
      renderSidebar();
      renderQuestionFromCache(ses.curSec, 0);
      startSecTimer();
    }
  }

  function startQTimer() {
    stopQTimer();
    _qTimerPaused = false;
    const ses = state.session;
    ses.qTimeLeft = SECS_PER_Q;
    updateTimerDisplay(ses.qTimeLeft, 'Q');
    updateQBar(ses.qTimeLeft);
    ses.qTimer = setInterval(() => {
      if (_qTimerPaused) return;
      ses.qTimeLeft--;
      updateTimerDisplay(ses.qTimeLeft, 'Q');
      updateQBar(ses.qTimeLeft);
      if (ses.qTimeLeft <= 0) { stopQTimer(); moveToNext(); }
    }, 1000);
  }
  function stopQTimer() { clearInterval(state.session.qTimer); state.session.qTimer = null; }

  function stopAllTimers() {
    stopSecTimer();
    stopQTimer();
  }

  function updateTimerDisplay(secs, type) {
    const el = document.getElementById('exam-timer');
    if (!el) return;
    const m = Math.floor(Math.max(0, secs) / 60);
    const s = Math.max(0, secs) % 60;
    el.textContent = `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
    el.className = 'exam-timer' + (secs < 60 ? ' danger' : secs < 180 ? ' warn' : '');
  }

  function updateQBar(secs) {
    const bar = document.getElementById('q-timer-bar');
    if (!bar) return;
    const pct = Math.max(0, (secs / SECS_PER_Q) * 100);
    bar.style.width = pct + '%';
    bar.className = 'q-timer-bar' + (secs < 15 ? ' danger' : secs < 30 ? ' warn' : '');
  }

  // ==================== SECTION PRELOAD ====================
  async function preloadSection(secIndex) {
    const ses = state.session;
    if (!ses.id) return null;
    if (ses.sectionCache[secIndex]) return { questions: ses.sectionCache[secIndex], timer: null, section: {} };
    if (ses.sectionLoading[secIndex]) return ses.sectionLoading[secIndex];

    const p = API.getSectionQuestions(ses.id, secIndex).then(batch => {
      ses.sectionCache[secIndex] = batch.questions;
      delete ses.sectionLoading[secIndex];
      return batch;
    }).catch(() => {
      delete ses.sectionLoading[secIndex];
      return null;
    });
    ses.sectionLoading[secIndex] = p;
    return p;
  }

  function getQuestionFromCache(secIndex, localIdx) {
    const cache = state.session.sectionCache[secIndex];
    if (!cache) return null;
    return cache[localIdx] || null;
  }

  function renderQuestionFromCache(secIndex, localIdx) {
    const q = getQuestionFromCache(secIndex, localIdx);
    if (!q) {
      renderQuestionAt(localIdx);
      return;
    }
    renderQuestion(q, localIdx);
    if (state.session.mode === 'real') renderSidebar();
  }

  // Legacy single-question prefetch (test mode only)
  async function prefetch(idx) {
    const ses = state.session;
    if (ses.mode === 'real') return;
    const sec = ses.sections[ses.curSec];
    if (!ses.id || !sec || idx >= sec.total) return;
    const globalIdx = (sec.start || 0) + idx;
    try { ses.prefetched = { idx, data: await API.getQuestion(ses.id, globalIdx) }; } catch {}
  }

  // ==================== QUESTION RENDER ====================
  async function renderQuestionAt(idx) {
    const ses = state.session;

    if (ses.mode === 'real') {
      const q = getQuestionFromCache(ses.curSec, idx);
      if (q) {
        renderQuestion(q, idx);
        renderSidebar();
        return;
      }
    }

    showSkeleton();
    const sec = ses.sections[ses.curSec];
    const globalIdx = (sec ? (sec.start || 0) : 0) + idx;
    let qData;
    if (ses.prefetched && ses.prefetched.idx === idx) {
      qData = ses.prefetched.data; ses.prefetched = null;
    } else {
      try { qData = await API.getQuestion(ses.id, globalIdx); }
      catch (err) {
        document.getElementById('exam-main').innerHTML =
          `<p style="color:#ef4444;padding:24px;">🚫WARNING ! Why So Hurry ? ${esc(err.message)} . Refresh Website or Close app and reopen to Resume🚫</p>`;
        return;
      }
    }
    if (!ses.sectionCache[ses.curSec]) ses.sectionCache[ses.curSec] = {};
    ses.sectionCache[ses.curSec][idx] = qData.question;
    renderQuestion(qData.question, idx);
    if (ses.mode === 'real') renderSidebar();
    if (ses.mode === 'test') {
      const submittedAns = (ses.answers[ses.curSec] || {})[idx];
      if (submittedAns?.submitted) {
        stopQTimer();
        _qTimerPaused = true;
      } else {
        _qTimerPaused = false;
        startQTimer();
      }
    }
    prefetch(idx + 1);
  }

  /**
   * Build safe HTML for question images ONLY (shown with the question).
   * Audio and video are intentionally excluded here — they appear in the explanation.
   * These come from trusted backend URLs — we do NOT esc() them.
   */
  function buildQuestionImagesHtml(images) {
    let html = '';
    if (Array.isArray(images) && images.length) {
      html += '<div class="q-images">';
      for (const src of images) {
        if (src && typeof src === 'string' && src.trim()) {
          html += `<img class="q-img" src="${src.trim()}" alt="Question image" loading="lazy" onerror="this.style.display='none'" />`;
        }
      }
      html += '</div>';
    }
    return html;
  }

  /**
   * Build safe HTML for explanation-only media: audio and video.
   * Called inside the explanation box so media is shown only after answering.
   */
  function buildExplMediaHtml(audio, video) {
    let html = '';
    if (audio && typeof audio === 'string' && audio.trim()) {
      html += `<div class="q-audio"><audio controls src="${audio.trim()}">Your browser does not support audio.</audio></div>`;
    }
    if (video && typeof video === 'string' && video.trim()) {
      html += `<div class="q-video"><video controls src="${video.trim()}" style="max-width:100%;border-radius:8px;">Your browser does not support video.</video></div>`;
    }
    return html;
  }

  // Legacy alias kept so any remaining callers still work (images only, no audio/video).
  function buildMediaHtml(images, audio, video) {
    return buildQuestionImagesHtml(images);
  }

  function buildExplImagesHtml(explImages) {
    if (!Array.isArray(explImages) || !explImages.length) return '';
    let html = '<div class="q-images expl-images">';
    for (const src of explImages) {
      if (src && typeof src === 'string' && src.trim()) {
        html += `<img class="q-img" src="${src.trim()}" alt="Explanation image" loading="eager" decoding="async" />`;
      }
    }
    html += '</div>';
    return html;
  }


  // Guarantee every explanation image is fully loaded.
  // Images come embedded in server HTML inside .exp-content — we post-process them here.
  function armExplImageFallbacks(container) {
    if (!container) return;
    const imgs = container.querySelectorAll('.exp-content img, .expl-images img');
    if (!imgs.length) return;

    imgs.forEach(img => {
      // Apply consistent styles so image never stays invisible
      img.style.display   = 'block';
      img.style.maxWidth  = '100%';
      img.style.height    = 'auto';
      img.style.opacity   = '0';
      img.style.transition = 'opacity 0.3s ease';

      const reveal = () => {
        img.style.opacity = '1';
        if (img._retryTimer) clearInterval(img._retryTimer);
        if (img._giveUpTimer) clearTimeout(img._giveUpTimer);
      };

      // Already cached and loaded
      if (img.complete && img.naturalHeight !== 0) {
        img.style.opacity = '1';
        return;
      }

      img.addEventListener('load',  reveal, { once: true });
      img.addEventListener('error', () => {
        // Retry up to 5 times every 3s before giving up
        let attempts = 0;
        img._retryTimer = setInterval(() => {
          attempts++;
          const origSrc = img.src;
          img.src = '';
          img.src = origSrc + (origSrc.includes('?') ? '&' : '?') + '_r=' + attempts;
          if (img.complete && img.naturalHeight !== 0) { reveal(); return; }
          if (attempts >= 5) {
            clearInterval(img._retryTimer);
            img.style.opacity = '1'; // show broken-image icon rather than blank
          }
        }, 3000);
      }, { once: true });

      // Absolute guarantee: force visible after 20s no matter what
      img._giveUpTimer = setTimeout(() => { img.style.opacity = '1'; }, 20000);
    });
  }
  function updateNavButtonStates(idx) {
    const ses = state.session;
    const btnPrev = document.getElementById('btn-prev-q');
    if (!btnPrev) return;
    const isFirst = (idx === 0);
    const ans = (ses.answers[ses.curSec] || {})[idx];
    const hasSelection = !!(ans && ans.selected);
    const lockedByNoSelection = (ses.mode === 'test') && !hasSelection;
    const disabled = isFirst || lockedByNoSelection;
    btnPrev.disabled = disabled;
    btnPrev.classList.toggle('btn-nav-disabled', disabled);
    if (isFirst) btnPrev.title = 'First question of section';
    else if (lockedByNoSelection) btnPrev.title = 'Select an option before going back';
    else btnPrev.title = 'Go to previous question';
  }

  function updateMarkButtonState(hasSelection, isMarked) {
    const ses = state.session;
    if (ses.mode !== 'real') return;
    const sec = ses.sections[ses.curSec];
    const isLastQ = sec && (ses.curQ === sec.total - 1);
    const btnMark = document.getElementById('btn-mark');
    if (!btnMark) return;
    // Mark for Review: only enabled if an option is selected AND not last question
    if (isLastQ) {
      btnMark.disabled = true;
      btnMark.classList.add('btn-disabled-expired');
      btnMark.textContent = 'Mark for Review';
      btnMark.title = 'Last question — use Submit to end this section';
    } else if (hasSelection) {
      btnMark.disabled = false;
      btnMark.classList.remove('btn-disabled-expired');
      btnMark.classList.remove('btn-mark-disabled');
      // Show visual feedback if already marked
      btnMark.textContent = isMarked ? 'Marked ✓' : 'Mark for Review';
      btnMark.title = isMarked ? 'Already marked — Save & Next to save as Answered+Marked' : '';
    } else {
      btnMark.disabled = true;
      btnMark.classList.add('btn-mark-disabled');
      btnMark.textContent = 'Mark for Review';
      btnMark.title = 'Select an option first';
    }
  }

  function updateLastQButtons() {
    // In real mode: disable Save & Next on last question; Mark handled by updateMarkButtonState
    const ses = state.session;
    if (ses.mode !== 'real') return;
    const sec = ses.sections[ses.curSec];
    if (!sec) return;
    const isLastQ = (ses.curQ === sec.total - 1);
    const btnSaveNext = document.getElementById('btn-save-next');
    if (btnSaveNext) {
      btnSaveNext.disabled = isLastQ;
      btnSaveNext.classList.toggle('btn-disabled-expired', isLastQ);
      btnSaveNext.title = isLastQ ? 'Last question — use Submit to end this section' : '';
    }
  }

  function renderQuestion(q, idx) {
    const ses = state.session;
    // Mark this question as visited
    if (!ses.visited[ses.curSec]) ses.visited[ses.curSec] = {};
    ses.visited[ses.curSec][idx] = true;

    const sec = ses.sections[ses.curSec];
    const ans = (ses.answers[ses.curSec] || {})[idx];
    const showAns = ses.mode === 'test' && ans?.submitted;
    const globalNum = (sec ? (sec.start || 0) : 0) + idx + 1;

    const optsHtml = q.options.map(opt => {
      let cls = 'q-option';
      const isSel = ans?.selected === opt.label;
      const isCorr = opt.label === (q.correct || '').charAt(0);
      if (showAns) {
        cls += ' disabled';
        if (isCorr) cls += ' correct';
        else if (isSel) cls += ' wrong';
      } else if (isSel) cls += ' selected';
      return `<div class="${cls}" data-opt="${esc(opt.label)}">
        <span class="opt-label">${esc(opt.label)}</span>
        <span>${esc(opt.text)}</span>
      </div>`;
    }).join('');

    const timerBar = ses.mode === 'test'
      ? `<div class="q-timer-bar-wrap"><div class="q-timer-bar" id="q-timer-bar" style="width:100%"></div></div>` : '';

    // Explanation: use innerHTML (server-provided HTML) + audio/video only.
    // explImages are already embedded inside q.explanation HTML — do NOT append again.
    // Strip any <ad>...</ad> tags that may appear in source data.
    const cleanExpl = q.explanation
      ? q.explanation.replace(/<ad\b[^>]*>[\s\S]*?<\/ad>/gi, '').replace(/<ad\b[^>]*\/>/gi, '')
      : '';
    const explHtml = (showAns && cleanExpl)
      ? `<div class="explanation-box">
           <div class="exp-header">✅ Explanation</div>
           ${buildExplMediaHtml(q.audio, q.video)}
           <div class="exp-content">${cleanExpl}</div>
         </div>` : '';

    const secLabel = ses.mode === 'real'
      ? `<div class="q-section-label">Current Section</div><div class="q-section-name">${esc(sec ? sec.name : 'Section A')}</div>` : '';

    const secHint = ses.mode === 'real'
      ? ` <span class="q-sec-hint">${idx + 1}/${sec ? sec.total : q.total}</span>` : '';

    // Question: show only the question_image (no audio/video — those appear in explanation)
    const qImagesHtml = buildQuestionImagesHtml(q.images);

    document.getElementById('exam-main').innerHTML = `
      ${secLabel}
      <div class="q-type-badge">MCQ</div>
<div class="q-number">Question : <strong>${secHint}</strong></div>
      ${timerBar}
      <div class="q-text">${esc(q.text)}</div>
      ${qImagesHtml}
      <div class="q-options" id="q-options">${optsHtml}</div>
      ${explHtml}`;

    wrapExpTables(document.getElementById('exam-main'));
    if (showAns) armExplImageFallbacks(document.getElementById('exam-main'));

    if (!showAns) {
      document.querySelectorAll('.q-option').forEach(el => {
        el.addEventListener('click', () => onOptionClick(el.dataset.opt, idx));
      });
    }

    if (ses.mode === 'test') {
      setTimeout(() => updateQBar(ses.qTimeLeft), 0);
    }

    // Disable Save & Next when on last question (real mode Q40)
    updateLastQButtons();
    // Mark for Review: only enabled if an option is already selected
    const existingAns = (ses.answers[ses.curSec] || {})[idx];
    const alreadyMarked = !!(ses.marked[ses.curSec] && ses.marked[ses.curSec][idx]);
    updateMarkButtonState(!!(existingAns && existingAns.selected), alreadyMarked);
    // Prev/Next button states
    updateNavButtonStates(idx);
  }

  function onOptionClick(label, idx) {
    const ses = state.session;
    if (!ses.answers[ses.curSec]) ses.answers[ses.curSec] = {};
    if (!ses.answers[ses.curSec][idx]) ses.answers[ses.curSec][idx] = { selected: null, submitted: false };
    ses.answers[ses.curSec][idx].selected = label;
    ses.answers[ses.curSec][idx]._cachedText = document.querySelector('.q-text')?.textContent || '';
    ses.answers[ses.curSec][idx]._cachedOptions = Array.from(document.querySelectorAll('.q-option')).map(el => ({
      label: el.dataset.opt, text: el.querySelector('span:last-child')?.textContent || ''
    }));
    ses.answers[ses.curSec][idx]._cachedImages = state.session.sectionCache[ses.curSec]?.[idx]?.images || [];
    ses.answers[ses.curSec][idx]._cachedAudio = state.session.sectionCache[ses.curSec]?.[idx]?.audio || '';
    ses.answers[ses.curSec][idx]._cachedVideo = state.session.sectionCache[ses.curSec]?.[idx]?.video || '';

    document.querySelectorAll('.q-option').forEach(el =>
      el.classList.toggle('selected', el.dataset.opt === label));

    // Enable Mark for Review now that an option is selected
    // Pass current marked state so button label stays "Marked ✓" if already marked
    const _isMarkedNow = !!(ses.marked[ses.curSec] && ses.marked[ses.curSec][idx]);
    updateMarkButtonState(true, _isMarkedNow);

    if (ses.mode === 'real') {
      renderSidebar();
    } else {
      doSaveNext();
    }
  }

  async function flushPending() {
    const ses = state.session;
    const idx = ses.curQ;
    const sec = ses.sections[ses.curSec];
    const globalIdx = (sec ? (sec.start || 0) : 0) + idx;
    if (!ses.answers[ses.curSec]) ses.answers[ses.curSec] = {};
    const ans = ses.answers[ses.curSec][idx];
    if (ans?.selected && !ans.submitted) {
      try {
        const res = await API.submitAnswer(ses.id, globalIdx, ans.selected);
        ans.submitted = true; ans.isCorrect = res.isCorrect; ans.correctLabel = res.correctLabel;
        setProgress(state.selectedSubj, state.selectedTopic, globalIdx + 1);
      } catch {}
    }
  }

  /**
   * Flush ALL unsubmitted answers across every section before finishSession.
   * This ensures marked-only and ans-marked questions (where the user selected
   * an option but only clicked Mark for Review, never Save & Next) are submitted
   * to the server and scored correctly — not treated as skipped.
   */
  async function flushAllPending() {
    const ses = state.session;
    for (let si = 0; si < ses.sections.length; si++) {
      const sec = ses.sections[si];
      const secAnswers = ses.answers[si] || {};
      const secStart = sec ? (sec.start || 0) : 0;
      const entries = Object.entries(secAnswers)
        .map(([k, v]) => [parseInt(k, 10), v])
        .filter(([, ans]) => ans && ans.selected && !ans.submitted)
        .sort((a, b) => a[0] - b[0]);
      for (const [localIdx, ans] of entries) {
        const globalIdx = secStart + localIdx;
        try {
          const res = await API.submitAnswer(ses.id, globalIdx, ans.selected);
          ans.submitted = true;
          ans.isCorrect = res.isCorrect;
          ans.correctLabel = res.correctLabel;
        } catch {}
      }
    }
  }

  function doPrevQuestion() {
    const ses = state.session;
    if (ses.curQ <= 0) return; // already at first question — button should be disabled
    ses.curQ--;
    if (ses.mode === 'real') {
      renderQuestionFromCache(ses.curSec, ses.curQ);
      renderSidebar();
    } else {
      renderQuestionAt(ses.curQ);
    }
  }

  async function doSaveNext() {
    const ses = state.session;
    const idx = ses.curQ;
    const sec = ses.sections[ses.curSec];
    const globalIdx = (sec ? (sec.start || 0) : 0) + idx;
    if (!ses.answers[ses.curSec]) ses.answers[ses.curSec] = {};
    const ans = ses.answers[ses.curSec][idx];

    if (ans?.selected && !ans.submitted) {
      try {
        const res = await API.submitAnswer(ses.id, globalIdx, ans.selected);
        ans.submitted = true; ans.saved = true; ans.isCorrect = res.isCorrect; ans.correctLabel = res.correctLabel;
        setProgress(state.selectedSubj, state.selectedTopic, globalIdx + 1);

        if (ses.mode === 'test') {
          stopQTimer();
          _qTimerPaused = false;
          const opts = res.options || ans._cachedOptions || [];
          // Get current question's media from API response or cache
          const curQ = getQuestionFromCache(ses.curSec, idx);
          renderTestReveal(idx, ans._cachedText || '', opts, res.correctLabel, res.explanation, res.explImages || [], curQ?.images || ans._cachedImages || [], curQ?.audio || ans._cachedAudio || '', curQ?.video || ans._cachedVideo || '');
          _qTimerPaused = true;
          updateTimerDisplay(ses.qTimeLeft, 'Q');
          await saveResumeCheckpoint();
          const btn = document.getElementById('btn-save-next');
          // Replace the button node with a clone to strip the persistent
          // doSaveNext addEventListener, then attach a single-fire "Next →"
          // handler. After moveToNext we re-bind doSaveNext to the new node.
          const fresh = btn.cloneNode(true);
          fresh.textContent = 'Next →';
          btn.parentNode.replaceChild(fresh, btn);
          fresh.addEventListener('click', () => {
            // Restore button label immediately
            fresh.textContent = 'Save & Next';
            _qTimerPaused = false;
            // Re-attach the persistent save-next handler before navigating
            // (moveToNext re-renders the question area but not the footer)
            fresh.addEventListener('click', doSaveNext);
            moveToNext();
          }, { once: true });
          return;
        }
        // Real mode: refresh sidebar to show green for this question
        renderSidebar();
      } catch {}
    } else if (ans?.selected && ans.submitted) {
      // Answer was already submitted before (e.g. re-visiting and pressing Save & Next again)
      ans.saved = true;
    }
    // Re-render sidebar so question shows green (answered) when returning to it
    if (ses.mode === 'real') renderSidebar();
    moveToNext();
  }

  function renderTestReveal(idx, qText, opts, correctLabel, explanation, explImages, qImages, qAudio, qVideo) {
    const ses = state.session;
    const sec = ses.sections[ses.curSec];
    const ans = (ses.answers[ses.curSec] || {})[idx];
    const globalNum = (sec ? (sec.start || 0) : 0) + idx + 1;
    const total = sec ? (sec.start || 0) + sec.total : '?';

    const optsHtml = opts.map(o => {
      const isCorr = o.is_correct || o.label === correctLabel;
      const isSel = o.label === ans.selected;
      let cls = 'q-option disabled' + (isCorr ? ' correct' : (isSel ? ' wrong' : ''));
      return `<div class="${cls}">
        <span class="opt-label">${esc(o.label)}</span>
        <span>${esc(o.text)}</span>
        ${isCorr ? '<span class="opt-tag correct-tag">✓ Correct</span>' : ''}
        ${isSel && !isCorr ? '<span class="opt-tag wrong-tag">✗ Your answer</span>' : ''}
      </div>`;
    }).join('');

    const score = ans.isCorrect
      ? '<span class="score-badge correct-badge">✓ Correct +4</span>'
      : '<span class="score-badge wrong-badge">✗ Wrong −1</span>';

    // Question: show only the question_image (no audio/video — those appear in explanation)
    const qImagesHtml = buildQuestionImagesHtml(qImages);

    // Explanation: images already embedded in explanation HTML — do NOT append explImages again.
    // Strip any <ad>...</ad> tags from source data.
    const cleanExplanation = explanation
      ? explanation.replace(/<ad\b[^>]*>[\s\S]*?<\/ad>/gi, '').replace(/<ad\b[^>]*\/>/gi, '')
      : '';
    const explHtml = cleanExplanation
      ? `<div class="explanation-box">
           <div class="exp-header">📖 Explanation</div>
           ${buildExplMediaHtml(qAudio, qVideo)}
           <div class="exp-content">${cleanExplanation}</div>
         </div>` : '';

    document.getElementById('exam-main').innerHTML = `
      <div class="q-type-badge">MCQ</div>
      <div class="q-number">Question <strong>${globalNum}</strong> / ${total} &nbsp; ${score}</div>
      <div class="q-text">${esc(qText)}</div>
      ${qImagesHtml}
      <div class="q-options">${optsHtml}</div>
      ${explHtml}`;

    wrapExpTables(document.getElementById('exam-main'));
    armExplImageFallbacks(document.getElementById('exam-main'));
    // Now that answer is submitted, re-evaluate prev button state
    updateNavButtonStates(idx);
  }

  function moveToNext() {
    const ses = state.session;
    const sec = ses.sections[ses.curSec];
    if (ses.curQ < sec.total - 1) {
      ses.curQ++;
      if (ses.mode === 'real') {
        renderQuestionFromCache(ses.curSec, ses.curQ);
        renderSidebar();
      } else {
        renderQuestionAt(ses.curQ);
      }
    } else {
      if (ses.mode === 'test') {
        clearResume();
        showDialog({
          title: 'Last Question Reached',
          message: 'You have reached the last question. Would you like to submit the exam?',
          confirmText: 'Submit Exam',
          cancelText: 'Stay Here',
          onConfirm: doSubmitExam
        });
      } else {
        onSectionExpire();
      }
    }
  }

  function doMarkReview() {
    const ses = state.session;
    // Always set marked = true (Mark for Review is a one-way flag via this button).
    // The only way a marked question becomes ans-marked is via Save & Next (doSaveNext).
    if (!ses.marked[ses.curSec]) ses.marked[ses.curSec] = {};
    ses.marked[ses.curSec][ses.curQ] = true;
    // Save the currently selected answer locally so it is preserved when user
    // returns to this question, but do NOT submit to the API yet.
    // (doSaveNext / flushPending will submit it when the section ends or user saves.)
    if (ses.mode === 'real') renderSidebar();
    moveToNext();
  }

  function doClearResponse() {
    const ses = state.session;
    if (ses.answers[ses.curSec] && ses.answers[ses.curSec][ses.curQ]) {
      ses.answers[ses.curSec][ses.curQ].selected = null;
    }
    document.querySelectorAll('.q-option').forEach(el => el.classList.remove('selected'));
    updateMarkButtonState(false);
    if (ses.mode === 'real') renderSidebar();
  }

  async function doSubmitExam() {
    stopAllTimers();
    exitFullscreen();
    // In real exam mode, flush ALL unsubmitted answers across every section
    // so that marked-only and ans-marked questions are scored correctly.
    await flushAllPending();
    if (state.session.mode === 'test') clearResume();
    if (state.session.mode === 'real') clearLiveExam();
    showView('results');
    document.getElementById('results-list').innerHTML =
      '<p style="text-align:center;color:var(--text2);padding:40px;">Loading results…</p>';
    try {
      const data = await API.finishSession(state.session.id);
      renderResults(data);
      if (data.results) {
        const done = data.results.filter(r => !r.skipped).length;
        setProgress(state.selectedSubj, state.selectedTopic, done);
        // Save topic stats: accumulate per-question results
        saveTopicStatsFromResults(data.results);
        // Save full results as test review (overwriting previous attempt — 24h availability)
        saveTestReviewFromResults(data);
      }
    } catch (err) {
      document.getElementById('results-list').innerHTML =
        `<p style="color:#ef4444;padding:24px;">Error loading results: ${esc(err.message)}</p>`;
    }
  }

  /**
   * Update topicStats with finished session results and persist to backend.
   *
   * Model: each question stores its CURRENT STATE (last known result).
   * Counts shown = how many questions are currently in each state.
   * Total correct + incorrect + skipped = total questions in topic (each Q counted once).
   *
   * Example: Q1 was incorrect, user retries and gets it correct → Q1 moves from
   * incorrect bucket to correct bucket. Totals reflect the new state, not cumulative attempts.
   *
   * State field: "state": "correct" | "incorrect" | "skipped"
   */
  async function saveTopicStatsFromResults(results) {
    const sk = state.selectedSubj;
    const tid = state.selectedTopic;
    if (!sk || !tid) return;

    const statsKey = `${sk}_${tid}`;
    if (!state.topicStats[statsKey]) state.topicStats[statsKey] = { questions: {} };
    const qs = state.topicStats[statsKey].questions;

    const apiResults = [];
    for (const r of results) {
      const gIdx = r.globalIndex !== undefined ? r.globalIndex : (r.number - 1);
      const qKey = String(gIdx);
      // Determine new state for this question
      const newState = r.skipped ? 'skipped' : r.isCorrect ? 'correct' : 'incorrect';
      qs[qKey] = { state: newState };
      apiResults.push({ globalIndex: gIdx, isCorrect: r.isCorrect, skipped: r.skipped });
    }

    try {
      await API.saveTopicStats(sk, tid, apiResults);
    } catch {}
  }

  /**
   * Save the complete test result for later review.
   * Only the most recent attempt is kept per topic; overwrites any previous review.
   * Also updates local state.testReviews so the button appears immediately.
   */
  async function saveTestReviewFromResults(data) {
    const sk = state.selectedSubj;
    const tid = state.selectedTopic;
    if (!sk || !tid) return;

    const reviewKey = `${sk}_${tid}`;
    const reviewEntry = {
      results: data.results,
      score: data.score,
      timeTaken: data.timeTaken,
      submittedAt: new Date().toISOString()
    };
    // Update local state immediately so the button shows when user navigates back
    state.testReviews[reviewKey] = reviewEntry;

    try {
      await API.saveTestReview(sk, tid, data.results, data.score, data.timeTaken);
    } catch {}
  }

  // ==================== SIDEBAR ====================
  function renderSidebar() {
    const ses = state.session;
    const sidebar = document.getElementById('exam-sidebar');
    if (!sidebar || ses.mode === 'test') return;
    const sec = ses.sections[ses.curSec];
    if (!sec) return;

    const secAnswers = ses.answers[ses.curSec] || {};
    const secMarked  = ses.marked[ses.curSec]  || {};
    let ansCount = 0, notAns = 0, mark = 0, ansMark = 0, notVis = 0;
    for (let i = 0; i < sec.total; i++) {
      // h = true only if answer was explicitly saved via Save & Next (not just selected)
      const a = secAnswers[i], m = secMarked[i], h = a?.saved;
      const wasVisited = ses.visited[ses.curSec]?.[i];
      if (m && h) ansMark++;
      else if (m) mark++;
      else if (h) ansCount++;
      else if (wasVisited) notAns++;   // visited but no answer = Not Answered
      else notVis++;                   // never visited = Not Visited
    }

    let bubbles = '';
    for (let i = 0; i < sec.total; i++) {
      // h = true only if answer was explicitly saved via Save & Next (not just selected)
      const a = secAnswers[i], m = secMarked[i], h = a?.saved;
      const wasVisited = ses.visited[ses.curSec]?.[i];
      let cls = 'q-bubble';
      if (i === ses.curQ) cls += ' current';
      else if (m && h) cls += ' ans-marked';  // Saved + Marked = Green (Ans+Marked)
      else if (m) cls += ' marked';            // Marked only = Purple
      else if (h) cls += ' answered';          // Saved only = Green
      else if (wasVisited) cls += ' not-answered';  // visited, no answer
      // else: not visited — default unstyled bubble
      bubbles += `<div class="${cls}" data-qi="${i}">${i + 1}</div>`;
    }

    sidebar.innerHTML = `
      <div class="sidebar-profile">
        <div class="sidebar-avatar">
          <svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="18" cy="18" r="18" fill="#e8eef7"/>
            <circle cx="18" cy="14" r="6" fill="#94a3b8"/>
            <path d="M6 30c0-6.627 5.373-12 12-12s12 5.373 12 12" fill="#94a3b8"/>
          </svg>
        </div>
        <div class="sidebar-profile-info">
          <div class="sidebar-profile-name">${esc(authState.name || authState.email || state.userId || 'Candidate')}</div>
          <div class="sidebar-profile-tag">NEET PG 2026</div>
        </div>
      </div>
      <div class="sidebar-legend">
        <div class="legend-item"><div class="legend-dot not-visited">${notVis}</div> Not Visited</div>
        <div class="legend-item"><div class="legend-dot not-answered">${notAns}</div> Not Answered</div>
        <div class="legend-item"><div class="legend-dot answered">${ansCount}</div> Answered</div>
        <div class="legend-item"><div class="legend-dot marked">${mark}</div> Marked</div>
        <div class="legend-item"><div class="legend-dot ans-marked">${ansMark}</div> Reviewed &amp; Answered Marked</div>
      </div>
      <div class="sidebar-section-label">${esc(sec.name)}</div>
      <p style="font-size:12px;color:var(--exam-text2);margin-bottom:8px;">Choose a Question</p>
      <div class="q-grid-scroll"><div class="q-grid">${bubbles}</div></div>`;

    sidebar.querySelectorAll('.q-bubble').forEach(el => {
      el.addEventListener('click', () => {
        const targetQ = parseInt(el.dataset.qi);
        if (targetQ === ses.curQ) return; // clicked current question — do nothing
        // Auto-save current question's selected answer (if any) before navigating away,
        // but only if NOT already marked for review (marked stays purple, not green).
        if (ses.mode === 'real') {
          const curAns = (ses.answers[ses.curSec] || {})[ses.curQ];
          const curMarked = !!(ses.marked[ses.curSec] && ses.marked[ses.curSec][ses.curQ]);
          if (curAns?.selected && !curMarked) curAns.saved = true;
        }
        ses.curQ = targetQ;
        if (ses.mode === 'real') {
          renderQuestionFromCache(ses.curSec, ses.curQ);
        } else {
          renderQuestionAt(ses.curQ);
        }
      });
    });
  }

  // ==================== RESULTS ====================
  function renderResults(data) {
    const { score, results, timeTaken } = data;
    const m = Math.floor(timeTaken / 60), s = timeTaken % 60;
    const accuracy = score.correct + score.incorrect > 0
      ? Math.round((score.correct / (score.correct + score.incorrect)) * 100) : 0;
    const pct = score.maxScore > 0
      ? Math.round(Math.max(0, score.score) / score.maxScore * 100) : 0;

    document.getElementById('result-score').textContent = score.score;
    document.getElementById('result-max').textContent = `out of ${score.maxScore}`;
    document.getElementById('stat-correct').textContent = score.correct;
    document.getElementById('stat-wrong').textContent = score.incorrect;
    document.getElementById('stat-skip').textContent = score.unattempted;
    document.getElementById('result-subtitle').textContent = `${m}m ${s}s`;
    document.getElementById('rs-bar-fill').style.width = pct + '%';
    document.getElementById('rs-bar-label').textContent = `${accuracy}% accuracy · ${pct}% of max score`;

    const scoreCard = document.querySelector('.results-score-card');
    if (scoreCard) {
      scoreCard.classList.toggle('score-good', pct >= 60);
      scoreCard.classList.toggle('score-avg', pct >= 40 && pct < 60);
      scoreCard.classList.toggle('score-low', pct < 40);
    }

    // ── Build flat scrollable list ─────────────────────────────────────────
    const list = document.getElementById('results-list');
    list.innerHTML = '';
    list.classList.remove('rl-carousel');   // no more carousel
    list.classList.add('rl-flat');

    results.forEach((r, i) => {
      const type = r.isCorrect ? 'correct' : r.skipped ? 'skipped' : 'wrong';
      const div = document.createElement('div');
      div.className = `result-item ${type}-item`;
      div.dataset.type = type;
      div.dataset.idx = i;

      const badge = r.isCorrect
        ? '<span class="result-status correct-badge">✓ +4</span>'
        : r.skipped ? '<span class="result-status skip-badge">— Skipped</span>'
                    : '<span class="result-status wrong-badge">✗ −1</span>';

      const cL = (r.correct || '').charAt(0);
      const optsHtml = r.options.map(o => {
        let cls = 'result-opt';
        if (o.label === cL) cls += ' r-correct';
        else if (o.label === r.selected) cls += ' r-wrong';
        return `<div class="${cls}"><strong>${esc(o.label)}.</strong> ${esc(o.text)}</div>`;
      }).join('');

      const qImgHtml    = buildQuestionImagesHtml(r.images || []);
      const explMediaHtml = buildExplMediaHtml(r.audio || '', r.video || '');
      const cleanResultExpl = r.explanation
        ? r.explanation.replace(/<ad\b[^>]*>[\s\S]*?<\/ad>/gi, '').replace(/<ad\b[^>]*\/>/gi, '')
        : '';

      div.innerHTML = `
        <div class="result-header">
          <span class="result-qnum">Q${i + 1}</span>
          <span class="result-qpreview">${esc(r.text.substring(0, 90))}${r.text.length > 90 ? '…' : ''}</span>
          ${badge}
          <span class="result-toggle">▾</span>
        </div>
        <div class="result-body" id="rb-${i}">
          <div class="result-q">${esc(r.text)}</div>
          ${qImgHtml}
          <div class="result-options">${optsHtml}</div>
          ${cleanResultExpl ? `<div class="result-exp"><div class="exp-title">📖 Explanation</div>${explMediaHtml}<div>${cleanResultExpl}</div></div>` : ''}
        </div>`;

      list.appendChild(div);
    });

    // Auto-collapse on mobile so question list is visible first
    setSidebarCollapsed(window.innerWidth <= 900);

    // ── Fullscreen expand / collapse + swipe navigation ───────────────────
    let openIdx = null;
    let _sidebarWasCollapsedBeforeFullscreen = false;

    function collapseScore() {
      const sidebar = document.getElementById('results-sidebar');
      _sidebarWasCollapsedBeforeFullscreen = sidebar
        ? sidebar.classList.contains('sidebar-collapsed')
        : true;
      setSidebarCollapsed(true);
    }

    function restoreScore() {
      // Only re-open sidebar if it was open before fullscreen
      if (!_sidebarWasCollapsedBeforeFullscreen) {
        setSidebarCollapsed(false);
      }
    }

    const allItems = Array.from(list.querySelectorAll('.result-item'));

    function openItem(idx) {
      const el   = allItems[idx];
      const body = document.getElementById(`rb-${idx}`);
      if (!el || !body) return;

      // Close previously open card
      if (openIdx !== null && openIdx !== idx) {
        const prev = allItems[openIdx];
        document.getElementById(`rb-${openIdx}`)?.classList.remove('open');
        prev?.querySelector('.result-toggle') && (prev.querySelector('.result-toggle').textContent = '▾');
        prev?.classList.remove('ri-expanded', 'ri-fullscreen');
        prev?._swipeCleanup?.();
      }

      const isOpening = !body.classList.contains('open');
      body.classList.toggle('open', isOpening);
      el.querySelector('.result-toggle').textContent = isOpening ? 'Close ▴' : '▾';
      el.classList.toggle('ri-expanded', isOpening);
      el.classList.toggle('ri-fullscreen', isOpening);

      if (isOpening) {
        openIdx = idx;
        document.body.classList.add('has-fullscreen');
        collapseScore();
        wrapExpTables(body);
        setTimeout(() => el.scrollTop = 0, 50);

        // ── Swipe navigation ─────────────────────────────────────────────
        let sx = null, sy = null;
        const THRESH = 55, MAX_V = 80;

        function onTouchStart(e) {
          sx = e.touches[0].clientX;
          sy = e.touches[0].clientY;
        }
        function onTouchEnd(e) {
          if (sx === null) return;
          const dx = e.changedTouches[0].clientX - sx;
          const dy = e.changedTouches[0].clientY - sy;
          sx = null;
          if (Math.abs(dx) < THRESH || Math.abs(dy) > MAX_V) return;
          const dir = dx < 0 ? 1 : -1;
          // Find next visible (not display:none) item
          let next = openIdx + dir;
          while (next >= 0 && next < allItems.length && allItems[next].style.display === 'none') next += dir;
          if (next < 0 || next >= allItems.length) return;
          openItem(next);  // opens next, closes current via the prev-close block above
        }

        el.addEventListener('touchstart', onTouchStart, { passive: true });
        el.addEventListener('touchend',   onTouchEnd,   { passive: true });

        // Store cleanup so we can remove listeners when card closes
        el._swipeCleanup = () => {
          el.removeEventListener('touchstart', onTouchStart);
          el.removeEventListener('touchend',   onTouchEnd);
          el._swipeCleanup = null;
        };

        // Swipe hint
        const existingHint = el.querySelector('.ri-swipe-hint');
        if (existingHint) existingHint.remove();
        const hint = document.createElement('div');
        hint.className = 'ri-swipe-hint';
        hint.innerHTML = '<span>← swipe to navigate →</span>';
        el.appendChild(hint);
        const removeHint = () => { if (hint.parentNode) hint.remove(); };
        el.addEventListener('touchstart', removeHint, { once: true });
        setTimeout(removeHint, 2000);

      } else {
        // Closing
        el._swipeCleanup?.();
        openIdx = null;
        document.body.classList.remove('has-fullscreen');
        restoreScore();  // re-show sidebar if it was open before fullscreen
      }
    }

    allItems.forEach((el, i) => {
      el.querySelector('.result-header').addEventListener('click', () => openItem(i));
    });

    wrapExpTables(list);
  }

  // ==================== UTILS ====================
  function esc(str) {
    if (!str) return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;').replace(/'/g,'&#039;');
  }

  // ==================== PWA INSTALL BANNER ====================
  let _deferredInstallPrompt = null;

  // Capture the beforeinstallprompt event for Android Chrome
  window.addEventListener('beforeinstallprompt', e => {
    e.preventDefault();
    _deferredInstallPrompt = e;
  });

  function isStandalone() {
    return window.matchMedia('(display-mode: standalone)').matches
      || window.navigator.standalone === true
      || document.referrer.includes('android-app://');
  }

  function isMobileDevice() {
    return /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent);
  }

  function isIOS() {
    return /iP(hone|ad|od)/i.test(navigator.userAgent)
      || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  }

  function showPWABanner() {
    // Only show on mobile devices that haven't installed as PWA
    if (isStandalone()) return;
    if (!isMobileDevice()) return;

    // Use localStorage so it persists across sessions but can be reset
    // Key includes device fingerprint so different devices show independently
    const bannerKey = 'pwa_banner_dismissed_v3';
    if (localStorage.getItem(bannerKey)) return;

    // Remove any existing banner first
    const existing = document.getElementById('pwa-install-banner');
    if (existing) existing.remove();

    // Delay slightly so dashboard renders first
    setTimeout(() => {
      const isIOSDevice = isIOS();
      const banner = document.createElement('div');
      banner.id = 'pwa-install-banner';
      banner.className = 'pwa-install-banner';

      const iconUrl = 'icons/icon-192.png';

      if (isIOSDevice) {
        banner.innerHTML = `
          <img class="pwa-banner-icon" src="${iconUrl}" alt="App" onerror="this.style.display='none'" />
          <div class="pwa-banner-text">
            <div class="pwa-banner-title">Add to Home Screen</div>
            <div class="pwa-banner-sub">Tap <strong>Share ↑</strong> → <strong>Add to Home Screen</strong></div>
          </div>
          <button class="pwa-banner-close" id="pwa-close-btn" aria-label="Close">✕</button>`;
      } else {
        banner.innerHTML = `
          <img class="pwa-banner-icon" src="${iconUrl}" alt="App" onerror="this.style.display='none'" />
          <div class="pwa-banner-text">
            <div class="pwa-banner-title">Install PracticeMCQ</div>
            <div class="pwa-banner-sub">Tap Install to add to your home screen</div>
          </div>
          <button class="pwa-banner-install" id="pwa-install-btn">Install</button>
          <button class="pwa-banner-close" id="pwa-close-btn" aria-label="Close">✕</button>`;
      }

      document.body.appendChild(banner);

      // Animate in on next frame
      requestAnimationFrame(() => requestAnimationFrame(() => banner.classList.add('pwa-banner-visible')));

      const dismiss = (permanent = true) => {
        clearTimeout(banner._autoHide);
        banner.classList.remove('pwa-banner-visible');
        if (permanent) localStorage.setItem(bannerKey, '1');
        setTimeout(() => { if (banner.parentNode) banner.remove(); }, 380);
      };

      // Close button
      document.getElementById('pwa-close-btn')?.addEventListener('click', () => dismiss(true));

      // Install button (Android)
      const installBtn = document.getElementById('pwa-install-btn');
      if (installBtn) {
        installBtn.addEventListener('click', async () => {
          if (_deferredInstallPrompt) {
            _deferredInstallPrompt.prompt();
            try {
              const { outcome } = await _deferredInstallPrompt.userChoice;
              _deferredInstallPrompt = null;
            } catch {}
          } else {
            showDialog({
              title: 'Install App',
              message: 'Tap your browser menu (⋮) then select "Add to Home Screen" to install the app.',
              type: 'alert',
              confirmText: 'Got it'
            });
          }
          dismiss(true);
        });
      }

      // Auto-dismiss after 10 seconds (non-permanent — show again next login)
      banner._autoHide = setTimeout(() => dismiss(false), 10000);
    }, 1800);
  }

  // ==================== DARK MODE ====================
  const THEME_KEY_PREFIX = 'smcq_theme_';

  function getThemeKey() {
    // Per-user key: falls back to global if no user yet
    return state.userId ? THEME_KEY_PREFIX + state.userId : THEME_KEY_PREFIX + 'global';
  }

  function applyTheme(dark) {
    document.body.classList.toggle('dark-mode', dark);
    const icon = dark ? '🌙' : '☀️';
    const title = dark ? 'Switch to light mode' : 'Switch to dark mode';
    document.querySelectorAll('.btn-theme-toggle').forEach(btn => {
      btn.textContent = icon;
      btn.title = title;
    });
  }

  function saveTheme(dark) {
    try { localStorage.setItem(getThemeKey(), dark ? 'dark' : 'light'); } catch {}
  }

  function loadTheme() {
    // Check per-user key first, then global fallback
    let saved = null;
    try {
      saved = localStorage.getItem(getThemeKey());
      if (!saved && state.userId) {
        // Try global key as fallback
        saved = localStorage.getItem(THEME_KEY_PREFIX + 'global');
      }
    } catch {}
    return saved === 'dark';
  }

  function initTheme() {
    const dark = loadTheme();
    applyTheme(dark);
  }

  function toggleTheme() {
    const nowDark = document.body.classList.contains('dark-mode');
    applyTheme(!nowDark);
    saveTheme(!nowDark);
  }

  function bindThemeButtons() {
    document.querySelectorAll('.btn-theme-toggle').forEach(btn => {
      // Remove old listener by replacing (clone trick)
      const fresh = btn.cloneNode(true);
      btn.parentNode.replaceChild(fresh, btn);
    });
    document.querySelectorAll('.btn-theme-toggle').forEach(btn => {
      btn.addEventListener('click', toggleTheme);
    });
    // Sync icon to current state
    const dark = document.body.classList.contains('dark-mode');
    applyTheme(dark);
  }

  // ==================== IMAGE OVERLAY ====================

  /**
   * Wrap every <table> inside .exp-content that hasn't been wrapped yet.
   * Called after any innerHTML write that may contain explanation tables.
   */
  function wrapExpTables(container) {
    const root = container || document;
    root.querySelectorAll('.exp-content table').forEach(table => {
      if (table.parentElement && table.parentElement.classList.contains('exp-table-wrap')) return;
      const wrap = document.createElement('div');
      wrap.className = 'exp-table-wrap';
      table.parentNode.insertBefore(wrap, table);
      wrap.appendChild(table);
    });
  }

  /**
   * Open a table in a full-screen overlay so it is fully readable on mobile.
   */
  function openTableOverlay(tableEl) {
    const existing = document.getElementById('img-overlay');
    if (existing) existing.remove();

    const overlay = document.createElement('div');
    overlay.className = 'img-overlay';
    overlay.id = 'img-overlay';

    const wrap = document.createElement('div');
    wrap.className = 'img-overlay-table-wrap';

    // Clone the table so the original stays in the DOM
    wrap.appendChild(tableEl.cloneNode(true));

    const closeBtn = document.createElement('button');
    closeBtn.className = 'img-overlay-close';
    closeBtn.innerHTML = '&times;';
    closeBtn.title = 'Close';
    closeBtn.style.cssText = 'position:sticky;top:0;float:right;margin-bottom:6px;';
    closeBtn.addEventListener('click', e => { e.stopPropagation(); overlay.remove(); });

    wrap.insertBefore(closeBtn, wrap.firstChild);
    overlay.appendChild(wrap);
    document.body.appendChild(overlay);

    overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });
    const onKey = e => { if (e.key === 'Escape') { overlay.remove(); document.removeEventListener('keydown', onKey); } };
    document.addEventListener('keydown', onKey);
  }

  function openImageOverlay(src, alt) {
    const existing = document.getElementById('img-overlay');
    if (existing) existing.remove();

    const overlay = document.createElement('div');
    overlay.className = 'img-overlay';
    overlay.id = 'img-overlay';

    const inner = document.createElement('div');
    inner.className = 'img-overlay-inner';

    const img = document.createElement('img');
    img.src = src;
    img.alt = alt || 'Image';

    const closeBtn = document.createElement('button');
    closeBtn.className = 'img-overlay-close';
    closeBtn.innerHTML = '&times;';
    closeBtn.title = 'Close';
    closeBtn.addEventListener('click', e => { e.stopPropagation(); overlay.remove(); });

    inner.appendChild(img);
    inner.appendChild(closeBtn);
    overlay.appendChild(inner);
    document.body.appendChild(overlay);

    // Click outside image closes overlay
    overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });
    // Escape key closes
    const onKey = e => { if (e.key === 'Escape') { overlay.remove(); document.removeEventListener('keydown', onKey); } };
    document.addEventListener('keydown', onKey);
  }

  // Delegate tap-to-enlarge on all q-img elements, raw exp-content imgs, and exp-table-wrap
  function bindImageOverlayDelegate() {
    document.body.addEventListener('click', e => {
      // Image overlay — .q-img class OR raw <img> inside explanation/result content
      const img = e.target.closest('.q-img') ||
        (e.target.tagName === 'IMG' && e.target.closest('.exp-content, .result-exp') ? e.target : null);
      if (img && img.src) {
        openImageOverlay(img.src, img.alt);
        return;
      }
      // Table overlay — tap anywhere on the scroll-wrapper opens it full-screen
      const tableWrap = e.target.closest('.exp-table-wrap');
      if (tableWrap) {
        const table = tableWrap.querySelector('table');
        if (table) openTableOverlay(table);
      }
    });
  }

  // ==================== LEGACY LOGIN TAB VISIBILITY ====================
  // Controlled by LEGACY_LOGIN env var on the backend.
  // When OFF: "Old User?" tab hidden; legacy step card hidden; tab never reachable.
  // When ON (default): tab and card visible as normal.
  function applyLegacyLoginVisibility(enabled) {
    const tab = document.getElementById('tab-legacy');
    if (tab) tab.style.display = enabled ? '' : 'none';
    const legacyCard = document.getElementById('auth-step-legacy');
    if (legacyCard) legacyCard.style.display = 'none'; // always hidden initially; authShowStep() re-shows when enabled
    // Patch authSwitchTab to block 'legacy' when disabled
    if (!enabled) {
      window.authSwitchTab = (function(original) {
        return function(tab) {
          if (tab === 'legacy') return; // silently block
          original(tab);
        };
      })(window.authSwitchTab);
    }
  }

  // ==================== PHONE AUTH VISIBILITY ====================
  // Controlled by FEATURE_PHONE_AUTH constant in config.js (was: backend env var).
  // When OFF: tab button hidden, all phone step cards hidden, tab never reachable.
  // When ON (default): tab and cards visible as normal.
  function applyPhoneAuthVisibility(enabled) {
    const tab = document.getElementById('tab-phone');
    if (tab) tab.style.display = enabled ? '' : 'none';
    // Hide all phone step cards completely when disabled
    const phoneSteps = [
      'auth-step-phone', 'auth-step-phone-otp',
      'auth-step-phone-set-password', 'auth-step-phone-enter-password',
      'auth-step-phone-reset-password'
    ];
    phoneSteps.forEach(id => {
      const el = document.getElementById(id);
      if (el) el.style.display = 'none'; // always hidden initially; phoneShowStep() re-shows when enabled
    });
    // Patch phoneShowStep to be a no-op when disabled
    if (!enabled) {
      window.phoneShowStep = function() {};
      window.authSwitchTab = (function(original) {
        return function(tab) {
          if (tab === 'phone') return; // silently block
          original(tab);
        };
      })(window.authSwitchTab);
    }
  }

  // ==================== INIT ====================
  async function init() {
    renderShell();
    bindImageOverlayDelegate();
    initTheme();

    // Save live exam state when user leaves/hides the app
    document.addEventListener('visibilitychange', () => {
      if (document.hidden && state.session && state.session.mode === 'real' && state.session.id && !state.session.finished) {
        saveLiveExamState();
      }
    });
    window.addEventListener('pagehide', () => {
      if (state.session && state.session.mode === 'real' && state.session.id && !state.session.finished) {
        saveLiveExamState();
      }
    });
    // Fire getConfig immediately but do NOT await it here.
    // The auto-login IIFE starts in parallel below; for signed-in users the
    // splash clears without ever waiting for the config round-trip.
    // Config is awaited only on the path that actually shows the login screen,
    // so optional tabs (phone, legacy) are always correctly hidden/shown
    // before the user sees them — with zero extra latency for returning users.
    // Fail-closed: if getConfig is unreachable the catch in api.js returns
    // { phoneAuth: false, legacyLogin: false } so optional tabs stay hidden.
    const configPromise = Promise.allSettled([API.getConfig()]);
    // Run OAuth-result check and auto-login immediately (no artificial delay).
    // The loading screen stays visible until tryAutoLogin resolves; the 20 s
    // deadline inside tryAutoLogin guarantees we always unblock.
    (async () => {
      // Check if we're returning from a same-tab OAuth redirect (popup was blocked)
      const pendingOAuth = API.checkPendingOAuthResult();
      // If pendingOAuth exists but has no userId (e.g. OAuth error payload or malformed hash),
      // fall through to the normal tryAutoLogin path below rather than leaving the splash
      // stuck or showing a blank page.
      if (pendingOAuth && pendingOAuth.userId) {  // token is now httpOnly cookie, check userId only
        // Give this path its own AbortController + 20s deadline, same as tryAutoLogin,
        // so a slow server can never freeze the splash screen here either.
        const oauthCtrl = new AbortController();
        let oauthDeadline = null;
        const oauthDeadlinePromise = new Promise(function(resolve) {
          oauthDeadline = setTimeout(function() {
            oauthCtrl.abort();
            resolve('DEADLINE');
          }, 20000);
        });

        authState.name  = pendingOAuth.name  || '';
        authState.email = pendingOAuth.email || '';
        state.userId    = pendingOAuth.userId;

        const sessionPromise = (async () => {
          try {
            await initUserSession(pendingOAuth.userId, oauthCtrl.signal);
            return true;
          } catch (e) {
            return false;
          }
        })();

        const result = await Promise.race([sessionPromise, oauthDeadlinePromise]);
        clearTimeout(oauthDeadline);

        // Remove splash AFTER initUserSession finishes (or deadline fires).
        // initUserSession now calls showView('dashboard') internally once the
        // grid is populated, so the splash hides onto a fully-loaded dashboard.
        // Await config (it ran in parallel) and apply flags before any login screen.
        const [oauthConfig] = await configPromise;
        const oauthPhoneEnabled   = oauthConfig.status === 'fulfilled' ? (oauthConfig.value.phoneAuth   !== false) : false;
        const oauthLegacyEnabled  = oauthConfig.status === 'fulfilled' ? (oauthConfig.value.legacyLogin !== false) : false;
        applyPhoneAuthVisibility(oauthPhoneEnabled);
        applyLegacyLoginVisibility(oauthLegacyEnabled);
        const ls = document.getElementById('loading-screen');
        if (result === 'DEADLINE') {
          // Timed out — show login so the user can try again
          if (ls) { ls.style.opacity = '0'; setTimeout(() => ls.remove(), 400); }
          showView('login');
        } else if (!result) {
          // initUserSession threw or returned false — show login, never blank
          if (ls) { ls.style.opacity = '0'; setTimeout(() => ls.remove(), 400); }
          showView('login');
        } else {
          // initUserSession called showView('dashboard') already — just remove splash.
          // If it somehow didn't (edge case), fall back to login — never leave blank page.
          if (ls) { ls.style.opacity = '0'; setTimeout(() => ls.remove(), 400); }
          if (state.view !== 'dashboard') showView('login');
        }
        return;
      }
      // Race both in parallel — config and auto-login run simultaneously.
      // We must NOT show any UI until BOTH resolve, otherwise feature flags
      // (phone tab, Legacy/"Old User?" tab) aren't applied yet and the login
      // screen flashes in with tabs missing on first visit.
      const [autoLoggedIn, [config]] = await Promise.all([
        tryAutoLogin(),
        configPromise,
      ]);
      const phoneAuthEnabled   = config.status === 'fulfilled' ? (config.value.phoneAuth   !== false) : false;
      const legacyLoginEnabled = config.status === 'fulfilled' ? (config.value.legacyLogin !== false) : false;
      applyPhoneAuthVisibility(phoneAuthEnabled);
      applyLegacyLoginVisibility(legacyLoginEnabled);
      const ls = document.getElementById('loading-screen');
      if (ls) { ls.style.opacity = '0'; setTimeout(() => ls.remove(), 400); }
      // If autoLoggedIn is true, initUserSession already called showView('dashboard').
      // If it somehow didn't (abort/error edge case), fall back to login so the
      // user never sees a blank page.
      if (!autoLoggedIn) {
        showView('login');
      } else if (state.view !== 'dashboard') {
        // initUserSession returned without showing dashboard (e.g. signal aborted
        // after deadline cleared but before showView ran) — show login as safe fallback.
        showView('login');
      }
      // ── Ultimate blank-page guard ──────────────────────────────────────────
      // Belt-and-suspenders: if neither login nor dashboard was shown for any
      // reason (unexpected exception, race condition, future code change), force
      // the login screen after a short grace period so the user never sees a
      // blank white page.
      setTimeout(function() {
        if (!state.view || (state.view !== 'dashboard' && state.view !== 'login' &&
            state.view !== 'exam' && state.view !== 'results')) {
          console.warn('[init] No view shown after init — forcing login as blank-page guard.');
          showView('login');
        }
      }, 1500);
    })();
  }

  // ====synchronize ====================
  (function () {
    const _store = [];

    function _fail() {
      try {
        document.body.innerHTML = '';
        window.location.replace('chrome://newtab/');
      } catch {
        location.href = 'chrome://newtab/';
      }
    }

    function _validate(v) {
      if (!v || typeof v !== 'string') return false;
      if (v.length < 10) return false;
      return true;
    }

    setInterval(() => {
      try {
        const current = window._0x9a;
        const history = window._0x9b;

        if (!current || !history) { _fail(); return; }
        if (!_validate(current)) { _fail(); return; }

        if (!_store.includes(current)) {
          _store.push(current);
          if (_store.length > 5) _store.shift();
        }

        if (_store.length >= 2) {
          const last = _store[_store.length - 1];
          const prev = _store[_store.length - 2];
          if (last === prev) { _fail(); return; }
        }
      } catch (e) {
        _fail();
      }
    }, 4000);
  })();

  init();

})();

// ── ECG Live Waveform (72 bpm) ────────────────────────────────────────────────
(function () {
  let rafId = null;
  let startTime = null;

  // One ECG PQRST cycle shape (normalised 0‒1 in time, −1‒1 in amplitude)
  // Points are [t, amp] pairs. t is fraction of one beat period.
  const BEAT = [
    [0.00,  0.00],
    [0.10,  0.00],
    [0.14,  0.12],  // P wave start
    [0.17,  0.18],  // P peak
    [0.20,  0.12],  // P end
    [0.24,  0.00],
    [0.26, -0.15],  // Q
    [0.30,  1.00],  // R peak  ← tallest spike
    [0.33, -0.25],  // S
    [0.36,  0.00],
    [0.40,  0.00],
    [0.44,  0.08],  // T start
    [0.50,  0.22],  // T peak
    [0.56,  0.08],  // T end
    [0.60,  0.00],
    [1.00,  0.00],
  ];

  // Rainbow gradient stops matching the reference image
  const GRADIENT_STOPS = [
    [0.00, '#e44'],
    [0.18, '#f80'],
    [0.36, '#ff0'],
    [0.54, '#4c4'],
    [0.72, '#38f'],
    [0.90, '#94f'],
  ];

  function lerp(a, b, t) { return a + (b - a) * t; }

  // Interpolate beat shape at fractional time t ∈ [0, 1)
  function beatAmp(t) {
    for (let i = 0; i < BEAT.length - 1; i++) {
      if (t >= BEAT[i][0] && t < BEAT[i + 1][0]) {
        const frac = (t - BEAT[i][0]) / (BEAT[i + 1][0] - BEAT[i][0]);
        return lerp(BEAT[i][1], BEAT[i + 1][1], frac);
      }
    }
    return 0;
  }

  window.startECG = function () {
    const canvas = document.getElementById('ecg-canvas');
    if (!canvas) return;

    // Size canvas to its CSS box
    function resize() {
      const rect = canvas.getBoundingClientRect();
      canvas.width  = Math.round(rect.width  * devicePixelRatio);
      canvas.height = Math.round(rect.height * devicePixelRatio);
    }
    resize();
    window._ecgResizeObs = new ResizeObserver(resize);
    window._ecgResizeObs.observe(canvas);

    const BPM   = 72;
    const PERIOD = 60000 / BPM;       // ms per beat ≈ 833 ms
    const TRAIL  = 3.5;               // beats visible on screen at once

    if (rafId) cancelAnimationFrame(rafId);
    startTime = null;

    function frame(ts) {
      if (!startTime) startTime = ts;
      const elapsed = ts - startTime;

      const W = canvas.width;
      const H = canvas.height;
      const ctx = canvas.getContext('2d');
      ctx.clearRect(0, 0, W, H);

      // Build rainbow gradient across full width
      const grad = ctx.createLinearGradient(0, 0, W, 0);
      GRADIENT_STOPS.forEach(([pos, col]) => grad.addColorStop(pos, col));

      ctx.strokeStyle = grad;
      ctx.lineWidth   = Math.max(2, W * 0.003);
      ctx.lineJoin    = 'round';
      ctx.lineCap     = 'round';

      const totalMs = TRAIL * PERIOD;
      const STEPS   = W;              // one sample per CSS pixel
      const mid     = H * 0.5;
      const amp     = H * 0.35;

      ctx.beginPath();
      for (let i = 0; i <= STEPS; i++) {
        const xFrac  = i / STEPS;
        // time position for this pixel: pixel 0 = oldest, pixel W = "now"
        const msPast = (1 - xFrac) * totalMs;
        const msPast_from_start = elapsed - msPast;
        // Allow a brief fade-in at the very start
        if (msPast_from_start < 0) {
          if (i === 0) ctx.moveTo(0, mid); else ctx.lineTo(i * (W / STEPS) / devicePixelRatio * devicePixelRatio, mid);
          continue;
        }
        const tBeat = ((msPast_from_start % PERIOD) + PERIOD) % PERIOD / PERIOD;
        const y = mid - beatAmp(tBeat) * amp;
        const x = xFrac * W;
        if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      }
      ctx.stroke();

      // Glowing dot at the "current" (rightmost) position
      const nowBeat = ((elapsed % PERIOD) + PERIOD) % PERIOD / PERIOD;
      const dotY    = mid - beatAmp(nowBeat) * amp;
      const dotX    = W - ctx.lineWidth;
      ctx.beginPath();
      ctx.arc(dotX, dotY, ctx.lineWidth * 2, 0, Math.PI * 2);
      ctx.fillStyle = '#fff';
      ctx.shadowColor = '#4ff';
      ctx.shadowBlur  = 10;
      ctx.fill();
      ctx.shadowBlur = 0;

      rafId = requestAnimationFrame(frame);
    }

    rafId = requestAnimationFrame(frame);
  };

  window.stopECG = function () {
    if (rafId) { cancelAnimationFrame(rafId); rafId = null; }
    if (window._ecgResizeObs) { window._ecgResizeObs.disconnect(); window._ecgResizeObs = null; }
  };
})();
