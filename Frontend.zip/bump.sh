#!/usr/bin/env bash
# ---------------------------------------------------------------
#  bump.sh - single deploy step for PracticeMCQ
#
#  Usage:
#    bash bump.sh        (prompts for new version)
#    bash bump.sh 10     (sets version to 10 directly)
#
#  What it does:
#    Updates APP_VERSION in js/config.js only.
#    sw.js and index.html do not need changes.
#
#  How updates are detected:
#    - sw.js calls importScripts('/js/config.js') — the SW fetch
#      handler bypasses the SW for config.js, so importScripts
#      always gets the live version from the network. When
#      APP_VERSION changes, CACHE_NAME changes, the browser sees
#      a different SW, installs it, and shows the "Update Now" toast.
#    - index.html's nuke script also loads config.js fresh (same
#      bypass) and checks localStorage for 'cache_nuked_vN'.
# ---------------------------------------------------------------
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
CONFIG="$SCRIPT_DIR/js/config.js"

# Read current version from config.js
CURRENT=$(grep -oP 'APP_VERSION\s*=\s*\K[0-9]+' "$CONFIG" | head -1)
echo "Current APP_VERSION: $CURRENT"

# Get new version
if [ -n "$1" ]; then
  NEW="$1"
else
  read -rp "Enter new version number [default: $((CURRENT + 1))]: " NEW
  NEW="${NEW:-$((CURRENT + 1))}"
fi

# Validate
if ! [[ "$NEW" =~ ^[0-9]+$ ]]; then
  echo "Error: version must be a number (got: $NEW)"
  exit 1
fi

if [ "$NEW" -le "$CURRENT" ]; then
  echo "Warning: new version ($NEW) is not greater than current ($CURRENT)"
  read -rp "Continue anyway? [y/N]: " CONFIRM
  [[ "$CONFIRM" =~ ^[Yy]$ ]] || exit 0
fi

# Update config.js only
sed -i "s/APP_VERSION = ${CURRENT}/APP_VERSION = ${NEW}/" "$CONFIG"

echo ""
echo "Version bumped: $CURRENT -> $NEW"
echo ""
echo "Files changed:"
echo "  js/config.js  - APP_VERSION = $NEW"
echo ""
echo "Deploy all files now."
