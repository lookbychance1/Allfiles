/**
 * PracticeMCQ — Service Worker
 *
 * ┌──────────────────────────────────────────────────────────────────┐
 * │  HOW TO PUSH UPDATES TO ALL USERS:                               │
 * │                                                                  │
 * │  ONE change needed on every deploy:                              │
 * │  → Bump APP_VERSION in js/config.js only (e.g. 8 → 9)           │
 * │                                                                  │
 * │  sw.js reads config.js via importScripts with a ?t= timestamp   │
 * │  so it always gets the latest version — no hardcoding here.     │
 * │                                                                  │
 * │  IMPORTANT: index.html and sw.js are intentionally excluded      │
 * │  from the SW cache. The browser always fetches them from the     │
 * │  network. This ensures the cache-nuke script in index.html       │
 * │  always runs on every fresh visit.                               │
 * └──────────────────────────────────────────────────────────────────┘
 */

// ── VERSION ──────────────────────────────────────────────────────────────────
// config.js is excluded from SW interception (see fetch handler below), so it
// is always served fresh from the network. index.html loads it directly and
// the nuke script reads APP_VERSION from it — no version needed here at all.
//
// The SW's own CACHE_NAME doesn't need to match APP_VERSION exactly; it just
// needs to change when config.js changes. We derive it by fetching config.js
// at install time and reading whatever APP_VERSION is live on the server.
//
// sw.js itself never changes between deploys — the browser re-evaluates it on
// every visit because sw.js is also excluded from SW interception, and the
// browser's built-in SW update check always fetches it from the network.
// When it runs importScripts, it gets the fresh config.js (no-cache because
// the SW fetch handler bypasses it), so CACHE_NAME reflects the new version,
// making sw.js behave differently → browser installs a new SW → waiting → toast.
// Only import the version file — not the full config.js.
// config.js changes whenever notifications/maintenance are toggled, which
// would make sw.js byte-different and trigger a new SW install (and the
// 'Update Now' toast) even when APP_VERSION hasn't changed.
// version.js contains ONLY APP_VERSION and is edited only on real releases.
importScripts('/js/version.js');
const CACHE_NAME = `practicemcq-v${APP_VERSION}`;

// ── index.html and sw.js are deliberately NOT in this list ──────────────────
// index.html must always be fetched live so its nuke script can run.
// sw.js is managed by the browser itself outside of Cache Storage.
const SHELL_ASSETS = [
  `/css/main.css?v=${APP_VERSION}`,
  `/js/shield.js?v=${APP_VERSION}`,
  `/js/api.js?v=${APP_VERSION}`,
  `/js/app.js?v=${APP_VERSION}`,
  '/manifest.json',
  '/icons/icon-192.png',
  '/icons/icon-512.png'
];

// ── Install ──────────────────────────────────────────────────────────────────
// NOTE: No self.skipWaiting() here.
// The new SW stays in "waiting" state so index.html's reg.waiting check
// and the updatefound → statechange === 'installed' path both work correctly,
// showing the "Update Now" toast to the user.
// skipWaiting() is triggered explicitly when nukeAndLogout() reloads the page
// and the new SW takes control naturally after the old one is unregistered.
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(SHELL_ASSETS).catch(() => {}))
  );
});

// ── Activate: purge all old caches ──────────────────────────────────────────
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

// ── Fetch ────────────────────────────────────────────────────────────────────
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);

  // Always bypass SW for API calls and cross-origin
  if (url.pathname.startsWith('/api/') || url.hostname !== self.location.hostname) return;

  // CRITICAL: Never cache or intercept index.html or config.js.
  // index.html must be fetched fresh so the nuke script always runs.
  // config.js and version.js must be fetched fresh so the nuke script reads
  // the real live APP_VERSION — not the version the old SW has cached.
  if (url.pathname === '/' || url.pathname === '/index.html') return;
  if (url.pathname === '/js/config.js') return;
  if (url.pathname === '/js/version.js') return;  // always fetch fresh — SW reads it via importScripts

  // Network-first with 5s timeout — prevents SW cold-start hangs causing blank screen.
  // If network doesn't respond in 5s, fall back to cache immediately.
  event.respondWith(
    Promise.race([
      fetch(event.request).then(response => {
        if (response && response.status === 200 && response.type === 'basic') {
          caches.open(CACHE_NAME).then(cache => cache.put(event.request, response.clone()));
        }
        return response;
      }),
      new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), 5000))
    ]).catch(() =>
      caches.match(event.request).then(cached => cached || new Response('Offline', { status: 503 }))
    )
  );
});
